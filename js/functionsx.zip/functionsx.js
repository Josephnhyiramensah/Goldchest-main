$(document).ready(function()
{
	//SETUP
		//OTHERS
			//isEmail();
		//COMPANY
			company_new_modal();
			company_open();
			company_save();
			company_edit();
			company_update();
			company_lock_unlock();
			company_subscription_open();
			company_subscription_modal();
			company_subscription_set_amount();
			company_subscription_set_expiry_date();
			company_subscription_save();
			company_subscription_edit();
			company_subscription_update();
			company_subscription_delete();
		//BRANCH
			branch_new_modal();
			branch_save();
			branch_edit();
			branch_update();
		//USER_ULTRA_SUPER
			user_ultra_super_new_modal();
			user_ultra_super_save();
			user_ultra_super_edit();
			user_ultra_super_update();
		//USER TYPES
			user_type_new_modal();
			user_type_save();
			user_type_edit();
			user_type_update();
		//USER PRIVILEGES
			user_privilege_new_modal();
			user_privilege_save();
			user_privilege_edit();
			user_privilege_update();
		//USERS-PERSONAL
			user_personal_new_modal();
			user_personal_save();
			user_personal_change_password_modal();
			user_personal_change_password_update();
			user_personal_reset_password_modal();
			user_personal_reset_password_update();
		//USERS
			user_sign_in();
			user_new_modal();
			user_save();
			user_edit();
			user_update();
			user_change_user_type();
			add_user_cash_ledger_row();
			delete_user_cash_ledger_row();
			user_change_branch();
		//USERS-ADMIN
			user_admin_new_sheet();
			user_admin_save();
			user_admin_edit();
			user_admin_update();
		//LEDGERS
			save_ledger();
			new_ledger_modal();
			ledger_modal();
			execute_ledger();
			edit_ledger();
			tb_2_list();
			tb_3_list();
			tb_4_list();
			tb_5_list();
			show_ledger_type();
			update_ledger();
			search_ledger_by_name();
			ledger_help();
			delete_ledger();
		//CUSTOMER
			customer_new_modal();
			customer_save();
			customer_edit();
			customer_update();
			customer_search_modal();
			customer_search();
			customer_search_save();
		//STOCK_ITEMS
			new_stock_item_modal();
			cancel_stock_item_modal();
			stock_item_add_component();
			stock_item_component_price();
			stock_item_sum_component_amount();
			stock_item_delete_component();
			stock_item_pricing();
			save_new_stock_item();
			edit_stock_item();
			update_stock_item();
			stock_item_image_modal();
			stock_item_image_trigger_click();
			stock_item_image_display_before_upload();
			stock_item_img_display_clear();
			delete_stock_item();
			stock_item_auto_update_price_modal();
			stock_item_auto_update_price_modal_component()
			stock_item_auto_update_price_save();
		//COMPONENT
			component_new_modal();
			component_save();
			component_edit();
			component_update();
			component_delete();
		//WAREHOUSE
			new_warehouse_modal();
			save_new_warehouse();
			edit_warehouse();
			update_warehouse();
		//SITES
			new_site_modal();
			save_site();
			edit_site();
			update_site();
		//ASSETS
			new_asset_modal();
			save_asset();
			edit_asset();
			update_asset();
	//FINANCIALS
		//RECEIPT
			new_receipt_voucher_modal();
			receipt_mode_bank_details();
			add_receipt_item_row();
			//mask_receipt_amt();
			sum_receipt_item_amount();
			delete_receipt_item_row();
			cancel_receipt_voucher_modal();
			save_receipt_voucher();
			edit_receipt_voucher();
			update_receipt_voucher();
			search_receipt_by_date();
			reprint_receipt();
			delete_receipt();
		//PAYMENT
			new_payment_voucher_modal();
			payment_mode_bank_details();
			add_payment_item_row();
			//mask_payment_amt();
			sum_payment_item_amount();
			delete_payment_item_row();
			cancel_payment_voucher_modal();
			save_payment_voucher();
			edit_payment_voucher();
			update_payment_voucher();
			search_payment_by_date();
			delete_payment();
		//CONTRA
			new_contra_voucher_modal();
			contra_mode_bank_details();
			cancel_contra_voucher_modal();
			save_contra_voucher();
			edit_contra_voucher();
			update_contra_voucher();
			search_contra_by_date();
			delete_contra();
		//JOURNAL
			new_journal_voucher_modal();
			cancel_journal_voucher_modal();
			save_journal_voucher();
			edit_journal_voucher();
			update_journal_voucher();
			search_journal_by_date();
			delete_journal();
		//PURCHASES
			new_purchase_modal();
			purchase_set_supplied_by();
			purchase_set_grams();
			cancel_purchase_modal();
			purchase_set_pounds()
			purchase_set_density();
			purchase_set_carat();
			purchase_set_purity();
			purchase_price_per_pound();
			purchase_set_amount();
			save_purchase_invoice();
			edit_purchase_invoice();
			update_purchase_invoice();
			delete_purchase_invoice();
			search_purchase_by_name();
			search_purchase_by_date();
			reprint_purchase_invoice();
		//BULK PURCHASES
			new_bulk_purchase_modal();
			add_bulk_purchase_item_row();
			delete_bulk_purchase_item_row();
			bulk_purchase_add_ledger();
			bulk_purchase_delete_ledger();
			bulk_purchase_ledger_group_id();
			bulk_purchase_sum_payment_amount();
			bulk_purchase_set_supplied_by();
			bulk_purchase_set_grams();
			cancel_bulk_purchase_modal();
			bulk_purchase_set_pounds()
			bulk_purchase_set_density();
			bulk_purchase_set_carat();
			bulk_purchase_set_purity();
			bulk_purchase_price_per_pound();
			bulk_purchase_set_amount();
			save_bulk_purchase_invoice();
			edit_bulk_purchase_invoice();
			update_bulk_purchase_invoice();
			delete_bulk_purchase_invoice();
			search_bulk_purchase_by_name();
			search_bulk_purchase_by_date();
			reprint_bulk_purchase_invoice();
		//STOCK_PURCHASES
			new_stock_purchase_modal();
			cancel_stock_purchase_modal();
			add_stock_purchase_item_row();
			get_stock_purchase_item_amount();
			delete_stock_purchase_item_row();
			save_stock_purchase_invoice();
			edit_stock_purchase_invoice();
			update_stock_purchase_invoice();
			search_stock_purchase_by_name();
			search_stock_purchase_by_date();
			delete_stock_purchase_invoice();
		//HIRING
			new_hiring_modal();
			cancel_hiring_modal();
			add_hiring_item_row();
			get_hiring_item_amount();
			delete_hiring_item_row();
			save_hiring_invoice();
			edit_hring_invoice();
			update_hiring_invoice();
			search_hiring_invoice_by_name();
			search_hiring_invoice_by_date();
			delete_hiring_invoice();
		//MAINTENANCE SHEET
			new_mtce_modal();
			cancel_mtce_modal();
			add_mtce_service_item_row();
			add_mtce_stock_item_row();
			get_mtce_service_item_amount();
			get_mtce_stock_item_amount();
			add_mtce_item_price();
			delete_mtce_service_item_row();
			delete_mtce_stock_item_row();
			save_mtce_invoice();
			edit_mtce_invoice();
			update_mtce_invoice();
			search_mtce_invoice_by_name();
			search_mtce_invoice_by_date();
			delete_mtce_invoice();
		//SALES
			new_sales_modal();
			cancel_sales_modal();
			sales_set_pounds()
			sales_set_density();
			sales_set_carat();
			sales_set_purity();
			sales_price_per_pound();
			sales_set_amount();
			add_sales_item();
			delete_sales_item();
			save_sales();
			edit_sales_invoice();
			update_sales_invoice();
			search_sales_by_date();
			search_sales_by_name();
			delete_sales()
			reprint_sales();
		
		//BULK_SALES
			new_bulk_sales_modal();
			bulk_sales_add_ledger();
			bulk_sales_delete_ledger();
			bulk_sales_ledger_group_id();
			bulk_sales_set_item_sales_amount();
			cancel_bulk_sales_modal();
			bulk_sales_sum_payment_amount();
			save_bulk_sales();
			edit_bulk_sales_invoice();
			update_bulk_sales_invoice();
			search_bulk_sales_by_date();
			search_bulk_sales_by_name();
			delete_bulk_sales()
			reprint_bulk_sales();

		//STOCK_SALES
			new_stock_sales_modal();
			cancel_stock_sales_modal();
			add_stock_sales_item_row();
			add_stock_sales_item_price();
			get_stock_sales_item_amount();
			delete_stock_sales_item_row();
			save_stock_sales();
			edit_stock_sales();
			update_stock_sales();
			reprint_stock_sales();
			delete_stock_sales();
			search_stock_sales_invoice_by_name();
			search_stock_sales_invoice_by_date();
		//STOCK_SALES_INVOICE
			stock_sales_invoice_add_ledger();
			stock_sales_invoice_sum_payment_amount();
			stock_sales_invoice_delete_ledger();
			stock_sales_invoice_calculate_net_amount();
			stock_sales_invoice_change_amount();
			stock_sales_invoice_item_search_modal();
			stock_sales_invoice_item_search();
			add_stock_sales_invoice_item_row();
			stock_sales_invoice_delete_item();
			save_stock_sales_invoice();
			reprint_stock_sales_invoice();
			display_stock_sales_invoice();
			edit_stock_sales_invoice();
			update_stock_sales_invoice();
		//SMS
			sms_purchase_modal();
			save_sms_purchase();
			edit_sms_purchase();
			update_sms_purchase();
	//REPORTS
		//PURCHASE REPORT
			purchase_report_modal();
			purchase_report_display();
			purchase_report_by_branch_modal();
			purchase_report_by_branch_display();
			profitability_report_modal();
			profitability_report_display();
		//SALES REPORT
			sales_report_modal();
			sales_report_display();
		//LEDGER REPORT
			ledger_report_modal();
			ledger_report_display();
			ledger_report_display_with_item_detail();
		//LEDGER DETAIL REPORT
			ledger_detail_report_modal();
			ledger_detail_report_display();
		//LEDGER SUMMARY REPORT
			ledger_summary_report_modal();
			ledger_summary_report_display();	
		//CASH REPORT
			cash_report_modal();
			cash_report_display();
		//PROFIT AND LOSS ACCOUNT
			profit_and_loss_modal();
			profit_and_loss_display();
		//BALANCE SHEET
			balance_sheet_modal();
			balance_sheet_display();
	//INVENTORY
		//STOCK REQUISITION
			new_stock_requisition_modal();
			add_stock_requisition_item_row();
			cancel_stock_requisition_modal();
			get_stock_requisition_item_category();
			delete_stock_requisition_item_row();
			save_stock_requisition_voucher();
			edit_stock_requisition_voucher();
			update_stock_requisition_voucher();
		//STOCK TRANSFER
			stock_transfer_modal_requisition();
			save_stock_transfer_voucher();
			edit_stock_transfer_voucher();
			update_stock_transfer_voucher();
			new_stock_transfer_modal();
			//cancel_stock_transfer_modal();
			add_stock_transfer_item_row();
			get_stock_transfer_item_category();
			delete_stock_transfer_item_row();
			//stock_transfer_modal_direct();
			//stock_transfer_batch_list();
		//STOCK ADJUSTMENT
			new_stock_adjustment_modal();
			add_stock_adjustment_item_row();
			clear_adjustment_qty_in_or_out();
			cancel_stock_adjustment_modal();
			delete_stock_adjustment_item_row();
			save_stock_adjustment_voucher();
			edit_stock_adjustment_voucher();
			update_stock_adjustment_voucher();
			get_stock_adjustment_item_category();
			delete_stock_adjustment();
		//STOCK REPORT
			stock_report_modal();
			stock_report_display();
			stock_report_item_tally_card();
		//TALLY CARD
			stock_item_tally_card_modal();
			stock_item_tally_card_get_category();
			stock_item_tally_card_display();
		//SITE REPORT
			site_report_modal();
			site_report_display();
			site_report_item_tally_card();
		//ASSET REPORT
			asset_report_modal();
			asset_report_display();
			asset_report_item_tally_card();
});

//SETUP
	//OTHERS
		/*function isEmail(email) {
		  var regex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
		  //var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,6})+$/;
		  return regex.test(email);
		}*/
	//COMPANY
		function company_new_modal()
		{
			$(document).on('click','#new_company_icon',function()
			{
				var user_super_id = $('#session_user_super_id').val();
				$('#user_super_id').val(user_super_id);
				$('#sms').val('No');
				$('#company_create_modal_header').html('Company Setup');
				$('#company_create_form').trigger('reset');
				$('#company_update_btn').hide();
				$('#company_save_btn').show();
				$('#company_status').val('Active');
				$('#company_create_modal').modal('show');
			}) 
		}

		function company_open()
		{
			$(document).on('click','#btn_open_company',function(){
				var company_id = $(this).attr('data-id');
				var company_type_id = $(this).attr('data-id3');
				var company_sms = $(this).attr('data-id4');
				$.ajax({
		             url:'/layout/items/company_open.php',
		             method:'POST',
					 datatype: 'JSON',
		             data:{
						company_id:company_id, 
						company_type_id:company_type_id, 
						company_sms:company_sms
					},
					success:function(data)
					{
						var res = $.parseJSON(data);
						if(res[2] == 'Open')
						{
							window.location.href="/welcome.php";
						}
						else if(res[2] == 'Expired_Closed')
						{
							alert('The Company subscription has expired on '+ res[1]+' and login blocked. Please the Administrator!');
						}
						else if(res[2] == 'Expired_Grace')
						{
							alert('The Company subscription has expired '+res[1]+', login will be blocked on '+res[0]+'. Please the Administrator!');
							window.location.href="/welcome.php";
						};
					}
		        });	
			});
		}

		function company_save()
		{
			$(document).on('click','#company_save_btn',function(e){
				var user_super_id = $('#session_user_super_id').val();
				var trading_name = $('#trading_name').val();
				var legal_name = $('#legal_name').val();
				var location = $('#location').val();
				var currency = $('#currency').val();
				var email = $('#email').val();
				var telephone = $('#telephone').val();
				var momo_phone = $('#momo_phone').val();
				var company_type_id = $('#company_type_id').val();

				e.preventDefault();
				if (trading_name !== "") 
				{
					if (legal_name !== "") 
					{
						if (location !== "") 
						{
							if (currency !== "") 
							{
								if (telephone !== "") 
								{
									if (company_type_id !== "" && company_type_id > 0) 
									{
										$.ajax({
											url:'/layout/items/company_save.php',
											method:'POST',
											data:$('#company_create_form').serialize(),
											success:function(data)
											{
												$('#company_create_form').trigger('reset');
												$('#company_create_modal').modal('hide');
												window.location.href="/layout/items/company_list.php";
											}
								        });	
									} 
									else 
									{
										$('#company_warning_div').html('<h6 style=color:red;>Please the Company Type cannot be EMPTY!</h6>');
										$('#company_warning_div').hide().slideDown().delay(2000).fadeOut();
									}
								} 
								else 
								{
									$('#company_warning_div').html('<h6 style=color:red;>Please the Telephone cannot be EMPTY!</h6>');
									$('#company_warning_div').hide().slideDown().delay(2000).fadeOut();
								}
							} 
							else 
							{
								$('#company_warning_div').html('<h6 style=color:red;>Please the Currency cannot be EMPTY!</h6>');
								$('#company_warning_div').hide().slideDown().delay(2000).fadeOut();
							}
						} 
						else 
						{
							$('#company_warning_div').html('<h6 style=color:red;>Please the Location cannot be EMPTY!</h6>');
							$('#company_warning_div').hide().slideDown().delay(2000).fadeOut();
						}
					} 
					else 
					{
						$('#company_warning_div').html('<h6 style=color:red;>Please the Legal Name cannot be EMPTY!</h6>');
						$('#company_warning_div').hide().slideDown().delay(2000).fadeOut();
					}
				} 
				else 
				{
					$('#company_warning_div').html('<h6 style=color:red;>Please the Trading Name cannot be EMPTY!</h6>');
					$('#company_warning_div').hide().slideDown().delay(2000).fadeOut();
				}
			});
		}

		function company_edit()
		{
			$(document).on('click','#btn_edit_company',function()
			{
				var company_id = $(this).attr('data-id');
				$.ajax({  
			             url:'/layout/items/company_edit.php',  
			             method:'POST',  
			             data:{
			             	company_id:company_id
			             },
			             datatype: 'JSON',
			             success:function(data){
		                 	var res = $.parseJSON(data);
		                 	$('#company_id').val(res[0]);
		                 	$('#trading_name').val(res[1]);
		                 	$('#legal_name').val(res[2]);
		                 	$('#company_logo_file').val(res[3]);
		                 	$('#address').val(res[4]);
		                 	$('#location').val(res[5]);
		                 	$('#gps').val(res[6]);
		                 	$('#telephone').val(res[7]);
		                 	$('#whatsapp_phone').val(res[8]);
		                 	$('#momo_phone').val(res[9]);
		                 	$('#email').val(res[10]);
		                 	$('#website').val(res[11]);
		                 	$('#admin_username').val(res[12]);
		                 	$('#admin_email').val(res[13]);
		                 	$('#admin_password').val(res[14]);
		                 	$('#currency').val(res[15]);
		                 	$('#company_type_id').val(res[16]);
		                 	$('#company_status').val(res[17]);
		                 	$('#sms').val(res[18]);
		                 	$('#company_create_modal_header').html('Company Edit');
							$('#company_update_btn').show();
							$('#company_save_btn').hide();
			             	$('#company_create_modal').modal('show');
			             }  
		        	});
			});
		}

		function company_update()
		{
			$(document).on('click','#company_update_btn',function(e){
				e.preventDefault();
			    var user_super_id = $('#session_user_super_id').val();
				var trading_name = $('#trading_name').val();
				var legal_name = $('#legal_name').val();
				var location = $('#location').val();
				var currency = $('#currency').val();
				var email = $('#email').val();
				var telephone = $('#telephone').val();
				var momo_phone = $('#momo_phone').val();
				var company_type_id = $('#company_type_id').val();
				if (trading_name !== "") 
				{
					if (legal_name !== "") 
					{
						if (location !== "") 
						{
							if (currency !== "") 
							{
								if (telephone !== "") 
								{
									if (company_type_id !== "" && company_type_id > 0) 
									{
										
										$.ajax({
											url:'/layout/items/company_update.php',
											method:'POST',
											data:$('#company_create_form').serialize(),
											success:function(data)
											{
												$('#company_create_form').trigger('reset');
												$('#company_create_modal').modal('hide');
												window.location.href="/layout/items/company_list.php";
											}
								        });	
									} 
									else 
									{
										$('#company_warning_div').html('<h6 style=color:red;>Please the Company Type cannot be EMPTY!</h6>');
										$('#company_warning_div').hide().slideDown().delay(2000).fadeOut();
									}
								} 
								else 
								{
									$('#company_warning_div').html('<h6 style=color:red;>Please the Telephone cannot be EMPTY!</h6>');
									$('#company_warning_div').hide().slideDown().delay(2000).fadeOut();
								}
							} 
							else 
							{
								$('#company_warning_div').html('<h6 style=color:red;>Please the Currency cannot be EMPTY!</h6>');
								$('#company_warning_div').hide().slideDown().delay(2000).fadeOut();
							}
						} 
						else 
						{
							$('#company_warning_div').html('<h6 style=color:red;>Please the Location cannot be EMPTY!</h6>');
							$('#company_warning_div').hide().slideDown().delay(2000).fadeOut();
						}
					} 
					else 
					{
						$('#company_warning_div').html('<h6 style=color:red;>Please the Legal Name cannot be EMPTY!</h6>');
						$('#company_warning_div').hide().slideDown().delay(2000).fadeOut();
					}
				} 
				else 
				{
					$('#company_warning_div').html('<h6 style=color:red;>Please the Trading Name cannot be EMPTY!</h6>');
					$('#company_warning_div').hide().slideDown().delay(2000).fadeOut();
				}
			});
		}

		function company_lock_unlock()
		{
			$(document).on('click','#btn_lock_company, #btn_unlock_company',function(e){
				e.preventDefault();
			    var company_id = $(this).attr('data-id');
			    var status = $(this).attr('data-id1');
				$.ajax({
					url:'/layout/items/company_lock.php',
					method:'POST',
					data:{company_id:company_id,status:status},
					success:function(data)
					{
						window.location.href="/layout/items/company_list.php";
					}
				});	
			});	
		}

		function company_subscription_open()
		{
			$(document).on('click','#btn_subscription_open',function()
			{
				var company_id = $(this).attr('data-id');
				
				$.ajax({
					url:'/layout/items/company_subscription_modal_show.php',
					method:'POST',
					data:{company_id:company_id},
					success:function(data)
					{
						window.location.href="/layout/items/company_subscription.php";
					}
				});
			}) 
		}

		function company_subscription_modal()
		{
			$(document).on('click','#btn_subscription_company',function()
			{
				var company_id = $(this).attr('data-id');
				$('#company_subscription_modal_header').html('Company Subscription Form');
				$('#company_subscription_form').trigger('reset');
				$('#company_subscription_company_id').val(company_id);
				$('#company_subscription_company_idD').val(company_id);
				$('#company_sub_update_btn').hide();
				$('#company_sub_save_btn').show();
				$('#company_subscription_modal').modal('show');
			}) 
		}

		function company_subscription_set_amount()
		{
			$(document).on('keyup','#price, #no_of_months, #exchange_rate',function()
			{
				var price = $('#price').val();
				var no_of_months = $('#no_of_months').val();
				var exchange_rate = $('#exchange_rate').val();
				var amount_dollar = price *no_of_months;
				var amount_cedi = amount_dollar *exchange_rate;
				$('#amount_dollar').val(amount_dollar);
				$('#amount_dollarD').val(amount_dollar);
				$('#amount_cedi').val(amount_cedi);
				$('#amount_cediD').val(amount_cedi);
			}) 
		}

		function company_subscription_set_expiry_date()
		{
			$(document).on('change','#start_date',function()
			{
				var start_date = $('#start_date').val();
				var no_of_months = $('#no_of_months').val();
				var d = new Date(start_date);
				var day = d.getDate();
				var month = d.getMonth();

				//EXPIRY DATE
				var month = parseInt(month) + parseInt(no_of_months) + parseInt(1);
				var year = d.getFullYear();
				var date = year+'-'+month+'-'+day;
				var datetime = new Date(date);
				var expiry_date = moment(datetime).format("YYYY-MM-DD");
				$('#expiry_date').val(expiry_date);

				//GRACE PERIOD
				var month2 = parseInt(month) + parseInt(1);
				var date2 = year+'-'+month2+'-'+day;
				var datetime2 = new Date(date2);
				var grace_date = moment(datetime2).format("YYYY-MM-DD");
				$('#date_grace').val(grace_date);
			}) 
		}
		
		function company_subscription_save()
		{
			$(document).on('click','#company_sub_save_btn',function(e){
				var price = $('#price').val();
				var no_of_months = $('#no_of_months').val();
				var exchange_rate = $('#exchange_rate').val();
				var start_date = $('#start_date').val();
				var expiry_date = $('#expiry_date').val();
				var date_grace = $('#date_grace').val();

				e.preventDefault();
				if (price !== "") 
				{
					if (no_of_months != "") 
					{
						if (exchange_rate != "") 
						{
							if (start_date != "") 
							{
								if (expiry_date != "") 
								{
									if (date_grace != "") 
									{
										if (expiry_date > start_date) 
										{
											if (date_grace > expiry_date) 
											{
												$.ajax({
													url:'/layout/items/company_subscription_save.php',
													method:'POST',
													data:$('#company_subscription_form').serialize(),
													success:function(data)
													{
														$('#company_subscription_form').trigger('reset');
														$('#company_subscription_modal').modal('hide');
														window.location.href="/layout/items/company_subscription.php";
													}
												});
											} 
											else 
											{
												$('#company_warning_div').html('<h6 style=color:red;>Please the Grace Period cannot be earlier than the Expiry Date!</h6>');
												$('#company_warning_div').hide().slideDown().delay(2000).fadeOut();
											}
										} 
										else 
										{
											$('#company_warning_div').html('<h6 style=color:red;>Please the Expiry Date cannot be earlier than the Start Date!</h6>');
											$('#company_warning_div').hide().slideDown().delay(2000).fadeOut();
										}
									} 
									else 
									{
										$('#company_warning_div').html('<h6 style=color:red;>Please the Expiry Date cannot be EMPTY!</h6>');
										$('#company_warning_div').hide().slideDown().delay(2000).fadeOut();
									}
								} 
								else 
								{
									$('#company_warning_div').html('<h6 style=color:red;>Please the Expiry Date cannot be EMPTY!</h6>');
									$('#company_warning_div').hide().slideDown().delay(2000).fadeOut();
								}
							} 
							else 
							{
								$('#company_warning_div').html('<h6 style=color:red;>Please the Start Date cannot be EMPTY!</h6>');
								$('#company_warning_div').hide().slideDown().delay(2000).fadeOut();
							}
						} 
						else 
						{
							$('#company_warning_div').html('<h6 style=color:red;>Please the Exchange Rate cannot be EMPTY!</h6>');
							$('#company_warning_div').hide().slideDown().delay(2000).fadeOut();
						}
					} 
					else 
					{
						$('#company_warning_div').html('<h6 style=color:red;>Please the No Of Months cannot be EMPTY!</h6>');
						$('#company_warning_div').hide().slideDown().delay(2000).fadeOut();
					}
				} 
				else 
				{
					$('#company_warning_div').html('<h6 style=color:red;>Please the Bill Rate cannot be EMPTY!</h6>');
					$('#company_warning_div').hide().slideDown().delay(2000).fadeOut();
				}
			});
		}

		function company_subscription_edit()
		{
			$(document).on('click','#btn_edit_subscription',function()
			{
				var sub_bill_id = $(this).attr('data-id');
				$.ajax({
						url:'/layout/items/company_subscription_edit.php',  
						method:'POST',  
						data:{sub_bill_id:sub_bill_id},
						datatype: 'JSON',
						success:function(data){
							var res = $.parseJSON(data);
							$('#sub_bill_id').val(res[0]);
							$('#company_subscription_company_id').val(res[1]);
							$('#price').val(res[2]);
							$('#no_of_months').val(res[3]);
							$('#exchange_rate').val(res[4]);
							$('#start_date').val(res[5]);
							$('#amount_dollar').val(res[6]);
							$('#amount_dollarD').val(res[6]);
							$('#amount_cedi').val(res[7]);
							$('#amount_cediD').val(res[7]);
							$('#expiry_date').val(res[8]);
							$('#date_grace').val(res[9]);
							$('#company_subscription_modal_header').html('Edit Subscription');
							$('#company_sub_update_btn').show();
							$('#company_sub_save_btn').hide();
							$('#company_subscription_modal').modal('show');
						}
		        });
			});
		}
		
		function company_subscription_update()
		{
			$(document).on('click','#company_sub_update_btn',function(e){
				var price = $('#price').val();
				var no_of_months = $('#no_of_months').val();
				var exchange_rate = $('#exchange_rate').val();
				var start_date = $('#start_date').val();
				var expiry_date = $('#expiry_date').val();
				var date_grace = $('#date_grace').val();

				e.preventDefault();
				if (price !== "") 
				{
					if (no_of_months != "") 
					{
						if (exchange_rate != "") 
						{
							if (start_date != "") 
							{
								if (expiry_date != "") 
								{
									if (date_grace != "") 
									{
										if (expiry_date > start_date) 
										{
											if (date_grace > expiry_date) 
											{
												$.ajax({
													url:'/layout/items/company_subscription_update.php',
													method:'POST',
													data:$('#company_subscription_form').serialize(),
													success:function(data)
													{
														$('#company_subscription_form').trigger('reset');
														$('#company_subscription_modal').modal('hide');
														window.location.href="/layout/items/company_subscription.php";
													}
												});
											} 
											else 
											{
												$('#company_warning_div').html('<h6 style=color:red;>Please the Grace Period cannot be earlier than the Expiry Date!</h6>');
												$('#company_warning_div').hide().slideDown().delay(2000).fadeOut();
											}
										} 
										else 
										{
											$('#company_warning_div').html('<h6 style=color:red;>Please the Expiry Date cannot be earlier than the Start Date!</h6>');
											$('#company_warning_div').hide().slideDown().delay(2000).fadeOut();
										}
									} 
									else 
									{
										$('#company_warning_div').html('<h6 style=color:red;>Please the Expiry Date cannot be EMPTY!</h6>');
										$('#company_warning_div').hide().slideDown().delay(2000).fadeOut();
									}
								} 
								else 
								{
									$('#company_warning_div').html('<h6 style=color:red;>Please the Expiry Date cannot be EMPTY!</h6>');
									$('#company_warning_div').hide().slideDown().delay(2000).fadeOut();
								}
							} 
							else 
							{
								$('#company_warning_div').html('<h6 style=color:red;>Please the Start Date cannot be EMPTY!</h6>');
								$('#company_warning_div').hide().slideDown().delay(2000).fadeOut();
							}
						} 
						else 
						{
							$('#company_warning_div').html('<h6 style=color:red;>Please the Exchange Rate cannot be EMPTY!</h6>');
							$('#company_warning_div').hide().slideDown().delay(2000).fadeOut();
						}
					} 
					else 
					{
						$('#company_warning_div').html('<h6 style=color:red;>Please the No Of Months cannot be EMPTY!</h6>');
						$('#company_warning_div').hide().slideDown().delay(2000).fadeOut();
					}
				} 
				else 
				{
					$('#company_warning_div').html('<h6 style=color:red;>Please the Bill Rate cannot be EMPTY!</h6>');
					$('#company_warning_div').hide().slideDown().delay(2000).fadeOut();
				}
			});
		}

		function company_subscription_delete()
		{
			$(document).on('click','#btn_delete_subscription',function(){
				var sub_bill_id = $(this).attr('data-id');
				var currentRow=$(this).closest("tr");
				var expiry_date = currentRow.find("td:eq(2)").text();
				//var Supplier = currentRow.find("td:eq(3)").text();
				$('#subscription_delete_question').text('Are you sure you want to delete subscription of ' + expiry_date + '?');
				$('#subscription_delete_modal').modal('show');
				$(document).on('click','#subscription_delete_yes',function(){
					$.ajax({  
		                 url:'/layout/items/company_subscription_delete.php',  
		                 type:'POST',  
		                 data:{sub_bill_id:sub_bill_id},
		                 success:function()
						 {
		                 	$('#subscription_delete_modal').modal('hide');
		                 	window.location.href="/layout/items/company_subscription.php";
		                 }
		            });
			      });
				$(document).on('click','#subscription_delete_no',function(){
					$('#subscription_delete_modal').modal('hide');
				});
			});
		}
		
	//BRANCH
		function branch_new_modal()
		{
			$(document).on('click','#new_branch_icon',function()
			{
				var user_super_id = $('#session_user_super_id').val();
				$('#user_super_id').val(user_super_id);
				$('#sms').val('No');
				$('#branch_create_modal_header').html('Branch Setup');
				$('#branch_create_form').trigger('reset');
				$('#branch_update_btn').hide();
				$('#branch_save_btn').show();
				$('#beanch_status').val('Active');
				$('#branch_create_modal').modal('show');
			}) 
		}

		function branch_save()
		{
			$(document).on('click','#branch_save_btn',function(e){
				var branch_name = $('#branch_name').val();
				e.preventDefault();
				if (branch_name !== "")
				{
					$.ajax({
						url:'/layout/items/branch_save.php',
						method:'POST',
						data:$('#branch_create_form').serialize(),
						success:function(data)
						{
							$('#branch_create_form').trigger('reset');
							$('#branch_create_modal').modal('hide');
							window.location.href="/layout/items/branch_list.php";
						}
					});	
				} 
				else 
				{
					$('#branch_create_form_msg').html('<h6 style=color:red;>Please the Branch Name cannot be EMPTY!</h6>');
					$('#branch_create_form_msg').hide().slideDown().delay(2000).fadeOut();
				};
			});
		}

		function branch_edit()
		{
			$(document).on('click','#btn_edit_branch',function()
			{
				var branch_id = $(this).attr('data-id');
				$.ajax({  
					url:'/layout/items/branch_edit.php',  
					method:'POST',  
					data:{
					branch_id:branch_id
					},
					datatype: 'JSON',
					success:function(data)
					{
						var res = $.parseJSON(data);
						$('#branch_id').val(res[0]);
						$('#branch_company_id').val(res[1]);
						$('#branch_name').val(res[2]);
						$('#branch_address').val(res[3]);
						$('#branch_location').val(res[4]);
						$('#branch_telephone').val(res[5]);
						$('#branch_email').val(res[6]);
						$('#branch_warehouse').val(res[7]);
						$('#branch_cash_ledger').val(res[8]);
						$('#branch_create_modal_header').html('Branch Edit');
						$('#branch_update_btn').show();
						$('#branch_save_btn').hide();
						$('#branch_create_modal').modal('show');
					}
				});
			});
		}

		function branch_update()
		{
			$(document).on('click','#branch_update_btn',function(e){
				var branch_name = $('#branch_name').val();
				e.preventDefault();
				if (branch_name !== "")
				{
					$.ajax({
						url:'/layout/items/branch_update.php',
						method:'POST',
						data:$('#branch_create_form').serialize(),
						success:function(data)
						{
							$('#branch_create_form').trigger('reset');
							$('#branch_create_modal').modal('hide');
							window.location.href="/layout/items/branch_list.php";
						}
					});	
				} 
				else 
				{
					$('#branch_create_form_msg').html('<h6 style=color:red;>Please the Branch Name cannot be EMPTY!</h6>');
					$('#branch_create_form_msg').hide().slideDown().delay(2000).fadeOut();
				};
			});
		}

	//USER_ULTRA_SUPER
		function user_ultra_super_new_modal()
		{
			$(document).on('click','#new_user_ultra_super_icon',function()
			{
				$('#user_ultra_super_create_form').trigger('reset');
				$('#user_ultra_super_update_btn').hide();
				$('#user_ultra_super_save_btn').show();
				$('#user_ultra_super_create_modal').modal('show');
			});
		}

		function user_ultra_super_save()
		{
			$(document).on('click','#user_ultra_super_save_btn',function(e){
				e.preventDefault();
				var name = $('#user_ultra_super_name').val();
				var email = $('#user_ultra_super_email').val();
				var password = $('#user_ultra_super_password').val();
				if (email !== '') 
				{
					if (name !== '') 
					{
						if (password !== '') 
						{
							$.ajax({
					             url:'/layout/items/user_ultra_super_save.php',
					             method:'POST',
					             data:$('#user_ultra_super_create_form').serialize(),
					             success:function(data)
					             {
					             	if (data == 'exist')
					             	{
					             		$('#user_form_msg').html('<h4 style=color:red;>Email NOT available!</h4>');
										$('#user_form_msg').hide().slideDown().delay(2000).fadeOut();
					             	} 
					             	else if (data == 'inserted')
					             	{
						             	$('#user_ultra_super_create_form').trigger('reset');
				             			$('#user_ultra_super_create_modal').modal('hide');
				             			window.location.href="/layout/items/user_ultra_super_list.php";
					             	};
					             }
					        });
						} 
						else 
						{
							$('#user_ultra_super_form_msg').html('<h6 style=color:red;>The Password cannot be EMPTY!</h6>');
							$('#user_ultra_super_form_msg').hide().slideDown().delay(2000).fadeOut();
						};
					} 
					else 
					{
						$('#user_ultra_super_form_msg').html('<h6 style=color:red;>The Name cannot be EMPTY!</h6>');
						$('#user_ultra_super_form_msg').hide().slideDown().delay(2000).fadeOut();
					};
				} 
				else 
				{
					$('#user_ultra_super_form_msg').html('<h6 style=color:red;>The Email cannot be EMPTY!</h6>');
					$('#user_ultra_super_form_msg').hide().slideDown().delay(2000).fadeOut();
				};
			});
		}

		function user_ultra_super_edit()
		{
			$(document).on('click','#btn_edit_user_ultra_super',function()
			{
				var user_id = $(this).attr('data-id');
				$.ajax({  
			             url:'/layout/items/user_ultra_super_edit.php',  
			             method:'POST',  
			             data:{
			             	user_id:user_id
			             },
			             datatype: 'JSON',
			             success:function(data){
		                 	var res = $.parseJSON(data);
		                 	$('#user_ultra_super_id').val(res[0]);
		                 	$('#user_ultra_super_name').val(res[1]);
		                 	$('#user_ultra_super_email').val(res[2]);
			             }  
		        	});
			});
		}

		function user_ultra_super_update()
		{
			$(document).on('click','#user_ultra_super_update_btn',function(e){
				e.preventDefault();
				var user_type = $('#user_type').val();
				var telephone = $('#telephone').val();
				var first_name = $('#first_name').val();
				var email = $('#email').val();
				if (email !== '') 
				{
					if (first_name !== '') 
					{
						if (user_type !== '') 
						{
							if (telephone !== '') 
							{
								$.ajax({
						             url:'/layout/items/user_update.php',
						             method:'POST',
						             data:$('#user_create_form').serialize(),
						             success:function(data)
							             {
							             	if (data == 'exist')
							             	{
							             		$('#user_form_msg').html('<h4 style=color:red;>Email NOT available!</h4>');
												$('#user_form_msg').hide().slideDown().delay(2000).fadeOut();
							             	} 
							             	else if (data == 'inserted')
							             	{
								             	$('#user_create_form').trigger('reset');
						             			$('#user_create_modal').modal('hide');
						             			window.location.href="/layout/items/user_list.php";
							             	};
							             }
						        });
						    } 
							else 
							{
								$('#user_form_msg').html('<h4 style=color:red;>Telephone cannot be EMPTY!</h4>');
								$('#user_form_msg').hide().slideDown().delay(2000).fadeOut();
							};
						} 
						else 
						{
							$('#user_form_msg').html('<h4 style=color:red;>User Type cannot be EMPTY!</h4>');
							$('#user_form_msg').hide().slideDown().delay(2000).fadeOut();
						};
					} 
					else 
					{
						$('#user_form_msg').html('<h4 style=color:red;>First Name cannot be EMPTY!</h4>');
						$('#user_form_msg').hide().slideDown().delay(2000).fadeOut();
					};
				} 
				else 
				{
					$('#user_form_msg').html('<h4 style=color:red;>Email cannot be EMPTY!</h4>');
					$('#user_form_msg').hide().slideDown().delay(2000).fadeOut();
				};
			});
		}

	//USER TYPES
		function user_type_new_modal()
		{
			$(document).on('click','#new_user_type_icon',function()
			{
				var id = "";
				$.ajax({
					url:'/layout/items/user_type_privilege_list.php',
					method:'POST',
					data:{
		             	id:id
		             },
					success:function(data)
		            {
		             	$('#user_type_create_form').trigger('reset');
		             	$('#user_type_privileges_div').html(data);
						$('#user_type_update_btn').hide();
						$('#user_type_save_btn').show();
						$('#user_type_create_modal').modal('show');
					}
			    });	
			}) 
		}

		function user_type_save()
		{
			$(document).on('click','#user_type_save_btn',function(e){
				e.preventDefault();
				var user_type_desc = $('#user_type_desc').val();
				if (user_type_desc != '') 
				{
					$.ajax({
			             url:'/layout/items/user_type_save.php',
			             method:'POST',
			             data:$('#user_type_create_form').serialize(),
			             success:function(data)
				             {
				             	$('#user_type_create_form').trigger('reset');
		             			$('#user_type_create_modal').modal('hide');
		             			window.location.href="/layout/items/user_type_list.php";
				             }
			        });	
				} 
				else 
				{
						$('#user_type_form_msg').html('<h6 style=color:red;>Description cannot be EMPTY!</h6>');
						$('#user_type_form_msg').hide().slideDown().delay(2000).fadeOut();
				};
					
			});
		}

		function user_type_edit()
		{
			$(document).on('click','#btn_edit_user_type',function()
			{
				var id = $(this).attr('data-id');
				$('#user_type_id').val(id);
				$.ajax({  
		             url:'/layout/items/user_type_edit.php',  
		             method:'POST',  
		             data:{
		             	id:id
		             },
		             datatype: 'JSON',
		             success:function(data){
	                 	var res = $.parseJSON(data);
	                 	$('#user_type_id').val(res[0]);
	                 	$('#user_type_desc').val(res[1]);
	                 	$.ajax({
							url:'/layout/items/user_type_privilege_list.php',
							method:'POST',
							data:{
				             	id:id
				            },
							success:function(data)
				            {
				             	$('#user_type_privileges_div').html(data);
			                 	$('#user_type_create_modal_header').html('User Type Edit');
								$('#user_type_update_btn').show();
								$('#user_type_save_btn').hide();
				             	$('#user_type_create_modal').modal('show');
							}
					    });

		             }  
	        	});
			});
		}

		function user_type_update()
		{
			$(document).on('click','#user_type_update_btn',function(e){
				e.preventDefault();
				var user_type_desc = $('#user_type_desc').val();
				if (user_type_desc != '') 
				{
					$.ajax({
			             url:'/layout/items/user_type_update.php',
			             method:'POST',
			             data:$('#user_type_create_form').serialize(),
			             success:function(data)
				             {
				             	$('#user_type_create_form').trigger('reset');
		             			$('#user_type_create_modal').modal('hide');
		             			window.location.href="/layout/items/user_type_list.php";
				             }
			        });	
				} 
				else 
				{
						$('#user_type_form_msg').html('<h6 style=color:red;>Description cannot be EMPTY!</h6>');
						$('#user_type_form_msg').hide().slideDown().delay(2000).fadeOut();
				};
					
			});
		}

	//USER PRIVILEGES
		function user_privilege_new_modal()
		{
			$(document).on('click','#new_user_privilege_icon',function()
			{
				$('#user_privilege_create_form').trigger('reset');
				$('#user_privilege_update_btn').hide();
				$('#user_privilege_save_btn').show();
				$('#user_privilege_create_modal').modal('show');
			}) 
		}

		function user_privilege_save()
		{
			$(document).on('click','#user_privilege_save_btn',function(e){
				e.preventDefault();
				var user_priv_page_id = $('#user_priv_page_id').val();
				var user_privilege_desc = $('#user_privilege_desc').val();
				if (user_privilege_desc != '') 
				{
					if (user_priv_page_id > 0) 
					{
						$.ajax({
				             url:'/layout/items/user_privilege_save.php',
				             method:'POST',
				             data:$('#user_privilege_create_form').serialize(),
				             success:function(data)
					             {
					             	$('#user_privilege_create_form').trigger('reset');
			             			$('#user_privilege_create_modal').modal('hide');
			             			window.location.href="/layout/items/user_privileges_list.php";
					             }
				        });	
					} 
					else 
					{
							$('#user_privilege_form_msg').html('<h6 style=color:red;>Page cannot be EMPTY!</h6>');
							$('#user_privilege_form_msg').hide().slideDown().delay(2000).fadeOut();
					};
				} 
				else 
				{
						$('#user_privilege_form_msg').html('<h6 style=color:red;>Privilege Description cannot be EMPTY!</h6>');
						$('#user_privilege_form_msg').hide().slideDown().delay(2000).fadeOut();
				};
					
			});
		}

		function user_privilege_edit()
		{
			$(document).on('click','#btn_user_privilege_edit',function()
			{
				var user_priv_id = $(this).attr('data-id');
				$('#user_privilege_id').val(user_priv_id);
				$.ajax({  
		             url:'/layout/items/user_privilege_edit.php',  
		             method:'POST',  
		             data:{
		             	user_priv_id:user_priv_id
		             },
		             datatype: 'JSON',
		             success:function(data){
	                 	var res = $.parseJSON(data);
	                 	$('#user_privilege_id').val(res[0]);
	                 	$('#user_privilege_desc').val(res[1]);
	                 	$('#user_priv_page_id').val(res[2]);
	                 	$('#user_privilege_create_modal_header').html('User Privilege Edit');
						$('#user_privilege_update_btn').show();
						$('#user_privilege_save_btn').hide();
		             	$('#user_privilege_create_modal').modal('show');
		             }  
	        	});
			});
		}

		function user_privilege_update()
		{
			$(document).on('click','#user_privilege_update_btn',function(e){
				e.preventDefault();
				var user_priv_page_id = $('#user_priv_page_id').val();
				var user_privilege_desc = $('#user_privilege_desc').val();
				if (user_privilege_desc != '') 
				{
					if (user_priv_page_id > 0) 
					{
						$.ajax({
				             url:'/layout/items/user_privilege_update.php',
				             method:'POST',
				             data:$('#user_privilege_create_form').serialize(),
				             success:function(data)
					             {
					             	$('#user_privilege_create_form').trigger('reset');
			             			$('#user_privilege_create_modal').modal('hide');
			             			window.location.href="/layout/items/user_privileges_list.php";
					             }
				        });	
					} 
					else 
					{
							$('#user_privilege_form_msg').html('<h6 style=color:red;>Page cannot be EMPTY!</h6>');
							$('#user_privilege_form_msg').hide().slideDown().delay(2000).fadeOut();
					};
				} 
				else 
				{
						$('#user_privilege_form_msg').html('<h6 style=color:red;>Privilege Description cannot be EMPTY!</h6>');
						$('#user_privilege_form_msg').hide().slideDown().delay(2000).fadeOut();
				};
			});
		}

	//USERS
		function user_sign_in()
		{
			$(document).on('click','#user_sign_in',function(e)
			{
				e.preventDefault();
				var email = $('#user_email').val();
				var password = $('#user_password').val();
				if (email != '') 
				{
					if (password != '') 
					{
						$.ajax({
							url:'/layout/items/user_sign_in.php',
							method:'POST',
							data:$('#user_sign_in_form').serialize(),
							datatype: 'JSON',
							success:function(data)
							{
								var res = $.parseJSON(data);
								if (res[2] == 'Normal_User') 
								{
									$('#user_sign_in_form').trigger('reset');
									window.location.href="/welcome.php";
								}
								else if (res[2] == 'Rejected')
								{
									$('#user_sign_in_msg').html('<h6 style=color:red;>User Credential Rejected by the Administrator!</h6>');
									$('#user_sign_in_msg').hide().slideDown().delay(2000).fadeOut();
								}
								else if (res[2] == 'Pending')
								{
									$('#user_sign_in_msg').html('<h6 style=color:red;>User Credential is still Pending Approval by the Administrator!</h6>');
									$('#user_sign_in_msg').hide().slideDown().delay(2000).fadeOut();
								}
								else if (res[2] == 'Revoked')
								{
									$('#user_sign_in_msg').html('<h6 style=color:red;>User Credential has been Revoked by the Administrator!</h6>');
									$('#user_sign_in_msg').hide().slideDown().delay(2000).fadeOut();
								} 
								else if (res[2] == 'Super_User')
								{
									$('#user_sign_in_form').trigger('reset');
									window.location.href="/layout/items/company_list.php";
								} 
								else if (res[2] == 'Ultra_Super_User')
								{
									$('#user_sign_in_form').trigger('reset');
									window.location.href="/layout/items/company_list.php";
								}
								else if (res[2] == 'User_Not_Registered')
								{
									$('#user_sign_in_msg').html('<h6 style=color:red;>Your Email and Password does not match!</h6>');
									$('#user_sign_in_msg').hide().slideDown().delay(2000).fadeOut();
								}
								else if (res[2] == 'Closed')
								{
									$('#user_sign_in_msg').html('<h6 style=color:red;>The Company is closed. Please the Administrator to open!</h6>');
									$('#user_sign_in_msg').hide().slideDown().delay(2000).fadeOut();
								}
								else if (res[2] == 'Expired_Closed')
								{
									$('#user_sign_in_msg').html('<h6 style=color:red;>The Company subscription has expired on '+ res[1]+' and login blocked. Please the Administrator!</h6>');
									$('#user_sign_in_msg').hide().slideDown().delay(2000).fadeOut();
								}
								else if (res[2] == 'Expired_Grace')
								{
									$('#user_sign_in_msg').html('<h6 style=color:red;>The Company subscription has expired '+res[1]+', login will be blocked on '+res[0]+'. Please the Administrator!</h6>');
									$('#user_sign_in_msg').hide().slideDown().delay(2000).fadeOut();
								};
							}
				        });
					}
					else 
					{
						$('#user_sign_in_msg').html('<h6 style=color:red;>Password Cannot Be EMPTY!</h6>');
						$('#user_sign_in_msg').hide().slideDown().delay(2000).fadeOut();
					};
				}
				else 
				{
					$('#user_sign_in_msg').html('<h6 style=color:red;>Email Cannot Be EMPTY!</h6>');
					$('#user_sign_in_msg').hide().slideDown().delay(2000).fadeOut();
				};
			}); 
		}

		function user_new_modal()
		{
			$(document).on('click','#new_user_icon',function()
			{
				var company_id = $('#session_company_id').val();
				var user_super_id = $('#session_user_super_id').val();
				var user_id = "";
				$.ajax({
					url:'/layout/items/user_privilege_list.php',
					method:'POST',
					data:{
		             	user_id:user_id
		             },
					success:function(data)
		            {
		            	$('#user_create_modal_header').html('User Setup');
						$('#user_create_form').trigger('reset');
						$('#ucm_company_id').val(company_id);
						$('#company_id_2').val(company_id);
						$('#company_id3').val(company_id);
						$('#ucm_user_super_id').val(user_super_id);
						$('#user_privileges_div').html(data);
						$('#user_update_btn').hide();
						$('#user_save_btn').show();
						$('#user_create_modal').modal('show');
					}
			    });	
			});
		}

		function user_save()
		{
			$(document).on('click','#user_save_btn',function(e){
				e.preventDefault();
				var user_type = $('#user_type').val();
				var telephone = $('#telephone').val();
				var first_name = $('#first_name').val();
				var email = $('#email').val();
				if (email !== '') 
				{
					if (first_name !== '') 
					{
						if (user_type !== '') 
						{
							if (telephone !== '') 
							{
								$.ajax({
						             url:'/layout/items/user_save.php',
						             method:'POST',
						             data:$('#user_create_form').serialize(),
						             success:function(data)
						             {
						             	if (data == 'exist')
						             	{
						             		$('#user_form_msg').html('<h4 style=color:red;>Email NOT available!</h4>');
											$('#user_form_msg').hide().slideDown().delay(2000).fadeOut();
						             	} 
						             	else if (data == 'inserted')
						             	{
							             	$('#user_create_form').trigger('reset');
					             			$('#user_create_modal').modal('hide');
					             			window.location.href="/layout/items/user_list.php";
						             	};
						             }
						        });
						    } 
							else 
							{
								$('#user_form_msg').html('<h4 style=color:red;>Telephone cannot be EMPTY!</h4>');
								$('#user_form_msg').hide().slideDown().delay(2000).fadeOut();
							};
						} 
						else 
						{
							$('#user_form_msg').html('<h4 style=color:red;>User Type cannot be EMPTY!</h4>');
							$('#user_form_msg').hide().slideDown().delay(2000).fadeOut();
						};
					} 
					else 
					{
						$('#user_form_msg').html('<h4 style=color:red;>First Name cannot be EMPTY!</h4>');
						$('#user_form_msg').hide().slideDown().delay(2000).fadeOut();
					};
				} 
				else 
				{
					$('#user_form_msg').html('<h4 style=color:red;>Email cannot be EMPTY!</h4>');
					$('#user_form_msg').hide().slideDown().delay(2000).fadeOut();
				};
			});
		}

		function user_edit()
		{
			$(document).on('click','#btn_edit_user',function()
			{
				var user_id = $(this).attr('data-id');
				$.ajax({  
			             url:'/layout/items/user_edit.php',  
			             method:'POST',  
			             data:{
			             	user_id:user_id
			             },
			             datatype: 'JSON',
			             success:function(data)
						 {
		                 	var res = $.parseJSON(data);
		                 	$('#ucm_company_id').val(res[0]);
		                 	$('#company_id_2').val(res[0]);
		                 	$('#ucm_user_id').val(res[1]);
		                 	$('#last_name').val(res[2]);
		                 	$('#user_approval_status').val(res[3]);
		                 	$('#email').val(res[4]);
		                 	$('#telephone').val(res[5]);
		                 	$('#address').val(res[6]);
		                 	$('#location').val(res[7]);
		                 	$('#photo').val(res[8]);
		                 	$('#first_name').val(res[9]);
		                 	$('#ucm_user_super_id').val(res[10]);
		                 	$('#user_type').val(res[11]);
		                 	$('#user_branch').val(res[12]);
		                 	$.ajax({
								url:'/layout/items/user_privilege_list.php',
								method:'POST',
								data:{
					             	user_id:user_id
					             },
								success:function(data)
					            {
					             	$('#user_create_modal_header').html('User Edit');
									$('#user_privileges_div').html(data);
									$('#user_update_btn').show();
									$('#user_save_btn').hide();
					            	$.ajax({
							            url:'/layout/items/user_cash_ledger_edit.php',
							            method:'POST',
							            data:{user_id:user_id},
							            success:function(data)
							            {
							            	$('#user_cash_ledger_list').html(data);
										}
						            });
					             	$('#user_create_modal').modal('show');
								}
						    });
			             }  
		        	});
			});
		}

		function user_update()
		{
			$(document).on('click','#user_update_btn',function(e){
				e.preventDefault();
				var user_type = $('#user_type').val();
				var telephone = $('#telephone').val();
				var first_name = $('#first_name').val();
				var email = $('#email').val();
				if (email !== '') 
				{
					if (first_name !== '') 
					{
						if (user_type !== '') 
						{
							if (telephone !== '') 
							{
								$.ajax({
						             url:'/layout/items/user_update.php',
						             method:'POST',
						             data:$('#user_create_form').serialize(),
						             success:function(data)
							             {
							             	if (data == 'exist')
							             	{
							             		$('#user_form_msg').html('<h4 style=color:red;>Email NOT available!</h4>');
												$('#user_form_msg').hide().slideDown().delay(2000).fadeOut();
							             	} 
							             	else if (data == 'inserted')
							             	{
								             	$('#user_create_form').trigger('reset');
						             			$('#user_create_modal').modal('hide');
						             			window.location.href="/layout/items/user_list.php";
							             	};
							             }
						        });
						    } 
							else 
							{
								$('#user_form_msg').html('<h4 style=color:red;>Telephone cannot be EMPTY!</h4>');
								$('#user_form_msg').hide().slideDown().delay(2000).fadeOut();
							};
						} 
						else 
						{
							$('#user_form_msg').html('<h4 style=color:red;>User Type cannot be EMPTY!</h4>');
							$('#user_form_msg').hide().slideDown().delay(2000).fadeOut();
						};
					} 
					else 
					{
						$('#user_form_msg').html('<h4 style=color:red;>First Name cannot be EMPTY!</h4>');
						$('#user_form_msg').hide().slideDown().delay(2000).fadeOut();
					};
				} 
				else 
				{
					$('#user_form_msg').html('<h4 style=color:red;>Email cannot be EMPTY!</h4>');
					$('#user_form_msg').hide().slideDown().delay(2000).fadeOut();
				};
			});
		}

		function user_change_user_type()
		{
			$(document).on('change','#user_type',function()
			{
				var user_type_id = $('#user_type').val();
				$.ajax({
					url:'/layout/items/user_change_user_type.php',
					method:'POST',
					data:{
		             	user_type_id:user_type_id
		             },
					success:function(data)
		            {
						$('#user_privileges_div').html(data);
					}
			    });	
			});
		}

		function add_user_cash_ledger_row()
		{
			$(document).on('change','.user_cash_ledger_id',function(){ 
				var i = $('#user_cash_ledger_list_table tr:last').attr('id');
				i++;
				$.ajax({
					url:'/layout/items/user_cash_ledger_list.php',
					method:'POST',
					data:{i:i},
					success:function(data)
					{
						$('#user_cash_ledger_list_table').append('<tr id="'+i+'">'+data+'</tr>');
					}
				});
			});
		}

		function delete_user_cash_ledger_row()
		{
			$(document).on('click', '#delete_user_cash_ledger', function()
			{
       			var button_id = $(this).attr("data-id");
           		$('#'+button_id+'').remove();
           	});
		}

		function user_change_branch()
		{
			$(document).on('change','.user_change_branch',function(){
				var user_id = $(this).attr('data-id');
				var branch_id = $('#user_change_branch'+user_id).val();
				$.ajax({
					url:'/layout/items/user_change_branch.php',
					type:'POST',  
					data:{user_id:user_id, branch_id:branch_id},
					success:function()
					{
						window.location.href="/layout/items/user_list.php";
					}
				});
		    }); 
		}

	//USERS-ADMIN
		function user_admin_new_sheet()
		{
			$(document).on('click','#u',function(e)
			{
				$('#user_create_modal_header').html('User Setup');
				$('#user_create_form').trigger('reset');
				$('#user_update_btn').hide();
				$('#user_save_btn').show();
				$('#user_create_modal').modal('show');
			}) 
		}

		function user_admin_save()
		{
			$(document).on('click','#user_admin_save_btn',function(e){
				e.preventDefault();
				var name = $('#user_admin_name').val();
				var user_email = $('#user_admin_email').val();
				var user_password = $('#user_admin_password').val();
				var password_confirm = $('#user_admin_password_confirm').val();
				var telephone = $('#user_admin_telephone').val();
				if (name != '') 
				{
					if (user_email != '') 
					{
						if (user_password != '') 
							{
								if (password_confirm != '') 
								{
									if (telephone != '') 
									{
										if (user_password == password_confirm) 
										{
											$.ajax({
												url:'/layout/items/user_admin_save.php',
												method:'POST',
												data:$('#user_admin_create_form').serialize(),
												success:function(data)
												{
													if (data == 'exist')
													{
														$('#user_admin_form_msg').html('<h4 style=color:red;>Email NOT available!</h4>');
														$('#user_admin_form_msg').hide().slideDown().delay(2000).fadeOut();
													}
													else if (data == 'inserted')
													{
			             								$.ajax({
												             url:'/layout/items/user_sign_in.php',
												             method:'POST',
												             data:{user_email:user_email,user_password:user_password},
												             success:function(data)
												             {
												             	window.location.href="/layout/items/company_list.php";
												             }
												        });
													};
												}
									        });
										}
										else
										{
											$('#user_admin_form_msg').html('<h4 style=color:red;>Password does NOT match!</h4>');
										    $('#user_admin_form_msg').hide().slideDown().delay(2000).fadeOut();
										};
									} 
									else 
									{
										$('#user_admin_form_msg').html('<h4 style=color:red;>Telephone cannot be EMPTY!</h4>');
										$('#user_admin_form_msg').hide().slideDown().delay(2000).fadeOut();
									};
								} 
								else 
								{
									$('#user_admin_form_msg').html('<h4 style=color:red;>Password Confirm cannot be EMPTY!</h4>');
									$('#user_admin_form_msg').hide().slideDown().delay(2000).fadeOut();
								};
							} 
							else 
							{
								$('#user_admin_form_msg').html('<h4 style=color:red;>Password cannot be EMPTY!</h4>');
								$('#user_admin_form_msg').hide().slideDown().delay(2000).fadeOut();
							};
					} 
					else 
					{
						$('#user_admin_form_msg').html('<h4 style=color:red;>Email cannot be EMPTY!</h4>');
						$('#user_admin_form_msg').hide().slideDown().delay(2000).fadeOut();
					};
				} 
				else 
				{
					$('#user_admin_form_msg').html('<h4 style=color:red;>Name cannot be EMPTY!</h4>');
					$('#user_admin_form_msg').hide().slideDown().delay(2000).fadeOut();
				};
					
			});
		}

		function user_admin_edit()
		{
			$(document).on('click','#btn_edit_user_admin',function()
			{
				var user_id = $(this).attr('data-id');
				$.ajax({  
			             url:'/layout/items/user_admin_edit.php',  
			             method:'POST',  
			             data:{
			             	user_id:user_id
			             },
			             datatype: 'JSON',
			             success:function(data){
		                 	var res = $.parseJSON(data);
		                 	$('#company_id').val(res[0]);
		                 	$('#user_id').val(res[1]);
		                 	$('#username').val(res[2]);
		                 	$('#password').val(res[3]);
		                 	$('#email').val(res[4]);
		                 	$('#telephone').val(res[5]);
		                 	$('#address').val(res[6]);
		                 	$('#location').val(res[7]);
		                 	$('#photo').val(res[8]);
		                 	$('#full_name').val(res[9]);
		                 	$('#user_create_modal_header').html('User Edit');
							$('#user_update_btn').show();
							$('#user_save_btn').hide();
			             	$('#user_create_modal').modal('show');
			             }  
		        	});
			});
		}

		function user_admin_update()
		{
			$(document).on('click','#user_admin_update_btn',function(e){
				e.preventDefault();
					$.ajax({
			             url:'/layout/items/user_admin_update.php',
			             method:'POST',
			             data:$('#user_create_form').serialize(),
			             success:function(data)
				             {
				             	$('#user_create_form').trigger('reset');
		             			$('#user_create_modal').modal('hide');
		             			window.location.href="/layout/items/user_admin_list.php";
				             }
			        });	
			});
		}

	//USERS-PERSONAL
		function user_personal_new_modal()
		{
			$(document).on('click','#new_user_link',function(e)
			{
				var company_id = $('#session_company_id').val();
				var user_super_id = $('#session_user_super_id').val();
				$('#user_personal_create_modal_header').html('User Setup');
				$('#user_personal_create_form').trigger('reset');
				$('#user_personal_company_id').val(company_id);
				$('#user_personal_company_id_2').val(company_id);
				$('#user_personal_user_super_id').val(user_super_id)
				$('#user_personal_update_btn').hide();
				$('#user_personal_save_btn').show();
				$('#user_personal_create_modal').modal('show');
			}) 
		}

		function user_personal_save()
		{
			$(document).on('click','#user_personal_save_btn',function(e){
				e.preventDefault();
				var name = $('#user_personal_full_name').val();
				var email = $('#user_personal_email').val();
				var password = $('#user_personal_password').val();
				var password_confirm = $('#user_personal_password_confirm').val();
				var telephone = $('#user_personal_telephone').val();
				if (name != '') 
				{
					if (email != '') 
					{
						if (password != '') 
						{
							if (password_confirm != '') 
							{
								if (telephone != '') 
								{
									if (password == password_confirm) 
									{
										$.ajax({
											url:'/layout/items/user_personal_save.php',
											method:'POST',
											data:$('#user_personal_create_form').serialize(),
											success:function(data)
											{
												if (data == 'exist')
												{
													$('#user_personal_form_msg').html('<h6 style=color:red;>Email NOT available!</h6>');
													$('#user_personal_form_msg').hide().slideDown().delay(2000).fadeOut();
												}
												else if (data == 'inserted')
												{
													$('#user_personal_create_form').trigger('reset');
													$('#user_personal_create_modal').modal('hide');
													$('#user_personal_form_msg').html('<h6 style=color:red;>User created successfully!</h6>');
													$('#user_personal_form_msg').hide().slideDown().delay(2000).fadeOut();
												};
											}
								        });
									}
									else
									{
										$('#user_personal_form_msg').html('<h6 style=color:red;>Password does NOT match!</h6>');
									    $('#user_personal_form_msg').hide().slideDown().delay(2000).fadeOut();
									};
								} 
								else 
								{
									$('#user_personal_form_msg').html('<h6 style=color:red;>Telephone cannot be EMPTY!</h6>');
									$('#user_personal_form_msg').hide().slideDown().delay(2000).fadeOut();
								};
							} 
							else 
							{
								$('#user_personal_form_msg').html('<h6 style=color:red;>Password Confirm cannot be EMPTY!</h6>');
								$('#user_personal_form_msg').hide().slideDown().delay(2000).fadeOut();
							};
						} 
						else 
						{
							$('#user_personal_form_msg').html('<h6 style=color:red;>Password cannot be EMPTY!</h6>');
							$('#user_personal_form_msg').hide().slideDown().delay(2000).fadeOut();
						};
					} 
					else 
					{
						$('#user_personal_form_msg').html('<h6 style=color:red;>Email cannot be EMPTY!</h6>');
						$('#user_personal_form_msg').hide().slideDown().delay(2000).fadeOut();
					};
				} 
				else 
				{
					$('#user_personal_form_msg').html('<h6 style=color:red;>Name cannot be EMPTY!</h6>');
					$('#user_personal_form_msg').hide().slideDown().delay(2000).fadeOut();
				};
					
			});
		}

		function user_personal_change_password_modal()
		{
			$(document).on('click','#change_password_link',function(e)
			{
				$('#user_personal_change_password_form').trigger('reset');
				$('#user_personal_change_password_update_btn').show();
				$('#user_personal_change_password_modal').modal('show');
			}) 
		}

		function user_personal_change_password_update()
		{
			$(document).on('click','#user_personal_change_password_update_btn',function(e){
				e.preventDefault();
				var password_old = $('#user_personal_change_password_old').val();
				var password_new = $('#user_personal_change_password_new').val();
				var password_confirm = $('#user_personal_change_password_confirm').val();
				if (password_old != '') 
				{
					if (password_new != '') 
					{
						if (password_confirm != '') 
						{
								if (password_new == password_confirm) 
								{
									$.ajax({
										url:'/layout/items/user_personal_change_password_update.php',
										method:'POST',
										data:$('#user_personal_change_password_form').serialize(),
										success:function(data)
										{
											if (data == 'no_user_match')
											{
												$('#user_personal_change_password_form_msg').html('<h6 style=color:red;>User not found!</h6>');
												$('#user_personal_change_password_form_msg').hide().slideDown().delay(2000).fadeOut();
											}
											else if (data == 'old_password_not_match')
											{
												$('#user_personal_change_password_form_msg').html('<h6 style=color:red;>User old password does not match!</h6>');
												$('#user_personal_change_password_form_msg').hide().slideDown().delay(2000).fadeOut();
											}
											else if (data == 'password_not_updated')
											{
												$('#user_personal_change_password_form_msg').html('<h6 style=color:red;>User password not updated!</h6>');
												$('#user_personal_change_password_form_msg').hide().slideDown().delay(2000).fadeOut();
											}
											else if (data == 'password_updated')
											{
												$('#user_personal_change_password_form').trigger('reset');
												$('#user_personal_change_password_form_msg').html('<h6 style=color:red;>Password updated successfully!</h6>');
												$('#user_personal_change_password_form_msg').hide().slideDown().delay(2000).fadeOut();
												$('#user_personal_change_password_modal').modal('hide');
											};
										}
							        });
								}
								else
								{
									$('#user_personal_change_password_form_msg').html('<h6 style=color:red;>Password does NOT match!</h6>');
								    $('#user_personal_change_password_form_msg').hide().slideDown().delay(2000).fadeOut();
								};
						} 
						else 
						{
							$('#user_personal_change_password_form_msg').html('<h6 style=color:red;>Password Confirm cannot be EMPTY!</h6>');
							$('#user_personal_change_password_form_msg').hide().slideDown().delay(2000).fadeOut();
						};			} 
					else 
					{
						$('#user_personal_change_password_form_msg').html('<h6 style=color:red;>New Password cannot be EMPTY!</h6>');
						$('#user_personal_change_password_form_msg').hide().slideDown().delay(2000).fadeOut();
					};
				} 
				else 
				{
					$('#user_personal_change_password_form_msg').html('<h6 style=color:red;>Old Password cannot be EMPTY!</h6>');
					$('#user_personal_change_password_form_msg').hide().slideDown().delay(2000).fadeOut();
				};
					
			});
		}

		function user_personal_reset_password_modal()
		{
			$(document).on('click','#btn_reset_user',function()
			{
				var user_id = $(this).attr('data-id');
				$('#user_personal_reset_password_form').trigger('reset');
				$('#user_personal_reset_password_user_id').val(user_id);
				$('#user_personal_reset_password_email').val(user_id);
				$('#user_personal_reset_password_email_2').val(user_id);
				$('#user_personal_reset_password_update_btn').show();
				$('#user_personal_reset_password_modal').modal('show');
			});
		}

		function user_personal_reset_password_update()
		{
			$(document).on('click','#user_personal_reset_password_update_btn',function(e){
				e.preventDefault();
				var password_new = $('#user_personal_reset_password_new').val();
				var password_confirm = $('#user_personal_reset_password_confirm').val();
				if (password_new != '') 
				{
					if (password_confirm != '') 
					{
							if (password_new == password_confirm) 
							{
								$.ajax({
									url:'/layout/items/user_personal_reset_password_update.php',
									method:'POST',
									data:$('#user_personal_reset_password_form').serialize(),
									success:function(data)
									{
										if (data == 'no_user_match')
										{
											$('#user_personal_reset_password_form_msg').html('<h6 style=color:red;>User not found!</h6>');
											$('#user_personal_reset_password_form_msg').hide().slideDown().delay(2000).fadeOut();
										}
										else if (data == 'password_do_not_match')
										{
											$('#user_personal_reset_password_form_msg').html('<h6 style=color:red;>User old password does not match!</h6>');
											$('#user_personal_reset_password_form_msg').hide().slideDown().delay(2000).fadeOut();
										}
										else if (data == 'password_not_updated')
										{
											$('#user_personal_reset_password_form_msg').html('<h6 style=color:red;>User password not updated!</h6>');
											$('#user_personal_reset_password_form_msg').hide().slideDown().delay(2000).fadeOut();
										}
										else if (data == 'password_updated')
										{
											$('#user_personal_reset_password_form').trigger('reset');
											$('#user_personal_reset_password_form_msg').html('<h6 style=color:red;>Password updated successfully!</h6>');
											$('#user_personal_reset_password_form_msg').hide().slideDown().delay(2000).fadeOut();
											$('#user_personal_reset_password_modal').modal('hide');
										};
									}
								});
							}
							else
							{
								$('#user_personal_reset_password_form_msg').html('<h6 style=color:red;>Password does NOT match!</h6>');
								$('#user_personal_reset_password_form_msg').hide().slideDown().delay(2000).fadeOut();
							};
					} 
					else 
					{
						$('#user_personal_reset_password_form_msg').html('<h6 style=color:red;>Password Confirm cannot be EMPTY!</h6>');
						$('#user_personal_reset_password_form_msg').hide().slideDown().delay(2000).fadeOut();
					};
				} 
				else 
				{
					$('#user_personal_reset_password_form_msg').html('<h6 style=color:red;>New Password cannot be EMPTY!</h6>');
					$('#user_personal_reset_password_form_msg').hide().slideDown().delay(2000).fadeOut();
				};
			});
		}

	//LEDGER
		function save_ledger()
		{
			$(document).on('click','#ledger_save_btn',function(){
				var company_id = $('#session_company_id').val();
				var user_super_id = $('#session_user_super_id').val();
				var user_id = $('#session_user_id').val();
				$('#company_id').val(company_id);
				$('#user_id').val(user_id);
				$('#user_super_id').val(user_super_id);

				$.ajax({
		             url:'/layout/items/ledger_insert.php',
		             method:'POST',
		             data:$('#ledger_create_form').serialize(),
		             success:function()
		             {
		             	window.location.href="/layout/items/ledger_list.php";
		             }
		        });
		    });
		}

		function tb_2_list()
		{
			$(document).on('change','#tb_1',function()
			{
				var tb_1 = $('#tb_1').val();
				$.ajax(
				{
					url: '/layout/items/tb_2_list.php',
					method: 'POST',
					data: {tb_1:tb_1},
					datatype: 'JSON',
					success: function(data)
					{
						var res = $.parseJSON(data);
						$('#tb_2').html('<option value="0">Please select</option>');
						for (var i=0, l=res.length; i<l;i+=2)
						{
							var oddPositionVal = res[i];
							var evenPositionVal = res[i+1];
							var rowhtml = '<option value=' + oddPositionVal + '>' + evenPositionVal + '</option>';
							$('#tb_2').append(rowhtml);
						}
					}
				});
				
			});
		}

		function tb_3_list()
		{
			$(document).on('change','#tb_2',function()
			{
				var tb_2 = $('#tb_2').val();
				$.ajax(
				{
					url: '/layout/items/tb_3_list.php',
					method: 'POST',
					data: {tb_2:tb_2},
					datatype: 'JSON',
					success: function(data)
					{
						var res = $.parseJSON(data);
						$('#tb_3').html('<option value="0">Please select</option>');
						for (var i=0, l=res.length; i<l;i+=2)
						{
							var oddPositionVal = res[i];
							var evenPositionVal = res[i+1];
							var rowhtml = '<option value=' + oddPositionVal + '>' + evenPositionVal + '</option>';
							$('#tb_3').append(rowhtml);
						}
						if(tb_2 == 1){$('#ledger_opening_state').val('Dr');$('#ledger_opening_state_up').val('Dr');}
						else if(tb_2 == 2){$('#ledger_opening_state').val('Cr');$('#ledger_opening_state_up').val('Cr');}
						else if(tb_2 == 3){$('#ledger_opening_state').val('Cr');$('#ledger_opening_state_up').val('Cr');}
						else if(tb_2 == 4){$('#ledger_opening_state').val('Dr');$('#ledger_opening_state_up').val('Dr');}
					}
				});
			});
		}

		function tb_4_list()
		{
			$(document).on('change','#tb_3',function()
			{
				var tb_3 = $('#tb_3').val();
				$.ajax(
				{
					url: '/layout/items/tb_4_list.php',
					method: 'POST',
					data: {tb_3:tb_3},
					datatype: 'JSON',
					success: function(data)
					{
						var res = $.parseJSON(data);
						$('#tb_4').html('<option value="0">Please select</option>');
						for (var i=0, l=res.length; i<l;i+=2)
						{
							var oddPositionVal = res[i];
							var evenPositionVal = res[i+1];
							var rowhtml = '<option value=' + oddPositionVal + '>' + evenPositionVal + '</option>';
							$('#tb_4').append(rowhtml);
						}
					}
				});
				
			});
		}

		function tb_5_list()
		{
			$(document).on('change','#tb_4',function()
			{
				var tb_4 = $('#tb_4').val();
				$.ajax(
				{
					url: '/layout/items/tb_5_list.php',
					method: 'POST',
					data: {tb_4:tb_4},
					datatype: 'JSON',
					success: function(data)
					{
						var res = $.parseJSON(data);
						$('#tb_5').html('<option value="0">Please select</option>');
						for (var i=0, l=res.length; i<l;i+=2)
						{
							var oddPositionVal = res[i];
							var evenPositionVal = res[i+1];
							var rowhtml = '<option value=' + oddPositionVal + '>' + evenPositionVal + '</option>';
							$('#tb_5').append(rowhtml);
						}
					}
				});
				
			});
		}

		function show_ledger_type()
		{
			$(document).on('change','#tb_5',function()
			{
				var tb_5 = $('#tb_5').val();
				
				if (tb_5==1){
					$('#ledger_type_div').show();
					$("ledger_type_div").addClass("col-md-4 mb-4");
					$("ledger_code_div").addClass("col-md-2 mb-2");
				}
				else{
					$('#ledger_type_div').hide();
					$("ledger_code_div").addClass("col-md-6 mb-6");
				}
				
			});
		}

		function new_ledger_modal()
		{
			$(document).on('click','#new_ledger_icon',function()
			{
				var company_id = $('#session_company_id').val();
				var user_super_id = $('#session_user_super_id').val();
				var user_id = $('#session_user_id').val();
				$('#ledger_create_form').trigger('reset');
				$('#ledger_company_id').val(company_id);
				$('#ledger_user_super_id').val(user_super_id);
				$('#ledger_user_id').val(user_id);

				$('#ledger_create_modal_header').html('Ledger Setup');
				$('#ledger_update_btn').hide();
				$('#ledger_execute_btn').hide();
				$('.trial_balance_group').show();
				$('#ledger_save_btn').show();
				$('#ledgercreatemodal').modal('show');
			}) 
		}

		function ledger_modal()
		{
			$(document).on('click','#new_customer_ledger, #new_supplier_ledger, #new_cash_ledger, #new_bank_ledger, #new_expense_ledger',function()
			{
				var type = $(this).attr('data-id');
				var company_id = $('#session_company_id').val();
				var user_super_id = $('#session_user_super_id').val();
				var user_id = $('#session_user_id').val();
				$('#ledger_create_form').trigger('reset');
				$('#ledger_company_id').val(company_id);
				$('#ledger_user_super_id').val(user_super_id);
				$('#ledger_user_id').val(user_id);
				$('.trial_balance_group').hide();
				if(type == 'customer')
				{
					$('#ledger_create_modal_header').html('Customer/Debtor Setup');
					$('#ledger_type').val('customer');
					$('#ledger_opening_state').val('Dr');
				}else if(type == 'supplier')
				{
					$('#ledger_create_modal_header').html('Supplier/Creditor Setup');
					$('#ledger_type').val('supplier');
					$('#ledger_opening_state').val('Cr');
				}else if(type == 'cash')
				{
					$('#ledger_create_modal_header').html('Cash Account Setup');
					$('#ledger_type').val('cash');
					$('#ledger_opening_state').val('Dr');
				}else if(type == 'bank')
				{
					$('#ledger_create_modal_header').html('Bank Account Setup');
					$('#ledger_type').val('bank');
					$('#ledger_opening_state').val('Dr');
				}else if(type == 'expense')
				{
					$('#ledger_create_modal_header').html('Expense Ledger Setup');
					$('#ledger_type').val('expense');
					$('#ledger_opening_state').val('Dr');
				};

				$('#ledger_update_btn').hide();
				$('#ledger_save_btn').hide();
				$('#ledger_execute_btn').show();
				$('#ledgercreatemodal').modal('show');
			});
		}

		function execute_ledger()
		{
			$(document).on('click','#ledger_execute_btn',function(){
				$.ajax({
					url:'/layout/items/ledger_execute.php',
					method:'POST',
					data:$('#ledger_create_form').serialize(),
					success:function()
					{
						window.location.href="/layout/items/ledger_list.php";
					}
		        });
		    });
		}

		function edit_ledger()
		{
			$(document).on('click','#btn_edit_ledger',function()
			{
				var ledger_id = $(this).attr('data-id');
				$.ajax(
				{
					url: '/layout/items/ledger_get_data.php',
					method: 'POST',
					data: {ledger_id:ledger_id},
					datatype: 'JSON',
					success: function(data)
					{
						var res = $.parseJSON(data);
						$('#ledgerid_up').val(res[0]);
						$('#ledgerdesc_up').val(res[1]);
						$('#ledgerCode_up').val(res[2]);
						$('#tb_1_up').val(res[3]);
						$('#tb_2_up').val(res[5]);
						$('#tb_3_up').val(res[7]);
						$('#tb_4_up').val(res[9]);
						$('#tb_5_up').val(res[11]);
						$('#ledgertype_up').val(res[13]);
						$('#ledgeraddress_up').val(res[14]);
						$('#ledgeremail_up').val(res[15]);
						$('#ledgerphone_up').val(res[16]);
						$('#ledgerstatus_up').val(res[17]);
						$('#show_balance_up').val(res[18]);
						$('#ledger_edit_modal_header').html('Ledger Update');
						if (res[11] == 1)
						{
							$('#ledger_type_div_up').show();
							$("ledger_type_div_up").addClass("col-md-4 mb-4");
							$("ledger_code_div_up").addClass("col-md-2 mb-2");
						}
						else{
							$('#ledger_type_div_up').hide();
							$("ledger_code_div_up").addClass("col-md-6 mb-6");
						};
						$('#ledger_opening_balance_up').val(res[19]);
						$('#ledger_opening_date_up').val(res[20]);
						$('#ledger_opening_state_up').val(res[21]);
						$('#ledger_update_btn').show();
						$('#ledger_save_btn').hide();
						$('#ledgereditmodal').modal('show');
					}
				})
			}) 
		}

		function update_ledger()
		{
			$(document).on('click','#ledger_update_btn',function(){
				$.ajax({
					url:'/layout/items/ledger_update.php',
					method:'POST',
					data:$('#ledger_edit_form').serialize(),
					success:function()
					{
						window.location.href="/layout/items/ledger_list.php";
					}
		        });
		    });
		}

		function search_ledger_by_name()
		{
			$(document).on('keyup','#ledger_search',function(e){
				e.preventDefault();
				var company_id = $('#session_company_id').val();
				var ledger_search = $('#ledger_search').val();

				$.ajax({
		             url:'/layout/items/ledger_search_by_name.php',
		             method:'POST',
		             data:{ledger_search:ledger_search,company_id:company_id},
		             success:function(data)
		             {
		             	$('#ledger_list_card_body').html(data);
		             }
		        });
			});
		}

		function ledger_help()
		{
			$(document).on('click','#new_ledger_help',function(e){
				window.open('/help/ledger_help.pdf', '_blank');
			});
		}
		
		function delete_ledger()
		{
			$(document).on('click','#btn_delete_ledger',function(){
				var ledger_id = $(this).attr('data-id');
				var currentRow=$(this).closest("tr");
				var ledger = currentRow.find("td:eq(1)").text();
				$('#item_delete_modal_title').text('Ledger Deletion!');
				$('#item_delete_question').text('Are you sure you want to delete ' + ledger + '?');
				$('#item_delete_modal').modal('show');
				$(document).on('click','#item_delete_yes',function(){
					$.ajax({  
		                 url:'/layout/items/ledger_delete.php',  
		                 type:'POST',  
		                 data:{ledger_id:ledger_id},
		                 success:function(data)
						 {
							if(data == 'deleted')
							{
								$('#item_delete_question').text(ledger +' deleted successfully!');
								$('#item_delete_no').hide();
								$('#item_delete_yes').text('OK');
								$(document).on('click','#item_delete_yes',function()
								{
									$('#item_delete_modal').modal('hide');
									window.location.href="/layout/items/ledger_list.php";
								})
							}
							else if(data == 'used')
							{
								$('#item_delete_question').text(ledger +' has been used for transactions, deletion is declined!');
								$('#item_delete_no').hide();
								$('#item_delete_yes').text('OK');
								$(document).on('click','#item_delete_yes',function()
								{
									$('#item_delete_modal').modal('hide');
									window.location.href="/layout/items/ledger_list.php";
								});
							};
		                 }
		            });
			      });
				$(document).on('click','#item_delete_no',function(){
					$('#item_delete_modal').modal('hide');
				});
			});
		}
		
	//CUSTOMER
		function customer_new_modal()
		{
			$(document).on('click','#new_customer_icon',function()
			{
				var type = $(this).attr('data-id');
				$('#customer_create_modal_header').html('Customer Setup');
				$('#customer_create_form').trigger('reset');
				$('#customer_entry_type').val(type);
				$('#customer_update_btn').hide();
				$('#customer_save_btn').show();
				$('#customer_create_modal').modal('show');
			}) 
		}

		function customer_save()
		{
			$(document).on('click','#customer_save_btn',function(e){
				var customer_first_name = $('#customer_first_name').val();
				var customer_sex = $('#customer_sex').val();
				var customer_dob = $('#customer_dob').val();
				var customer_phone_number = $('#customer_phone_number').val();
				var customer_id_number = $('#customer_id_number').val();
				var customer_entry_type = $('#customer_entry_type').val();
				e.preventDefault();
				if (customer_first_name != "")
				{
					if (customer_sex != "")
					{
						if (customer_dob != "")
						{
							if (customer_phone_number != "")
							{
								if (customer_id_number != "")
								{
									$.ajax({
										url:'/layout/items/customer_save.php',
										method:'POST',
										data:$('#customer_create_form').serialize(),
										success:function(data)
										{
											$('#customer_create_form').trigger('reset');
											$('#customer_create_modal').modal('hide');
											if(customer_entry_type == 'customer')
											{
												window.location.href="/layout/items/customer_list.php";
											}
											else if(customer_entry_type == 'invoice')
											{
												$('#stock_sales_invoice_customer_details').html(data);
											};
										}
									});
								} 
								else 
								{
									$('#customer_create_form_msg').html('<h6 style=color:red;>Please the ID Number cannot be EMPTY!</h6>');
									$('#customer_create_form_msg').hide().slideDown().delay(2000).fadeOut();
								};
							} 
							else 
							{
								$('#customer_create_form_msg').html('<h6 style=color:red;>Please the Phone Number cannot be EMPTY!</h6>');
								$('#customer_create_form_msg').hide().slideDown().delay(2000).fadeOut();
							};
						} 
						else 
						{
							$('#customer_create_form_msg').html('<h6 style=color:red;>Please the Date of Birth cannot be EMPTY!</h6>');
							$('#customer_create_form_msg').hide().slideDown().delay(2000).fadeOut();
						};
					} 
					else 
					{
						$('#customer_create_form_msg').html('<h6 style=color:red;>Please the Sex cannot be EMPTY!</h6>');
						$('#customer_create_form_msg').hide().slideDown().delay(2000).fadeOut();
					};
				} 
				else 
				{
					$('#customer_create_form_msg').html('<h6 style=color:red;>Please the Name cannot be EMPTY!</h6>');
					$('#customer_create_form_msg').hide().slideDown().delay(2000).fadeOut();
				};
			});
		}

		function customer_edit()
		{
			$(document).on('click','#btn_edit_customer',function()
			{
				var customer_id = $(this).attr('data-id');
				$.ajax({  
					url:'/layout/items/customer_edit.php',  
					method:'POST',  
					data:{
						customer_id:customer_id
					},
					datatype: 'JSON',
					success:function(data)
					{
						var res = $.parseJSON(data);
						$('#customer_id').val(res[0]);
						$('#customer_first_name').val(res[1]);
						$('#customer_last_name').val(res[2]);
						$('#customer_dob').val(res[3]);
						$('#customer_phone_number').val(res[4]);
						$('#customer_address').val(res[5]);
						$('#customer_location').val(res[6]);
						$('#customer_email').val(res[7]);
						$('#customer_marital_status').val(res[8]);
						$('#customer_sex').val(res[9]);
						$('#customer_occupation').val(res[10]);
						$('#customer_religion').val(res[11]);
						$('#customer_id_number').val(res[12]);
						$('#customer_id_type').val(res[13]);
						$('#customer_other_info').val(res[14]);
						$('#customer_allergies').val(res[15]);
						$('#customer_create_modal_header').html('Customer Edit');
						$('#customer_update_btn').show();
						$('#customer_save_btn').hide();
						$('#customer_create_modal').modal('show');
					}
				});
			});
		}

		function customer_update()
		{
			$(document).on('click','#customer_update_btn',function(e){
				e.preventDefault();
				var customer_first_name = $('#customer_first_name').val();
				var customer_sex = $('#customer_sex').val();
				var customer_dob = $('#customer_dob').val();
				var customer_phone_number = $('#customer_phone_number').val();
				var customer_id_number = $('#customer_id_number').val();
				if (customer_first_name != "")
				{
					if (customer_sex != "")
					{
						if (customer_dob != "")
						{
							if (customer_phone_number != "")
							{
								if (customer_id_number != "")
								{
									$.ajax({
										url:'/layout/items/customer_update.php',
										method:'POST',
										data:$('#customer_create_form').serialize(),
										success:function(data)
										{
											$('#customer_create_form').trigger('reset');
											$('#customer_create_modal').modal('hide');
											window.location.href="/layout/items/customer_list.php";
										}
									});
								} 
								else 
								{
									$('#customer_create_form_msg').html('<h6 style=color:red;>Please the ID Number cannot be EMPTY!</h6>');
									$('#customer_create_form_msg').hide().slideDown().delay(2000).fadeOut();
								};
							} 
							else 
							{
								$('#customer_create_form_msg').html('<h6 style=color:red;>Please the Phone Number cannot be EMPTY!</h6>');
								$('#customer_create_form_msg').hide().slideDown().delay(2000).fadeOut();
							};
						} 
						else 
						{
							$('#customer_create_form_msg').html('<h6 style=color:red;>Please the Date of Birth cannot be EMPTY!</h6>');
							$('#customer_create_form_msg').hide().slideDown().delay(2000).fadeOut();
						};
					} 
					else 
					{
						$('#customer_create_form_msg').html('<h6 style=color:red;>Please the Sex cannot be EMPTY!</h6>');
						$('#customer_create_form_msg').hide().slideDown().delay(2000).fadeOut();
					};
				} 
				else 
				{
					$('#customer_create_form_msg').html('<h6 style=color:red;>Please the Name cannot be EMPTY!</h6>');
					$('#customer_create_form_msg').hide().slideDown().delay(2000).fadeOut();
				};
			});
		}

		function customer_search_modal()
		{
			$(document).on('click','#search_customer_icon',function()
			{
				$('#customer_search').prop('id','item_search');
				$('#customer_list_table').html('');
				$('#item_search_modal_header').text('Customer Search');
				$('#item_search_modal_form').trigger('reset');
				$('#item_search_modal').modal('show');
			});
		}

		function customer_search()
		{
			$(document).on('keyup','#item_search',function(e){
				e.preventDefault();
				
				var search = $('#item_search').val();
				$.ajax({
					url:'/layout/items/customer_search.php',
					method:'POST',
					data:{
						search:search
					},
					success:function(data)
					{
						$('#customer_list_table').html(data);
					}
				});
			});
		}

		function customer_search_save()
		{
			$(document).on('click','#search_customer_save',function(e){
				e.preventDefault();
				var customer_id = $(this).attr('data-id');
				$.ajax({
					url:'/layout/items/customer_search_save.php',
					method:'POST',
					data:{
						customer_id:customer_id
					},
					success:function(data)
					{
						$('#item_search_modal_form').trigger('reset');
						$('#item_search_modal').modal('hide');
						$('#stock_sales_invoice_customer_details').html(data);
					}
				});
			});
		}

	//STOCK_ITEMS
		function new_stock_item_modal()
		{
			$(document).on('click','#new_stock_item_icon',function()
			{
				$("#stock_item_detail_div").attr('class', 'col-md-12 mb-12');
				$("#stock_item_image_div").attr('hidden', true);
				$('#stock_item_update_btn').hide();
				$('#stock_item_save_btn').show();
				$('#stock_item_cancel_btn').show();
				$('#stock_item_create_form').trigger('reset');
				$('#block_neg').val('No');
				$('#batch').val('No');
				$('#expiry_date').val('No');
				$('#days_prompt').val(90);
				$('#min_level').val(100);
				$('#max_level').val(1000);
				$('#re_order_level').val(500);
				$('#eoq').val(600);
				$('#stock_item_create_modal').modal('show');
			});
		}

		function cancel_stock_item_modal()
		{
			$(document).on('click','#stock_item_cancel_btn',function()
			{
				$('#stock_item_create_modal').modal('hide');
				window.location.href="/layout/items/stock_item_list.php";
			});
		}

		function stock_item_add_component()
		{
			$(document).on('click','#add_stock_item_component',function()
			{
				var i = $('#stock_item_component_list_table tr:last').attr('id');
				$.ajax({
					url:'/layout/items/stock_item_add_component.php',
					method:'POST',
					data:{i:i},
					success:function(data)
					{
						$('#stock_item_component_list_table').append(data);
					}
				});
			});
		}

		function stock_item_component_price()
		{
			$(document).on('click','.stock_item_component_id',function(){
				var i = $('#stock_item_component_list_table tr:last').attr('id');
				var component_id = $('#stock_item_component_id'+i+'').val();
				$.ajax({
					url:'/layout/items/stock_item_component_price.php',
					method:'POST',
					data:{component_id:component_id},
					datatype:'JSON',
					success:function(data)
					{
						var res = $.parseJSON(data);
						$('#stock_item_component_price'+i+'').val(res[0]);
						$('#stock_item_component_priceD'+i+'').val(res[0]);
					}
		        });
			});
		}

		function stock_item_sum_component_amount()
		{
			$(document).on('keyup change', '.stock_item_component_price, .stock_item_component_gram', function()
			{  
				var button_id = $(this).closest('tr').attr('id');
				var component = $('#stock_item_component_id'+button_id).val();
				var price = $('#stock_item_component_price'+button_id).val();
				var gram = $('#stock_item_component_gram'+button_id).val();
				
				var item_gram = $('#grams').val();
				
				if(component != '' && component > 0)
				{
					var amount = 0;
					var amount = gram * price;
					$('#stock_item_component_amount'+button_id).val(amount);
					$('#stock_item_component_amountD'+button_id).val(amount);

					var total_gram = 0;
					var total_amount = 0;
					$(".stock_item_component_gram").each(function(){
						total_gram += +$(this).val();
					});
					$(".stock_item_component_amount").each(function(){
						total_amount += +$(this).val();
					});
					var price_per_gram = total_amount/total_gram;
					$("#stock_item_component_grams_total").val(total_gram);
					$("#stock_item_component_amount_total").val(total_amount);
					$("#grams").val(total_gram);
					$("#price_per_gram").val(price_per_gram.toFixed(2));
					$("#price_cash").val(total_amount);
				}
				else
				{
					$(this).val(0);
					alert('Please select the Component first!');
				};
			});
		}

		function stock_item_delete_component()
		{
			$(document).on('click', '.btn_delete_stock_item_component', function()
			{  
				var tr_id = $(this).closest("tr").attr("id");
				$('#'+tr_id+'').remove();
				
				var total_gram = 0;
				var total_amount = 0;
				$(".stock_item_component_gram").each(function(){
					total_gram += +$(this).val();
				});
				$(".stock_item_component_amount").each(function(){
					total_amount += +$(this).val();
				});
				var price_per_gram = total_amount/total_gram;
				$("#stock_item_component_grams_total").val(total_gram);
				$("#stock_item_component_amount_total").val(total_amount);
				$("#grams").val(total_gram);
				$("#price_per_gram").val(price_per_gram.toFixed(2));
				$("#price_cash").val(total_amount);
			});
		}

		function stock_item_pricing()
		{
			$(document).on('keyup','#grams, #price_per_gram',function(e){
				e.preventDefault();
				if(isNaN($('#grams').val()))
				{
					var grams = 0;
				}
				else
				{
					var grams = $('#grams').val();
				};

				if(isNaN($('#price_per_gram').val()))
				{
					var price_per_gram = 0;
				}
				else
				{
					var price_per_gram = $('#price_per_gram').val();
				};
				$.ajax({
					url:'/layout/items/stock_item_pricing.php',
					method:'POST',
					data:{
						grams:grams,
						price_per_gram:price_per_gram
					},
					success:function(data)
					{
						$('#price_cash').val(data);
					}
				});
			});
		}

		function save_new_stock_item()
		{
			$(document).on('click','#stock_item_save_btn',function(){
				var stock_item_name = $('#stock_item_name').val();
				if (stock_item_name !="") 
				{
					$.ajax({
						url:'/layout/items/stock_item_save.php',
						method:'POST',
						data:$('#stock_item_create_form').serialize(),
						success:function()
						{
				         	$('#stock_item_create_modal').modal('hide');
				         	$('#stock_item_create_form').trigger('reset');
							window.location.href="/layout/items/stock_item_list.php";
				        }
				    });
				} 
				else 
				{
					alert('Please the Stock Item Description cannot be EMPTY!');
				};
		    });
		}

		function edit_stock_item()
		{
			$(document).on('click','#btn_edit_stock_item',function()
			{
				var stock_item_id = $(this).attr('data-id');
				$.ajax({
			         url:'/layout/items/stock_item_edit.php',
			         method:'POST',
			         data:{stock_item_id:stock_item_id},
			         datatype: 'JSON',
			         success:function(data)
					 {
			         	var res = $.parseJSON(data);
			         	$('#stock_item_id').val(res[0]);
			         	$('#stock_item_name').val(res[2]);
			         	$('#type').val(res[1]);
			         	$('#price_cash').val(res[3]);
			         	$('#unit_of_measure').val(res[4]);
			         	$('#manufacturer').val(res[5]);
			         	$('#block_neg').val(res[6]);
			         	$('#expiry_date').val(res[7]);
			         	$('#batch').val(res[8]);
			         	$('#days_prompt').val(res[9]);
			         	$('#eoq').val(res[10]);
			         	$('#min_level').val(res[11]);
			         	$('#max_level').val(res[12]);
			         	$('#re_order_level').val(res[13]);
			         	$('#grams').val(res[16]);
			         	$('#price_per_gram').val(res[17]);
						
						$('#stock_item_image').html('');
						if(res[15] == 'pdf')
						{
							$('#stock_item_image').append('<iframe src="'+res[14]+'" width="250" height="200"></iframe>');
						}
						else
						{
							$('#stock_item_image').append('<img src="'+res[14]+'" width="250" height="200">');
						};
						$('#component_list_div').html(res[18]);
						$('#stock_item_component_total_div').html(res[19]);
						$("#stock_item_detail_div").attr('class', 'col-md-9 mb-9');
						$("#stock_item_image_div").attr('hidden', false);
			         	$('#stock_item_update_btn').show();
						$('#stock_item_save_btn').hide();
						$('#stock_item_create_modal_header').html('Stock Item Edit');
						$('#stock_item_create_modal').modal('show');
			        }
			    });
			});
		}

		function update_stock_item()
		{
			$(document).on('click','#stock_item_update_btn',function(){
				var stock_item_name = $('#stock_item_name').val();
				if (stock_item_name !=="") 
				{
					$.ajax({
				         url:'/layout/items/stock_item_update.php',
				         method:'POST',
				         data:$('#stock_item_create_form').serialize(),
				         success:function(data){
				         	$('#stock_item_create_modal').modal('hide');
				         	$('#stock_item_create_form').trigger('reset');
							window.location.href="/layout/items/stock_item_list.php";
				         }
				     });
				} 
				else 
				{
					alert('Please the Stock Item Description cannot be EMPTY!');
				};
			});
		}

		function stock_item_image_modal()
		{
			$(document).on('click','#stock_item_file_insert_btn',function()
			{
				var stock_item_id = $(this).attr('data-id');
				var currentRow=$(this).closest("tr");
				var name = currentRow.find("td:eq(0)").text();
				$('#stock_item_img_upload_modal_title').html('Upload Image for '+name);
				$('#stock_item_id_img').val(stock_item_id);
				$('#stock_item_img_upload_modal').modal('show');
			});
		}
		
		function stock_item_image_trigger_click()
		{
			$(document).on('click','#stock_item_image_display',function()
			{
				$('#stock_item_img_file').click();
			});
		}
		
		function stock_item_image_display_before_upload()
		{
			$(document).on('change','#stock_item_img_file',function()
			{
				if(this.files[0])
				{
					var reader = new FileReader();
					reader.onload = function(e)
					{
						$('#stock_item_image_display').attr('src', e.target.result);
					}
					reader.readAsDataURL(this.files[0]);
				};
			});
		}
		
		function stock_item_img_display_clear()
		{
			$(document).on('click','#delete_stock_item_image',function()
			{
				var stock_item_id = $(this).attr('data-id');
				var stock_item_img_id = $(this).attr('data-id1');
				$('#item_delete_question').text('Are you sure you want to delete this Stock Item Image?');
				$('#item_delete_modal').modal('show');
				$(document).on('click','#item_delete_yes',function()
				{
					$('#item_delete_modal').modal('hide');
					$.ajax({  
						url:'/layout/items/stock_item_img_display_clear.php',
						method:'POST',
						datatype: 'JSON',
						data:{
							stock_item_img_id:stock_item_img_id,
							stock_item_id:stock_item_id
						},
						success:function(data)
						{
							var res = $.parseJSON(data);
							$('#stock_item_images_list').html('');
							for(var i = 0; i < res.length; i += 4) 
							{
								if(res[i+3] == 'pdf')
								{
									$('#stock_item_images_list').append('<iframe src="'+res[i]+'" width="300" height="200"></iframe><a href="#" id="delete_stock_item_image" data-id="'+res[i+2]+'" data-id1="'+res[i+1]+'">Clear</a>');
								}
								else
								{
									$('#stock_item_images_list').append('<img src="'+res[i]+'" width="300" height="200"><a href="#" id="delete_stock_item_image" data-id="'+res[i+2]+'" data-id1="'+res[i+1]+'">Clear</a>');
								};
							};

						}
					});
			    });
				$(document).on('click','#item_delete_no',function()
				{
					$('#item_delete_modal').modal('hide');
				});
				
			}); 
		}
		
		function delete_stock_item()
		{
			$(document).on('click','#btn_delete_stock_item',function(){
				var stock_item_id = $(this).attr('data-id');
				var currentRow=$(this).closest("tr");
				var item = currentRow.find("td:eq(0)").text();
				$('#item_delete_modal_title').text('Stock Item Deletion!');
				$('#item_delete_question').text('Are you sure you want to delete Stok Item: ' + item + '?');
				$('#item_delete_modal').modal('show');
				$(document).on('click','#item_delete_yes',function(){
					$.ajax({  
		                 url:'/layout/items/stock_item_delete.php',  
		                 type:'POST',  
		                 data:{stock_item_id:stock_item_id},
		                 success:function(data)
						 {
							if(data == 'deleted')
							{
								$('#item_delete_question').text(item +' deleted successfully!');
								$('#item_delete_no').hide();
								$('#item_delete_yes').text('OK');
								$(document).on('click','#item_delete_yes',function()
								{
									$('#item_delete_modal').modal('hide');
									window.location.href="/layout/items/stock_item_list.php";
								})
							}
							else if(data == 'used')
							{
								$('#item_delete_question').text(item +' has been used for transactions, deletion is declined!');
								$('#item_delete_no').hide();
								$('#item_delete_yes').text('OK');
								$(document).on('click','#item_delete_yes',function()
								{
									$('#item_delete_modal').modal('hide');
									window.location.href="/layout/items/stock_item_list.php";
								});
							};
		                 }
		            });
			      });
				$(document).on('click','#item_delete_no',function(){
					$('#item_delete_modal').modal('hide');
				});
			});
		}
		
		function stock_item_auto_update_price_modal()
		{
			$(document).on('click','#auto_update_price_icon',function()
			{
				$('#stock_item_auto_price_modal_form').trigger('reset');
				$('#product_type_div').show();
				$('#component_div').hide();
				$('#stock_item_auto_price_modal').modal('show');
			});
		}

		function stock_item_auto_update_price_modal_component()
		{
			$(document).on('click','#auto_update_price_component_icon',function()
			{
				$('#stock_item_auto_price_modal_form').trigger('reset');
				$('#product_type_div').hide();
				$('#component_div').show();
				$('#stock_item_auto_price_modal').modal('show');
			});
		}
		
		function stock_item_auto_update_price_save()
		{
			$(document).on('click','#stock_item_auto_price_modal_ok_btn',function(){
				var component_id = $('#stock_item_auto_price_modal_component_id').val();
				var type = $('#stock_item_auto_price_modal_type').val();
				var category = $('#stock_item_auto_price_modal_category').val();
				var amount = $('#stock_item_auto_price_modal_amount').val();
				if(category != '' || (component_id !='' && component_id > 0))
				{
					if(type != '')
					{
						if(amount != '' && amount != 0)
						{
							$('#stock_item_auto_price_modal').modal('hide');
							$('#item_delete_modal_title').text('Stock Item Price Update!');
							$('#item_delete_question').text('Are you sure you want to Update ' + category + ' Stock Items ' + type +' by '+ amount + '?');
							$('#item_delete_modal').modal('show');
							$(document).on('click','#item_delete_yes',function()
							{
								$.ajax({
									url:'/layout/items/stock_item_auto_price_update.php',  
									type:'POST',  
									data:{
										type:type,
										amount:amount,
										component_id:component_id,
										category:category
									},
									success:function(data)
									{
										$('#item_delete_question').text(data +' Stock Items updated successfully!');
										$('#item_delete_no').hide();
										$('#item_delete_yes').text('OK');
										$('#item_delete_yes').prop('id','item_delete_ok');
										$(document).on('click','#item_delete_ok',function()
										{
											$('#item_delete_modal').modal('hide');
											window.location.href="/layout/items/stock_item_list.php";
										})
									}
								});
							});
							$(document).on('click','#item_delete_no',function(){
								$('#item_delete_modal').modal('hide');
							});
						}
						else
						{
							$('#stock_item_auto_price_modal_warning').html('<h6 style=color:red;>Please the Amount cannot be EMPTY or zero!</h6>');
							$('#stock_item_auto_price_modal_warning').hide().slideDown().delay(2000).fadeOut();
						};
					}
					else
					{
						$('#stock_item_auto_price_modal_warning').html('<h6 style=color:red;>Please the Type of Price Update cannot be EMPTY!</h6>');
						$('#stock_item_auto_price_modal_warning').hide().slideDown().delay(2000).fadeOut();
					};
				}
				else
				{
					$('#stock_item_auto_price_modal_warning').html('<h6 style=color:red;>Please the Type of Product OR the Component cannot be EMPTY!</h6>');
					$('#stock_item_auto_price_modal_warning').hide().slideDown().delay(2000).fadeOut();
				};
			});
		}
		
	//COMPONENT
		function component_new_modal()
		{
			$(document).on('click','#new_component_icon',function()
			{
				$('#component_create_modal_header').html('Component Setup');
				$('#component_create_form').trigger('reset');
				$('#component_update_btn').hide();
				$('#component_save_btn').show();
				$('#component_create_modal').modal('show');
			});
		}

		function component_save()
		{
			$(document).on('click','#component_save_btn',function(e)
			{
				e.preventDefault();
				var component = $('#component').val();
				var price_per_gram = $('#price_per_gram').val();
				if (component !== "")
				{
					if (price_per_gram !== "")
					{
						$.ajax({
							url:'/layout/items/component_save.php',
							method:'POST',
							data:$('#component_create_form').serialize(),
							success:function(data)
							{
								$('#component_create_form').trigger('reset');
								$('#component_create_modal').modal('hide');
								window.location.href="/layout/items/component_list.php";
							}
						});	
					} 
					else 
					{
						$('#component_create_form_msg').html('<h6 style=color:red;>Please the Price Per Gram cannot be EMPTY!</h6>');
						$('#component_create_form_msg').hide().slideDown().delay(2000).fadeOut();
					};
				} 
				else 
				{
					$('#component_create_form_msg').html('<h6 style=color:red;>Please the Component cannot be EMPTY!</h6>');
					$('#component_create_form_msg').hide().slideDown().delay(2000).fadeOut();
				};
			});
		}

		function component_edit()
		{
			$(document).on('click','#btn_edit_component',function()
			{
				var component_id = $(this).attr('data-id');
				$.ajax({  
					url:'/layout/items/component_edit.php',  
					method:'POST',  
					data:{
						component_id:component_id
					},
					datatype: 'JSON',
					success:function(data)
					{
						var res = $.parseJSON(data);
						$('#component_id').val(res[0]);
						$('#component').val(res[1]);
						$('#price_per_gram').val(res[2]);
						$('#component_create_modal_header').html('Component Edit');
						$('#component_update_btn').show();
						$('#component_save_btn').hide();
						$('#component_create_modal').modal('show');
					}
				});
			});
		}

		function component_update()
		{
			$(document).on('click','#component_update_btn',function(e)
			{
				var component = $('#component').val();
				var price_per_gram = $('#price_per_gram').val();
				e.preventDefault();
				if (component !== "")
				{
					if (price_per_gram !== "")
					{
						$.ajax({
							url:'/layout/items/component_update.php',
							method:'POST',
							data:$('#component_create_form').serialize(),
							success:function(data)
							{
								$('#component_create_form').trigger('reset');
								$('#component_create_modal').modal('hide');
								window.location.href="/layout/items/component_list.php";
							}
						});	
					} 
					else 
					{
						$('#component_create_form_msg').html('<h6 style=color:red;>Please the Price Per Gram cannot be EMPTY!</h6>');
						$('#component_create_form_msg').hide().slideDown().delay(2000).fadeOut();
					};
				} 
				else 
				{
					$('#component_create_form_msg').html('<h6 style=color:red;>Please the Component cannot be EMPTY!</h6>');
					$('#component_create_form_msg').hide().slideDown().delay(2000).fadeOut();
				};
			});
		}
	
		function component_delete()
		{
			$(document).on('click','#btn_delete_component',function(){
				var component_id = $(this).attr('data-id');
				var currentRow=$(this).closest("tr");
				var item = currentRow.find("td:eq(0)").text();
				$('#item_delete_modal_title').text('Stock Item Deletion!');
				$('#item_delete_question').text('Are you sure you want to delete Stok Item: ' + item + '?');
				$('#item_delete_modal').modal('show');
				$(document).on('click','#item_delete_yes',function(){
					$.ajax({  
							url:'/layout/items/component_delete.php',  
							type:'POST',  
							data:{component_id:component_id},
							success:function(data)
							{
							if(data == 'deleted')
							{
								$('#item_delete_question').text(item +' deleted successfully!');
								$('#item_delete_no').hide();
								$('#item_delete_yes').text('OK');
								$(document).on('click','#item_delete_yes',function()
								{
									$('#item_delete_modal').modal('hide');
									window.location.href="/layout/items/component_list.php";
								})
							}
							else if(data == 'used')
							{
								$('#item_delete_question').text(item +' has been used for transactions, deletion is declined!');
								$('#item_delete_no').hide();
								$('#item_delete_yes').text('OK');
								$(document).on('click','#item_delete_yes',function()
								{
									$('#item_delete_modal').modal('hide');
									window.location.href="/layout/items/component_list.php";
								});
							};
							}
					});
					});
				$(document).on('click','#item_delete_no',function(){
					$('#item_delete_modal').modal('hide');
				});
			});
		}

	//WAREHOUSE
		function new_warehouse_modal()
		{
			$(document).on('click','#new_warehouse_icon',function()
			{
				$('#warehouse_update_btn').hide();
				$('#warehouse_save_btn').show();
				$('#warehouse_cancel_btn').show();
				$('#warehouse_create_form').trigger('reset');
				$('#warehouse_create_modal').modal('show');
			});
		}

		function save_new_warehouse()
		{
			$(document).on('click','#warehouse_save_btn',function(){
				var warehouse_name = $('#warehouse_name').val();
				if (warehouse_name !=="") 
				{
					$.ajax({
				         url:'/layout/items/warehouse_save.php',
				         method:'POST',
				         data:$('#warehouse_create_form').serialize(),
				         success:function(data){
				         	$('#warehouse_create_modal').modal('hide');
				         	$('#warehouse_create_form').trigger('reset');
				         	$('#warehouse_list_table').html(data);
				         }
				     });
				} 
				else 
				{
					alert('Please the Warehouse Description cannot be EMPTY!');
				};
		    });
		}

		function edit_warehouse()
		{
			$(document).on('click','#btn_edit_warehouse',function()
			{
				var warehouse_id = $(this).attr('data-id');
				$.ajax({
			         url:'/layout/items/warehouse_edit.php',
			         method:'POST',
			         data:{warehouse_id:warehouse_id},
			         datatype: 'JSON',
			         success:function(data){
			         	var res = $.parseJSON(data);
			         	$('#warehouse_id').val(res[0]);
			         	$('#warehouse_name').val(res[1]);
			         	$('#warehouse_location').val(res[2]);
			         	$('#warehouse_update_btn').show();
						$('#warehouse_save_btn').hide();
						$('#warehouse_create_modal_header').html('Warehouse Edit');
						$('#warehouse_create_modal').modal('show');
			         }
			     });
			});
		}

		function update_warehouse()
		{
			$(document).on('click','#warehouse_update_btn',function(){
				var warehouse_name = $('#warehouse_name').val();
				if (warehouse_name !=="") 
				{
					$.ajax({
				         url:'/layout/items/warehouse_update.php',
				         method:'POST',
				         data:$('#warehouse_create_form').serialize(),
				         success:function(data){
				         	$('#warehouse_create_modal').modal('hide');
				         	$('#warehouse_create_form').trigger('reset');
				         	$('#warehouse_list_table').html(data);
				         }
				     });
				} 
				else 
				{
					alert('Please the Warehouse Description cannot be EMPTY!');
				};
			});
		}

	//SITES
		function new_site_modal()
		{
			$(document).on('click','#new_site_icon',function()
			{
				$('#site_update_btn').hide();
				$('#site_save_btn').show();
				$('#site_cancel_btn').show();
				$('#site_create_form').trigger('reset');
				$('#site_create_modal').modal('show');
			});
		}

		function save_site()
		{
			$(document).on('click','#site_save_btn',function(){
				var site_name = $('#site_name').val();
				if (site_name !=="") 
				{
					$.ajax({
				         url:'/layout/items/site_save.php',
				         method:'POST',
				         data:$('#site_create_form').serialize(),
				         success:function(data){
				         	$('#site_create_modal').modal('hide');
				         	$('#site_create_form').trigger('reset');
				         	$('#site_list_table').html(data);
				         }
				     });
				} 
				else 
				{
					alert('Please the Site Description cannot be EMPTY!');
				};
		    });
		}

		function edit_site()
		{
			$(document).on('click','#btn_edit_site',function()
			{
				var site_id = $(this).attr('data-id');
				$.ajax({
			         url:'/layout/items/site_edit.php',
			         method:'POST',
			         data:{site_id:site_id},
			         datatype: 'JSON',
			         success:function(data){
			         	var res = $.parseJSON(data);
			         	$('#site_id').val(res[0]);
			         	$('#site_name').val(res[1]);
			         	$('#site_location').val(res[2]);
			         	$('#site_update_btn').show();
						$('#site_save_btn').hide();
						$('#site_create_modal_header').html('Site Edit');
						$('#site_create_modal').modal('show');
			         }
			     });
			});
		}

		function update_site()
		{
			$(document).on('click','#site_update_btn',function(){
				var site_name = $('#site_name').val();
				if (site_name !=="") 
				{
					$.ajax({
				         url:'/layout/items/site_update.php',
				         method:'POST',
				         data:$('#site_create_form').serialize(),
				         success:function(data){
				         	$('#site_create_modal').modal('hide');
				         	$('#site_create_form').trigger('reset');
				         	$('#site_list_table').html(data);
				         }
				     });
				} 
				else 
				{
					alert('Please the Site Description cannot be EMPTY!');
				};
			});
		}

	//ASSETS
		function new_asset_modal()
		{
			$(document).on('click','#new_asset_icon',function()
			{
				$('#asset_update_btn').hide();
				$('#asset_save_btn').show();
				$('#asset_cancel_btn').show();
				$('#asset_create_form').trigger('reset');
				$('#asset_create_modal').modal('show');
			});
		}

		function save_asset()
		{
			$(document).on('click','#asset_save_btn',function(){
				var asset_ledger_id = $('#asset_ledger_id').val();
				var asset_brand = $('#asset_brand').val();
				var asset_model = $('#asset_model').val();
				var asset_serial_no = $('#asset_serial_no').val();
				var asset_manu_date = $('#asset_manu_date').val();
				if (asset_ledger_id !=="") 
				{
					if (asset_brand !=="") 
					{
						if (asset_model !=="") 
						{
							if (asset_serial_no !=="") 
							{
								$.ajax({
							         url:'/layout/items/asset_save.php',
							         method:'POST',
							         data:$('#asset_create_form').serialize(),
							         success:function(data){
							         	$('#asset_create_modal').modal('hide');
							         	$('#asset_create_form').trigger('reset');
							         	$('#asset_list_table').html(data);
							         }
							     });
							} 
							else 
							{
								alert('Please the Serial No cannot be EMPTY!');
							};
						} 
						else 
						{
							alert('Please the Model cannot be EMPTY!');
						};
					} 
					else 
					{
						alert('Please the Brand cannot be EMPTY!');
					};
				} 
				else 
				{
					alert('Please the Ledger cannot be EMPTY!');
				};
		    });
		}

		function edit_asset()
		{
			$(document).on('click','#btn_edit_asset',function()
			{
				var asset_id = $(this).attr('data-id');
				$.ajax({
			         url:'/layout/items/asset_edit.php',
			         method:'POST',
			         data:{asset_id:asset_id},
			         datatype: 'JSON',
			         success:function(data){
			         	var res = $.parseJSON(data);
			         	$('#asset_id').val(res[0]);
			         	$('#asset_ledger_id').val(res[1]);
			         	$('#asset_brand').val(res[2]);
			         	$('#asset_model').val(res[3]);
			         	$('#asset_serial_no').val(res[4]);
			         	$('#asset_manu_date').val(res[5]);
			         	$('#asset_update_btn').show();
						$('#asset_save_btn').hide();
						$('#asset_create_modal_header').html('Asset Edit');
						$('#asset_create_modal').modal('show');
			         }
			     });
			});
		}

		function update_asset()
		{
			$(document).on('click','#asset_update_btn',function(){
				
				var asset_ledger_id = $('#asset_ledger_id').val();
				var asset_brand = $('#asset_brand').val();
				var asset_model = $('#asset_model').val();
				var asset_serial_no = $('#asset_serial_no').val();
				var asset_manu_date = $('#asset_manu_date').val();
				if (asset_ledger_id !=="") 
				{
					if (asset_brand !=="") 
					{
						if (asset_model !=="") 
						{
							if (asset_serial_no !=="") 
							{
								$.ajax({
							         url:'/layout/items/asset_update.php',
							         method:'POST',
							         data:$('#asset_create_form').serialize(),
							         success:function(data){
							         	$('#asset_create_modal').modal('hide');
							         	$('#asset_create_form').trigger('reset');
							         	$('#asset_list_table').html(data);
							         }
							     });
							} 
							else 
							{
								alert('Please the Serial No cannot be EMPTY!');
							};
						} 
						else 
						{
							alert('Please the Model cannot be EMPTY!');
						};
					} 
					else 
					{
						alert('Please the Brand cannot be EMPTY!');
					};
				} 
				else 
				{
					alert('Please the Ledger cannot be EMPTY!');
				};
			});
		}
//FINANCIALS
	//RECEIPT
		function new_receipt_voucher_modal()
		{
			$(document).on('click','#new_receipt_icon',function()
			{
				var company_id = $('#session_company_id').val();
				var user_super_id = $('#session_user_super_id').val();
				var user_id = $('#session_user_id').val();
				$('#receipt_company_id').val(company_id);
				$('#receipt_user_super_id').val(user_super_id);
				$('#receipt_user_id').val(user_id);
				$('#receipt_update_btn').hide();
				$('#receipt_save_btn').show();
				$('#receipt_create_form').trigger('reset');
				$('#receipt_create_modal').modal('show');
			});
		}

		function receipt_mode_bank_details()
		{
			$(document).on('change keyup','#receipt_mode',function()
			{
				var payment_mode = $('#receipt_mode').val();
				if(payment_mode =='cheque')
				{
					$("#bank_details_div").prop("hidden",false);
				}else
				{
					$("#bank_details_div").prop("hidden",true);
				};
			});
		}

		/*function mask_receipt_amt()
			{
				$('.receipt_item_amt').mask('#,###,###,###.##',{reverse : true});
			}*/

		function sum_receipt_item_amount()
		{
			$(document).on('keyup','.receipt_cr_amt',function(){ 
					var sum=0;
					$('.receipt_cr_amt').each(function(){
						var num = $(this).val().replace(',','');
						if(num !=0){
							sum += parseFloat(num);
						}
					});
					$('#receipt_amount').val(sum);
					$('#receipt_amountD').val(sum);
				});
		}

		function add_receipt_item_row()
		{
			$(document).on('change','.receipt_led_cr',function(){ 
				var company_id = $('#session_company_id').val();
				var i = $('#receipt_cr_list_table tr:last').attr('id');
				i++;
				$.ajax({
					url:'/layout/vouchers/receipt_cr_list.php',
					method:'POST',
					data:{i:i,company_id:company_id},
					success:function(data)
					{
						$('#receipt_cr_list_table').append('<tr id="'+i+'">'+data+'</tr>');
					}
				});
			});
		}

		function delete_receipt_item_row()
		{
			$(document).on('click', '#delete_receipt_cr', function(){  
       			var button_id = $(this).attr("data-id");
           		$('#'+button_id+'').remove();
           		var sum=0;
				$('.receipt_cr_amt').each(function(){
					var num = $(this).val().replace(',','');
					if(num !=0){
						sum += parseFloat(num);
					}
				});
				$('#receipt_amount').val(sum);
				$('#receipt_amountD').val(sum);
           	});
		}

		function cancel_receipt_voucher_modal()
		{
			$(document).on('click','#receipt_cancel_btn',function()
			{
				var page = window.location.pathname;
				$('#receipt_create_form').trigger('reset');
				$('#receipt_create_modal').modal('hide');
				window.location.href= page;
				//window.location.href="/layout/vouchers/receipt_list.php";
			});
		}

		function save_receipt_voucher()
		{
			$(document).on('click','#receipt_save_btn',function(e){
				e.preventDefault();
				var last_tr_id = $("#receipt_cr_list_table tr:last").attr("id");
				var last_tr_select = $("#receipt_cr_list_table tr:last option:selected").val();
				var receipt_debit_ledger = $('#receipt_debit_ledger').val();
				var receipt_mode = $('#receipt_mode').val();
				var receipt_date = $('#receipt_date').val();
				var receipt_received_from = $('#receipt_received_from').val();
				var receipt_amount = $('#receipt_amount').val();
				var page = window.location.pathname;
				if (receipt_debit_ledger !=="") 
				{
					if (receipt_date !=="") 
					{
						if (receipt_mode !=="") 
						{
							if (receipt_received_from !=="") 
							{
								if (receipt_amount > 0) 
								{
									if(last_tr_select =="" || last_tr_select ==0)
									{
										$('#'+last_tr_id+'').remove();
									};
									$.ajax({
							             url:'/layout/vouchers/receipt_save.php',
							             method:'POST',
							             data:$('#receipt_create_form').serialize(),
							             success:function(data)
								             {
								             	$('#receipt_create_form').trigger('reset');
								             	window.open('/layout/vouchers/receipt_display.php', '_blank');
								             	window.location.href= page;
								             	//window.location.href="/layout/vouchers/receipt_list.php";
								             }
							        });		
								} 
								else 
								{
									alert('Please provide amount for credit ledgers selected!');
								}
							} 
							else 
							{
								alert('Please type the name of the person the receipt is being made to!');
							}
						} 
						else 
						{
							alert('Please select the mode of receipt!');
						}
					} 
					else 
					{
						alert('Please select the date for the receipt voucher!');
					}
				} 
				else 
				{
					alert('Please select the ledger from which receipt is being made!');
				};
			});
		}

		function edit_receipt_voucher()
		{
			$(document).on('click','#btn_edit_receipt',function(){
				var receipt_id = $(this).attr('data-id');
				$.ajax({
			            url:'/layout/vouchers/receipt_edit.php',
			            method:'POST',
			            data:{receipt_id:receipt_id},
						datatype:'JSON',
			            success:function(data)
			            {
			             	var res = $.parseJSON(data);
			             	$('#receipt_id').val(res[1]);
			             	$('#receipt_company_id').val(res[2]);
			             	$('#receipt_user_id').val(res[3]);
			             	$('#receipt_user_super_id').val(res[0]);
			             	$('#receipt_debit_ledger').val(res[4]);
			             	$('#receipt_ref').val(res[10]);
			             	$('#receipt_date').val(res[7]);
			             	$('#receipt_amount').val(res[8]);
			             	$('#receipt_amountD').val(res[8]);
			             	$('#receipt_mode').val(res[11]);
			             	$('#receipt_inst_no').val(res[14]);
			             	$('#receipt_bank').val(res[12]);
			             	$('#receipt_branch').val(res[13]);
			             	$('#receipt_received_from').val(res[6]);
			             	$('#receipt_narration').val(res[9]);
			             	$('#receipt_branch_id').val(res[15]);

			             	$.ajax({
					            url:'/layout/vouchers/receipt_cr_edit.php',
					            method:'POST',
					            data:{receipt_id:receipt_id},
					            success:function(data)
						            {
						            	$('#receipt_cr_list').html(data);
									}
				            });
			             	$('#receipt_update_btn').show();
			             	$('#receipt_save_btn').hide();
							$('#receipt_create_modal').modal('show');
    						
						}
		             });
				
			});
		}

		function update_receipt_voucher()
		{
			$(document).on('click','#receipt_update_btn',function(e){
				e.preventDefault();
				var last_tr_id = $("#receipt_cr_list_table tr:last").attr("id");
				var last_tr_select = $("#receipt_cr_list_table tr:last option:selected").val();
				var receipt_debit_ledger = $('#receipt_debit_ledger').val();
				var receipt_mode = $('#receipt_mode').val();
				var receipt_date = $('#receipt_date').val();
				var receipt_received_from = $('#receipt_received_from').val();
				var receipt_amount = $('#receipt_amount').val();
				var page = window.location.pathname;
				if (receipt_debit_ledger !=="") 
				{
					if (receipt_date !=="") 
					{
						if (receipt_mode !=="") 
						{
							if (receipt_received_from !=="") 
							{
								if (receipt_amount > 0) 
								{
									if(last_tr_select =="" || last_tr_select ==0)
									{
										$('#'+last_tr_id+'').remove();
									};
									$.ajax({
							             url:'/layout/vouchers/receipt_update.php',
							             method:'POST',
							             data:$('#receipt_create_form').serialize(),
							             success:function(data)
								             {
								             	$('#receipt_create_form').trigger('reset');
								             	window.location.href= page;
								             	//window.location.href="/layout/vouchers/receipt_list.php";
								             }
							        });		
								} 
								else 
								{
									alert('Please provide amount for credit ledgers selected!');
								}
							} 
							else 
							{
								alert('Please type the name of the person the receipt is being made to!');
							}
						} 
						else 
						{
							alert('Please select the mode of receipt!');
						}
					} 
					else 
					{
						alert('Please select the date for the receipt voucher!');
					}
				} 
				else 
				{
					alert('Please select the ledger from which receipt is being made!');
				};
			});
		}

		function search_receipt_by_name()
		{
			$(document).on('keyup','#receipt_search_name',function(e){
				e.preventDefault();
				var company_id = $('#session_company_id').val();
				var receipt_search_name = $('#receipt_search_name').val();

				$.ajax({
					url:'/layout/vouchers/receipt_search_by_name.php',
					method:'POST',
					data:{receipt_search_name:receipt_search_name,company_id:company_id},
					success:function(data)
					{
						$('#receipt_list_card_body').html(data);
					}
		        });
			});
		}

		function search_receipt_by_date()
		{
			$(document).on('click','#receipt_search_icon',function(e){
				e.preventDefault();
				var company_id = $('#session_company_id').val();
				var start_date = $('#receipt_search_from').val();
				var end_date = $('#receipt_search_to').val();

				$.ajax({
		             url:'/layout/vouchers/receipt_search_by_date.php',
		             method:'POST',
		             data:{start_date:start_date,end_date:end_date,company_id:company_id},
		             success:function(data)
			             {
			             	$('#receipt_list_card_body').html(data);
			             }
		        });
			});
		}

		function reprint_receipt()
		{
			$(document).on('click','#btn_receipt_reprint',function(e){
				var receipt_id = $(this).attr('data-id');
				var company_id = $('#session_company_id').val();

				$.ajax({
		             url:'/layout/vouchers/receipt_reprint.php',
		             method:'POST',
		             data:{
		             	receipt_id:receipt_id,
		             	company_id:company_id
		             },
		             success:function(data)
		             {
		             	window.open('/layout/vouchers/receipt_display.php', '_blank');
		             }
		        });
			});
		}

		function delete_receipt()
		{
			$(document).on('click','#btn_delete_receipt',function(){
				var receipt_id = $(this).attr('data-id');
				var currentRow=$(this).closest("tr");
				var receipt_date = currentRow.find("td:eq(1)").text();
				//var Supplier = currentRow.find("td:eq(3)").text();
				$('#receipt_delete_question').text('Are you sure you want to delete receipt of ' + receipt_date + '?');
				$('#receipt_delete_modal').modal('show');
				$(document).on('click','#receipt_delete_yes',function(){
					$.ajax({  
		                 url:'/layout/vouchers/receipt_delete.php',  
		                 type:'POST',  
		                 data:{receipt_id:receipt_id},
		                 success:function(){
		                 	$('#receipt_delete_modal').modal('hide');
		                 	window.location.href="/layout/vouchers/receipt_list.php";
		                 }  
		            });
			      });
				$(document).on('click','#receipt_delete_no',function(){
					$('#receipt_delete_modal').modal('hide');
				});
			});
		}
		
	//PAYMENT
		function new_payment_voucher_modal()
		{
			$(document).on('click','#new_payment_icon',function()
			{
				var company_id = $('#session_company_id').val();
				var user_super_id = $('#session_user_super_id').val();
				var user_id = $('#session_user_id').val();
				$('#company_id').val(company_id);
				$('#user_super_id').val(user_super_id);
				$('#user_id').val(user_id);
				$('#payment_update_btn').hide();
				$('#payment_save_btn').show();
				$('#payment_create_form').trigger('reset');
				$('#payment_create_modal').modal('show');
			});
		}

		function payment_mode_bank_details()
		{
			$(document).on('change keyup','#payment_mode',function()
			{
				var payment_mode = $('#payment_mode').val();
				if(payment_mode =='cheque')
				{
					$("#bank_details_div").prop("hidden",false);
				}else
				{
					$("#bank_details_div").prop("hidden",true);
				};
			});
		}

		/*function mask_payment_amt()
			{
				$('.payment_item_amt').mask('#,###,###,###.##',{reverse : true});
			}*/

		function sum_payment_item_amount()
		{
			$(document).on('keyup','.payment_dr_amt',function(){ 
					var sum=0;
					$('.payment_dr_amt').each(function(){
						var num = $(this).val().replace(',','');
						if(num !=0){
							sum += parseFloat(num);
						}
					});
					$('#payment_amount').val(sum);
					$('#payment_amountD').val(sum);
				});
		}

		function add_payment_item_row()
		{
			$(document).on('change','.payment_led_dr',function(){ 
				var company_id = $('#session_company_id').val();
				var i = $('#payment_dr_list_table tr:last').attr('id');
				i++;
				$.ajax({
					url:'/layout/vouchers/payment_dr_list.php',
					method:'POST',
					data:{i:i,company_id:company_id},
					success:function(data)
					{
						$('#payment_dr_list_table').append('<tr id="'+i+'">'+data+'</tr>');
					}
				});
			});
		}

		function delete_payment_item_row()
		{
			$(document).on('click', '#delete_payment_dr', function(){  
       			var button_id = $(this).attr("data-id");
           		$('#'+button_id+'').remove();
           		var sum=0;
				$('.payment_dr_amt').each(function(){
					var num = $(this).val().replace(',','');
					if(num !=0){
						sum += parseFloat(num);
					}
				});
				$('#payment_amount').val(sum);
				$('#payment_amountD').val(sum);
           	});
		}

		function cancel_payment_voucher_modal()
		{
			$(document).on('click','#payment_cancel_btn',function()
			{
				var page = window.location.pathname;
				$('#payment_create_form').trigger('reset');
				$('#payment_create_modal').modal('hide');
				window.location.href= page;
				//window.location.href="/layout/vouchers/payment_list.php";
			});
		}

		function save_payment_voucher()
		{
			$(document).on('click','#payment_save_btn',function(e){
				e.preventDefault();
				var last_tr_id = $("#payment_dr_list_table tr:last").attr("id");
				var last_tr_select = $("#payment_dr_list_table tr:last option:selected").val();
				var payment_credit_ledger = $('#payment_credit_ledger').val();
				var payment_mode = $('#payment_mode').val();
				var payment_date = $('#payment_date').val();
				var payment_payee = $('#payment_payee').val();
				var payment_amount = $('#payment_amount').val();
				var page = window.location.pathname;
				if (payment_credit_ledger !=="") 
				{
					if (payment_date !=="") 
					{
						if (payment_mode !=="") 
						{
							if (payment_payee !=="") 
							{
								if (payment_amount > 0) 
								{
									if(last_tr_select =="" || last_tr_select ==0)
									{
										$('#'+last_tr_id+'').remove();
									};
									$.ajax({
							             url:'/layout/vouchers/payment_save.php',
							             method:'POST',
							             data:$('#payment_create_form').serialize(),
							             success:function(data)
								             {
								             	$('#payment_create_form').trigger('reset');
								             	window.location.href= page;
								             	//window.location.href="/layout/vouchers/payment_list.php";
								             }
							        });		
								} 
								else 
								{
									alert('Please provide amount for debit ledgers selected!');
								}
							} 
							else 
							{
								alert('Please type the name of the person the payment is being made to!');
							}
						} 
						else 
						{
							alert('Please select the mode of payment!');
						}
					} 
					else 
					{
						alert('Please select the date for the payment voucher!');
					}
				} 
				else 
				{
					alert('Please select the ledger from which payment is being made!');
				};
			});
		}

		function edit_payment_voucher()
		{
			$(document).on('click','#btn_edit_payment',function(){
				var payment_id = $(this).attr('data-id');
				$.ajax({
			            url:'/layout/vouchers/payment_edit.php',
			            method:'POST',
			            data:{payment_id:payment_id},
						datatype:'JSON',
			            success:function(data)
			            {
			             	var res = $.parseJSON(data);
			             	$('#payment_id').val(res[1]);
			             	$('#company_id').val(res[2]);
			             	$('#user_id').val(res[3]);
			             	$('#user_super_id').val(res[0]);
			             	$('#payment_credit_ledger').val(res[4]);
			             	$('#payment_ref').val(res[10]);
			             	$('#payment_date').val(res[7]);
			             	$('#payment_amount').val(res[8]);
			             	$('#payment_amountD').val(res[8]);
			             	$('#payment_mode').val(res[11]);
			             	$('#payment_inst_no').val(res[14]);
			             	$('#payment_bank').val(res[12]);
			             	$('#payment_branch').val(res[13]);
			             	$('#payment_payee').val(res[6]);
			             	$('#payment_narration').val(res[9]);
			             	$('#payment_branch_id').val(res[15]);

			             	$.ajax({
					            url:'/layout/vouchers/payment_dr_edit.php',
					            method:'POST',
					            data:{payment_id:payment_id},
					            success:function(data)
						            {
						            	$('#payment_dr_list').html(data);
									}
				            });
			             	$('#payment_update_btn').show();
			             	$('#payment_save_btn').hide();
							$('#payment_create_modal').modal('show');
    						
						}
		             });
				
			});
		}

		function update_payment_voucher()
		{
			$(document).on('click','#payment_update_btn',function(e){
				e.preventDefault();
				var last_tr_id = $("#payment_dr_list_table tr:last").attr("id");
				var last_tr_select = $("#payment_dr_list_table tr:last option:selected").val();
				var payment_credit_ledger = $('#payment_credit_ledger').val();
				var payment_mode = $('#payment_mode').val();
				var payment_date = $('#payment_date').val();
				var payment_payee = $('#payment_payee').val();
				var payment_amount = $('#payment_amount').val();
				var page = window.location.pathname;
				if (payment_credit_ledger !=="") 
				{
					if (payment_date !=="") 
					{
						if (payment_mode !=="") 
						{
							if (payment_payee !=="") 
							{
								if (payment_amount > 0) 
								{
									if(last_tr_select =="" || last_tr_select ==0)
									{
										$('#'+last_tr_id+'').remove();
									};
									$.ajax({
							             url:'/layout/vouchers/payment_update.php',
							             method:'POST',
							             data:$('#payment_create_form').serialize(),
							             success:function(data)
								             {
								             	$('#payment_create_form').trigger('reset');
								             	window.location.href= page;
								             	//window.location.href="/layout/vouchers/payment_list.php";
								             }
							        });		
								} 
								else 
								{
									alert('Please provide amount for debit ledgers selected!');
								}
							} 
							else 
							{
								alert('Please type the name of the person the payment is being made to!');
							}
						} 
						else 
						{
							alert('Please select the mode of payment!');
						}
					} 
					else 
					{
						alert('Please select the date for the payment voucher!');
					}
				} 
				else 
				{
					alert('Please select the ledger from which payment is being made!');
				};
			});
		}

		function search_payment_by_name()
		{
			$(document).on('keyup','#payment_search_name',function(e){
				e.preventDefault();
				var company_id = $('#session_company_id').val();
				var payment_search_name = $('#payment_search_name').val();

				$.ajax({
		             url:'/layout/vouchers/payment_search_by_name.php',
		             method:'POST',
		             data:{payment_search_name:payment_search_name,company_id:company_id},
		             success:function(data)
			             {
			             	$('#payment_list_card_body').html(data);
			             }
		        });
			});
		}

		function search_payment_by_date()
		{
			$(document).on('click','#payment_search_icon',function(e){
				e.preventDefault();
				var company_id = $('#session_company_id').val();
				var start_date = $('#payment_search_from').val();
				var end_date = $('#payment_search_to').val();

				$.ajax({
		             url:'/layout/vouchers/payment_search_by_date.php',
		             method:'POST',
		             data:{start_date:start_date,end_date:end_date,company_id:company_id},
		             success:function(data)
			             {
			             	$('#payment_list_card_body').html(data);
			             }
		        });
			});
		}

		function delete_payment()
		{
			$(document).on('click','#btn_delete_payment',function(){
				var payment_id = $(this).attr('data-id');
				var currentRow=$(this).closest("tr");
				var payment_date = currentRow.find("td:eq(1)").text();
				$('#payment_delete_question').text('Are you sure you want to delete payment of ' + payment_date + '?');
				$('#payment_delete_modal').modal('show');
				$(document).on('click','#payment_delete_yes',function()
				{
					$.ajax({  
						url:'/layout/vouchers/payment_delete.php',  
						type:'POST',  
						data:{payment_id:payment_id},
						success:function()
						{
							$('#payment_delete_modal').modal('hide');
							window.location.href="/layout/vouchers/payment_list.php";
						}  
		            });
			    });
				$(document).on('click','#payment_delete_no',function(){
					$('#payment_delete_modal').modal('hide');
				});
			});
		}

	//CONTRA
		function new_contra_voucher_modal()
		{
			$(document).on('click','#new_contra_icon',function()
			{
				var company_id = $('#session_company_id').val();
				var user_super_id = $('#session_user_super_id').val();
				var user_id = $('#session_user_id').val();
				$('#contra_company_id').val(company_id);
				$('#contra_user_super_id').val(user_super_id);
				$('#contra_user_id').val(user_id);
				$('#contra_update_btn').hide();
				$('#contra_save_btn').show();
				$('#contra_create_form').trigger('reset');
				$('#contra_create_modal').modal('show');
			});
		}

		function contra_mode_bank_details()
		{
			$(document).on('change keyup','#contra_mode',function()
			{
				var contra_mode = $('#contra_mode').val();
				if(contra_mode =='cheque')
				{
					$("#bank_details_div").prop("hidden",false);
				}else
				{
					$("#bank_details_div").prop("hidden",true);
				};
			});
		}

		function cancel_contra_voucher_modal()
		{
			$(document).on('click','#contra_cancel_btn',function()
			{
				var page = window.location.pathname;
				$('#contra_create_form').trigger('reset');
				$('#contra_create_modal').modal('hide');
				window.location.href= page;
				//window.location.href="/layout/vouchers/contra_list.php";
			});
		}

		function save_contra_voucher()
		{
			$(document).on('click','#contra_save_btn',function(e){
				e.preventDefault();
				var contra_debit_ledger = $('#contra_debit_ledger').val();
				var contra_credit_ledger = $('#contra_credit_ledger').val();
				var contra_mode = $('#contra_mode').val();
				var contra_date = $('#contra_date').val();
				var contra_name = $('#contra_name').val();
				var contra_amount = $('#contra_amount').val();
				var contra_narration = $('#contra_narration').val();
				var page = window.location.pathname;
				if (contra_credit_ledger !=="") 
				{
					if (contra_date !=="") 
					{
						if (contra_mode !=="") 
						{
							if (contra_name !=="") 
							{
								if (contra_amount > 0) 
								{
									if (contra_narration !== "") 
									{
										$.ajax({
								             url:'/layout/vouchers/contra_save.php',
								             method:'POST',
								             data:$('#contra_create_form').serialize(),
								             success:function(data)
									             {
									             	$('#contra_create_form').trigger('reset');
									             	window.location.href= page;
									             	//window.location.href="/layout/vouchers/contra_list.php";
									             }
								        });
								    } 
									else 
									{
										alert('Please the Narration cannot be EMPTY!');
									}
								} 
								else 
								{
									alert('Please provide amount for debit ledgers selected!');
								}
							} 
							else 
							{
								alert('Please type the name of the person the payment is being made to!');
							}
						} 
						else 
						{
							alert('Please select the mode of contra!');
						}
					} 
					else 
					{
						alert('Please select the date for the contra voucher!');
					}
				} 
				else 
				{
					alert('Please select the ledger from which payment is being made!');
				};
			});
		}

		function edit_contra_voucher()
		{
			$(document).on('click','#btn_edit_contra',function(){
				var contra_id = $(this).attr('data-id');
				$.ajax({
			            url:'/layout/vouchers/contra_edit.php',
			            method:'POST',
			            data:{contra_id:contra_id},
						datatype:'JSON',
			            success:function(data)
			            {
			             	var res = $.parseJSON(data);
			             	$('#contra_id').val(res[1]);
			             	$('#contra_company_id').val(res[2]);
			             	$('#contra_user_id').val(res[3]);
			             	$('#contra_user_super_id').val(res[0]);
			             	$('#contra_debit_ledger').val(res[5]);
			             	$('#contra_credit_ledger').val(res[4]);
			             	$('#contra_ref').val(res[10]);
			             	$('#contra_date').val(res[7]);
			             	$('#contra_amount').val(res[8]);
			             	$('#contra_amountD').val(res[8]);
			             	$('#contra_mode').val(res[11]);
			             	$('#contra_inst_no').val(res[14]);
			             	$('#contra_bank').val(res[12]);
			             	$('#contra_branch').val(res[13]);
			             	$('#contra_name').val(res[6]);
			             	$('#contra_narration').val(res[9]);
			             	$('#contra_branch_id').val(res[15]);

			             	$.ajax({
					            url:'/layout/vouchers/contra_dr_edit.php',
					            method:'POST',
					            data:{contra_id:contra_id},
					            success:function(data)
						            {
						            	$('#contra_dr_list').html(data);
									}
				            });
			             	$('#contra_update_btn').show();
			             	$('#contra_save_btn').hide();
							$('#contra_create_modal').modal('show');
    						
						}
		             });
				
			});
		}

		function update_contra_voucher()
		{
			$(document).on('click','#contra_update_btn',function(e){
				e.preventDefault();
				var contra_debit_ledger = $('#contra_debit_ledger').val();
				var contra_credit_ledger = $('#contra_credit_ledger').val();
				var contra_mode = $('#contra_mode').val();
				var contra_date = $('#contra_date').val();
				var contra_name = $('#contra_name').val();
				var contra_amount = $('#contra_amount').val();
				var contra_narration = $('#contra_narration').val();
				var page = window.location.pathname;
				if (contra_credit_ledger !=="") 
				{
					if (contra_date !=="") 
					{
						if (contra_mode !=="") 
						{
							if (contra_name !=="") 
							{
								if (contra_amount > 0) 
								{
									if (contra_narration !== "") 
									{
										$.ajax({
											url:'/layout/vouchers/contra_update.php',
											method:'POST',
											data:$('#contra_create_form').serialize(),
											success:function(data)
											{
												$('#contra_create_form').trigger('reset');
												window.location.href= page;
												//window.location.href="/layout/vouchers/contra_list.php";
											}
								        });
								    } 
									else 
									{
										alert('Please the Narration cannot be EMPTY!');
									}
								} 
								else 
								{
									alert('Please provide amount for debit ledgers selected!');
								}
							} 
							else 
							{
								alert('Please type the name of the person the payment is being made to!');
							}
						} 
						else 
						{
							alert('Please select the mode of contra!');
						}
					} 
					else 
					{
						alert('Please select the date for the contra voucher!');
					}
				} 
				else 
				{
					alert('Please select the ledger from which payment is being made!');
				};
			});
		}

		function search_contra_by_name()
		{
			$(document).on('keyup','#contra_search_name',function(e){
				e.preventDefault();
				var company_id = $('#session_company_id').val();
				var contra_search_name = $('#contra_search_name').val();

				$.ajax({
		             url:'/layout/vouchers/contra_search_by_name.php',
		             method:'POST',
		             data:{contra_search_name:contra_search_name,company_id:company_id},
		             success:function(data)
			             {
			             	$('#contra_list_card_body').html(data);
			             }
		        });
			});
		}

		function search_contra_by_date()
		{
			$(document).on('click','#contra_search_icon',function(e){
				e.preventDefault();
				var company_id = $('#session_company_id').val();
				var start_date = $('#contra_search_from').val();
				var end_date = $('#contra_search_to').val();

				$.ajax({
		             url:'/layout/vouchers/contra_search_by_date.php',
		             method:'POST',
		             data:{start_date:start_date,end_date:end_date,company_id:company_id},
		             success:function(data)
			             {
			             	$('#contra_list_card_body').html(data);
			             }
		        });
			});
		}

		function delete_contra()
		{
			$(document).on('click','#btn_delete_contra',function(){
				var contra_id = $(this).attr('data-id');
				var currentRow=$(this).closest("tr");
				var contra_date = currentRow.find("td:eq(1)").text();
				$('#contra_delete_question').text('Are you sure you want to delete contra of ' + contra_date + '?');
				$('#contra_delete_modal').modal('show');
				$(document).on('click','#contra_delete_yes',function()
				{
					$.ajax({  
						url:'/layout/vouchers/contra_delete.php',  
						type:'POST',  
						data:{contra_id:contra_id},
						success:function()
						{
							$('#contra_delete_modal').modal('hide');
							window.location.href="/layout/vouchers/contra_list.php";
						}  
		            });
			    });
				$(document).on('click','#contra_delete_no',function(){
					$('#contra_delete_modal').modal('hide');
				});
			});
		}
		
	//JOURNAL
		function new_journal_voucher_modal()
		{
			$(document).on('click','#new_journal_icon',function()
			{
				var company_id = $('#session_company_id').val();
				var user_super_id = $('#session_user_super_id').val();
				var user_id = $('#session_user_id').val();
				$('#company_id').val(company_id);
				$('#user_super_id').val(user_super_id);
				$('#user_id').val(user_id);
				$('#journal_update_btn').hide();
				$('#journal_save_btn').show();
				$('#journal_create_form').trigger('reset');
				$('#journal_create_modal').modal('show');
			});
		}

		function cancel_journal_voucher_modal()
		{
			$(document).on('click','#contra_cancel_btn',function()
			{
				var page = window.location.pathname;
				$('#contra_create_form').trigger('reset');
				$('#contra_create_modal').modal('hide');
				window.location.href= page;
			});
		}

		function save_journal_voucher()
		{
			$(document).on('click','#journal_save_btn',function(e){
				e.preventDefault();
				var journal_debit_ledger = $('#journal_debit_ledger').val();
				var journal_credit_ledger = $('#journal_credit_ledger').val();
				var journal_date = $('#journal_date').val();
				var journal_ref = $('#journal_ref').val();
				var journal_narration = $('#journal_narration').val();
				var journal_amount = $('#journal_amount').val();
				var page = window.location.pathname;
				if (journal_debit_ledger !=="") 
				{
					if (journal_credit_ledger !=="") 
					{
						if (journal_credit_ledger !== journal_debit_ledger) 
						{
							if (journal_date !=="") 
							{
								if (journal_amount !=="") 
								{
									if (journal_narration !=="") 
									{
										$.ajax({
											url:'/layout/vouchers/journal_save.php',
											method:'POST',
											data:$('#journal_create_form').serialize(),
											success:function(data)
											{
												$('#journal_create_form').trigger('reset');
												window.location.href= page;
												//window.location.href="/layout/vouchers/journal_list.php";
											}
								        });		
										
									} 
									else 
									{
										alert('The Narration cannot be EMPTY!');
									}
								} 
								else 
								{
									alert('The Amount cannot be EMPTY!');
								}
							} 
							else 
							{
								alert('Please select the date for the Journal Voucher!');
							}
						} 
						else 
						{
							alert('The Credit Ledger cannot be the SAME and the Debit Ledger!');
						};
					} 
					else 
					{
						alert('The Credit Ledger cannot be EMPTY!');
					};
				} 
				else 
				{
					alert('The Debit Ledger cannot be EMPTY!');
				};
			});
		}

		function edit_journal_voucher()
		{
			$(document).on('click','#btn_edit_journal',function(){
				var journal_id = $(this).attr('data-id');
				$.ajax({
		            url:'/layout/vouchers/journal_edit.php',
		            method:'POST',
		            data:{journal_id:journal_id},
					datatype:'JSON',
		            success:function(data)
		            {
		             	var res = $.parseJSON(data);
		             	$('#journal_id').val(res[1]);
		             	$('#company_id').val(res[2]);
		             	$('#user_id').val(res[3]);
		             	$('#user_super_id').val(res[0]);
		             	$('#journal_debit_ledger').val(res[5]);
		             	$('#journal_credit_ledger').val(res[4]);
		             	$('#journal_ref').val(res[9]);
		             	$('#journal_date').val(res[6]);
		             	$('#journal_amount').val(res[7]);
		             	$('#journal_narration').val(res[8]);
		             	$('#journal_branch_id').val(res[10]);
		             	$('#journal_update_btn').show();
		             	$('#journal_save_btn').hide();
						$('#journal_create_modal').modal('show');
					}
	             });
			});
		}

		function update_journal_voucher()
		{
			$(document).on('click','#journal_update_btn',function(e){
				e.preventDefault();
				var journal_debit_ledger = $('#journal_debit_ledger').val();
				var journal_credit_ledger = $('#journal_credit_ledger').val();
				var journal_date = $('#journal_date').val();
				var journal_ref = $('#journal_ref').val();
				var journal_narration = $('#journal_narration').val();
				var journal_amount = $('#journal_amount').val();
				var page = window.location.pathname;
				if (journal_debit_ledger !=="") 
				{
					if (journal_credit_ledger !=="") 
					{
						if (journal_credit_ledger !== journal_debit_ledger) 
						{
							if (journal_date !=="") 
							{
								if (journal_amount !=="") 
								{
									if (journal_narration !=="") 
									{
										
										$.ajax({
											url:'/layout/vouchers/journal_update.php',
											method:'POST',
											data:$('#journal_create_form').serialize(),
											success:function(data)
											{
												$('#journal_create_form').trigger('reset');
												window.location.href= page;
												//window.location.href="/layout/vouchers/journal_list.php";
											}
								        });		
										
									} 
									else 
									{
										alert('The Narration cannot be EMPTY!');
									}
								} 
								else 
								{
									alert('The Amount cannot be EMPTY!');
								}
							} 
							else 
							{
								alert('Please select the date for the Journal Voucher!');
							}
						} 
						else 
						{
							alert('The Credit Ledger cannot be the SAME and the Debit Ledger!');
						};
					} 
					else 
					{
						alert('The Credit Ledger cannot be EMPTY!');
					};
				} 
				else 
				{
					alert('The Debit Ledger cannot be EMPTY!');
				};
			});
		}

		function search_journal_by_name()
		{
			$(document).on('keyup','#journal_search_name',function(e){
				e.preventDefault();
				var company_id = $('#session_company_id').val();
				var journal_search_name = $('#journal_search_name').val();

				$.ajax({
		             url:'/layout/vouchers/journal_search_by_name.php',
		             method:'POST',
		             data:{journal_search_name:journal_search_name,company_id:company_id},
		             success:function(data)
			             {
			             	$('#journal_list_card_body').html(data);
			             }
		        });
			});
		}

		function search_journal_by_date()
		{
			$(document).on('click','#journal_search_icon',function(e){
				e.preventDefault();
				var company_id = $('#session_company_id').val();
				var start_date = $('#journal_search_from').val();
				var end_date = $('#journal_search_to').val();

				$.ajax({
		             url:'/layout/vouchers/journal_search_by_date.php',
		             method:'POST',
		             data:{start_date:start_date,end_date:end_date,company_id:company_id},
		             success:function(data)
			             {
			             	$('#journal_list_card_body').html(data);
			             }
		        });
			});
		}

		function delete_journal()
		{
			$(document).on('click','#btn_delete_journal',function(){
				var journal_id = $(this).attr('data-id');
				var currentRow=$(this).closest("tr");
				var journal_date = currentRow.find("td:eq(1)").text();
				$('#journal_delete_question').text('Are you sure you want to delete journal of ' + journal_date + '?');
				$('#journal_delete_modal').modal('show');
				$(document).on('click','#journal_delete_yes',function()
				{
					$.ajax({  
						url:'/layout/vouchers/journal_delete.php',  
						type:'POST',  
						data:{journal_id:journal_id},
						success:function()
						{
							$('#journal_delete_modal').modal('hide');
							window.location.href="/layout/vouchers/journal_list.php";
						}  
		            });
			    });
				$(document).on('click','#journal_delete_no',function(){
					$('#journal_delete_modal').modal('hide');
				});
			});
		}

	//PURCHASES
		function new_purchase_modal()
		{
			$(document).on('click','#new_purchase_icon',function()
			{
				var company_id = $('#session_company_id').val();
				var user_id = $('#session_user_id').val();
				var user_super_id = $('#session_user_super_id').val();
				$('#purchases_create_form').trigger('reset');
				$('#purch_product').val(1);
				$('#purch_debitD').val(3);
				$('#purch_debit').val(3);
				$('#purch_company_id').val(company_id);
				$('#purch_user_id').val(user_id);
				$('#purch_user_super_id').val(user_super_id);
				$('#purch_update_btn').hide();
				$('#purch_save_btn').show();
				$('#purchase_create_modal').modal('show');
			});
		}

		function purchase_set_supplied_by()
		{
			$(document).on('change','#purch_credit',function()
			{
				var ledger_id = $(this).val();
				var telephone = $('#phone_no').val();
				$.ajax({
					url:'/layout/vouchers/purchases_set_supplied_by.php',
					method:'POST',
					data:{ledger_id:ledger_id},
					success:function(data)
					{
						var res = $.parseJSON(data);
						$('#purch_supplied_by').val(res[0]);
						if(res[1] != '')
						{
							$('#phone_no').val(res[1]);
						};
					}
				});
			});
		}

		function purchase_set_grams()
		{
			$(document).on('keyup','#purch_gram_both',function()
			{
				var purch_gram_both = $(this).val();
				$('#purch_gram').val(purch_gram_both);
			});
		}

		function cancel_purchase_modal()
		{
			$(document).on('click','#purch_cancel_btn',function()
			{
				var page = window.location.pathname;
				$('#purchases_create_form').trigger('reset');
				$('#purchase_create_modal').modal('hide');
				window.location.href= page;
				//window.location.href="/layout/vouchers/purchases_list.php";
			});
		}

		/*ADD COMMAS*/
		function addCommas(x) 
		{
		    var parts = x.toString().split(".");
		    parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
		    return parts.join(".");
		}

		//CALCULATIONS
			/*POUNDS*/
				function purchase_set_pounds()
				{
					$(document).on('keyup','#purch_gram,#purch_water',function(){
						var purch_gram_both = $('#purch_gram_both').val();
						var purch_gram = $('#purch_gram').val();
						var purch_product = $('#purch_product').val();
						if (purch_gram > 0) 
						{
							if(purch_product == 1)
							{
								var pounds = Math.trunc((purch_gram_both / 7.75)*100)/100;
								//var pounds = parseFloat(purch_gram_both / 7.75).toFixed(2);
							}
							else if(purch_product == 2)
							{
								var pounds = Math.trunc((purch_gram_both / 0.8)*100)/100;
								//var pounds = parseFloat(purch_gram_both / 0.80).toFixed(2);
							};
					        $('#purch_pounds').val(pounds);
					        $('#purch_poundsD').val(pounds);
				    	};
					});
				}
			
			/*DENSITY*/
				function purchase_set_density()
				{
					$(document).on('keyup','#purch_gram, #purch_water',function(){
						var purch_gram = $('#purch_gram').val();
						var purch_water = $('#purch_water').val();
						if (purch_gram > 0 && purch_water > 0) 
						{
				        	var density = Math.trunc((purch_gram / purch_water)*100)/100;
							//var density = parseFloat((purch_gram / purch_water)).toFixed(2);
				        	$('#purch_density').val(density);
				        	$('#purch_densityD').val(density);
						};
					});
				}
			
			/*CARAT*/
				function purchase_set_carat()
				{
					$(document).on('keyup','#purch_gram, #purch_water',function(){
						var purch_product = $('#purch_product').val();
						var purch_gram = $('#purch_gram').val();
						var purch_water = $('#purch_water').val();
						if (purch_gram > 0 && purch_water > 0) 
						{
							if(purch_product == 1)
							{
								var density = Math.trunc((purch_gram / purch_water)*100)/100;
								var carat = Math.trunc((((density - 10.51) * 52.838)/density)*100)/100;

								$('#purch_karat').val(carat);
								$('#purch_karatD').val(carat);
							};
				    	};
					});
				}
			
			/*PURITY*/
				function purchase_set_purity()
				{
					$(document).on('keyup','#purch_gram, #purch_water',function(){
						var purch_gram = $('#purch_gram').val();
						var purch_water = $('#purch_water').val();
						if (purch_gram > 0 && purch_water > 0) 
						{
				    		var density = Math.trunc(($('#purch_gram').val() / $('#purch_water').val())*100)/100;
							var carat = Math.trunc((((density - 10.51) * 52.838)/density)*100)/100;
							var purity =Math.trunc(((carat/24)*100)*100)/100;
				        	$('#purch_purity').val(purity);
				        	$('#purch_purityD').val(purity);
			        	};
					});
				}

			/*PRICE_PER_POUND*/
				function purchase_price_per_pound()
				{
					$(document).on('keyup','#purch_price',function(){
						var purch_karat = $('#purch_karat').val();
						var purch_price = $('#purch_price').val();
						if (purch_karat > 0 && purch_price > 0) 
						{
							var price_per_pound = (purch_karat * purch_price)/23;
							var amount = parseFloat(price_per_pound).toFixed(2);
							var ppp = addCommas(amount);
					        $('#purch_ppp').val(amount);
					        $('#purch_pppD').val(ppp);
				    	};
					});
				}
			
			/*AMOUNT*/
				function purchase_set_amount()
				{
					$(document).on('keyup','#purch_gram_both, #purch_gram, #purch_water, #purch_price',function(){
						var purch_gram_both = $('#purch_gram_both').val();
						var purch_gram = $('#purch_gram').val();
						var purch_water = $('#purch_water').val();
						var purch_price = $('#purch_price').val();
						var purch_product = $('#purch_product').val();
						if (purch_gram > 0 && purch_price > 0) 
						{
							var density = Math.trunc((purch_gram / purch_water)*100)/100;

							//var density = parseFloat((purch_gram / purch_water)).toFixed(2);
							var carat = Math.trunc((((density - 10.51) * 52.838)/density)*100)/100;

							if(purch_product == 1)
							{
								var pounds = Math.trunc((purch_gram_both / 7.75)*100)/100;
								//var pounds = parseFloat(purch_gram_both / 7.75).toFixed(3);
								var amount1 = Math.trunc(((carat * $('#purch_price').val())/23)*pounds);
							}
							else if(purch_product == 2)
							{
								//var pounds = parseFloat(purch_gram_both / 0.80).toFixed(2);
								var pounds = Math.trunc((purch_gram_both/0.80)*100)/100;
								var amount1 = Math.trunc($('#purch_price').val()*pounds);
							};
							var amount = addCommas(amount1);
			    			$('#purch_amount').val(amount1);
			    			$('#purch_amountD').val(amount);
			    		};
					});
				}

		function save_purchase_invoice()
		{
			$(document).on('click','#purch_save_btn',function(e){
				e.preventDefault();
				var company_sms = $('#session_company_sms').val();
				var company_sms_bal = $('#session_company_sms_bal').val();
				var purch_debit = $('#purch_debit').val();
				var purch_credit = $('#purch_credit').val();
				var purch_product = $('#purch_product').val();
				var purch_gram = $('#purch_gram').val();
				var purch_gram_both = $('#purch_gram_both').val();
				var purch_water = $('#purch_water').val();
				var purch_date = $('#purch_date').val();
				var purch_price = $('#purch_price').val();
				var purch_karat = $('#purch_karat').val();
				var purch_supplied_by = $('#purch_supplied_by').val();
				var purch_phone = $('#phone_no').val();
				var page = window.location.pathname;
				
				if ((purch_product == 1 && purch_karat < 25) || (purch_product == 2 && purch_karat == '')) 
				{
					if (purch_debit !=="") 
					{
						if (purch_credit !=="") 
						{
							if (purch_product !=="") 
							{
								if (purch_gram_both !=="") 
								{
									if (purch_gram !=="") 
									{
										if (purch_product == 1 && purch_water !="" || purch_product == 2 && purch_water =="") 
										{
											if (purch_date !=="") 
											{
												if (purch_price !=="") 
												{
													if (purch_phone !=="") 
													{
														if (purch_supplied_by !=="") 
														{
															$.ajax({
																url:'/layout/vouchers/purchases_save.php',
																method:'POST',
																data:$('#purchases_create_form').serialize(),
																success:function(data)
																{
																	var purchase_id = data;
																	$('#purchases_create_form').trigger('reset');
																	$('#purchase_create_modal').modal('hide');
																	// if(company_sms == 'Yes')
																	// {
																	// 	if(company_sms_bal > 0)
																	// 	{
																	// 		$('#purchase_send_sms_question').text('Are you sure you want to send sms purchase invoice of ' + purch_date + ' for ' + purch_supplied_by + '?');
																	// 		$('#purchase_send_sms_modal').modal('show');
																	// 		$(document).on('click','#purchase_send_sms_yes',function(){
																	// 			$.ajax({  
																	// 				url:'/layout/vouchers/purchases_send_sms.php',  
																	// 				type:'POST',  
																	// 				data:{purchase_id:purchase_id},
																	// 				success:function(data)
																	// 				{
																	// 					$('#purchase_send_sms_modal').modal('hide');
																	// 					var phone_no = '233' + purch_phone.substring(1, 10);
																	// 					var message = data;
																	// 					window.open('https://sms.isendgh.com/sms/api?action=send-sms&api_key=dGNCT2V3ZEtwa0p4PUp2Y2F3c3k=&to='+phone_no+'&from=Goldchest&sms='+message,'_blank');
																	// 					window.location.href="/layout/vouchers/purchases_list.php";
																	// 					window.open('/layout/vouchers/purchase_pdf.php', '_blank');
																	// 				}  
																	// 			});
																	// 		});
																	// 		$(document).on('click','#purchase_send_sms_no',function(){
																	// 			$('#purchase_send_sms_modal').modal('hide');
																	// 			window.location.href="/layout/vouchers/purchases_list.php";
																	// 			window.open('/layout/vouchers/purchase_pdf.php', '_blank');
																	// 		});
																	// 	}
																	// 	else
																	// 	{
																	// 		alert('Please you do not have sufficient balance in your account to send SMS. Please recharge.');
																	// 		window.location.href="/layout/vouchers/purchases_list.php";
																	// 		window.open('/layout/vouchers/purchase_pdf.php', '_blank');
																	// 	};
																	// }
																	// else
																	// {
																			//window.location.href="/layout/vouchers/purchases_list.php";
																			window.location.href= page;
																			window.open('/layout/vouchers/purchase_pdf.php', '_blank');
																	// };
																}
															});
														} 
														else 
														{
															alert('Please type the Name of the person who brought the goods!');
														};
													} 
													else 
													{
														alert('Please type the Telephone number of the customer!');
													};
												} 
												else 
												{
													alert('Please type the PRICE for item!');
												};
											} 
											else 
											{
												alert('Please select the date of purchase!');
											};
										} 
										else 
										{
											alert('Please type the WATER weight!');
										};
									} 
									else 
									{
										alert('Please type the TOP weight - GRAMS (BIG)!');
									};
								} 
								else 
								{
									alert('Please type the TOP weight - GRAMS (BOTH)!');
								};
							} 
							else 
							{
								alert('Please select the TYPE of Product purchase!');
							};
						} 
						else 
						{
							alert('Please select the ledger from which the purchase was made (Supplier or Cash Account)!');
						};
					} 
					else 
					{
						alert('Please select the ledger into which the purchase was made (Purchases Account)!');
					};
				} 
				else 
				{
					alert('Please the Karat cannot be more than 24!');
				};
			});
		}

		function edit_purchase_invoice()
		{
			$(document).on('click','#btn_edit_purchase',function(){
				var purchase_id = $(this).attr('data-id');
				var company_id = $('#session_company_id').val();
				var user_id = $('#session_user_id').val();
				var user_super_id = $('#session_user_super_id').val();
				$.ajax({
					url:'/layout/vouchers/purchases_edit.php',
					method:'POST',
					data:{purchase_id:purchase_id},
					datatype:'JSON',
					success:function(data)
					{
						var res = $.parseJSON(data);
						$('#purchase_id').val(res[0]);
						$('#purch_date').val(res[1]);
						$('#purch_debit').val(res[2]);
						$('#purch_debitD').val(res[2]);
						$('#purch_credit').val(res[3]);
						$('#purch_amount').val(res[4]);
						$('#purch_amountD').val(res[4]);
						$('#company_id').val(res[5]);
						$('#purch_supplied_by').val(res[6]);
						$('#phone_no').val(res[7]);
						$('#purch_narration').val(res[8]);
						$('#purch_product').val(res[9]);
						$('#purch_gram').val(res[10]);
						$('#purch_water').val(res[11]);
						$('#purch_price').val(res[12]);
						$('#purch_pounds').val(res[13]);
						$('#purch_poundsD').val(res[13]);
						$('#purch_density').val(res[14]);
						$('#purch_densityD').val(res[14]);
						$('#purch_karat').val(res[15]);
						$('#purch_karatD').val(res[15]);
						$('#purch_purity').val(res[16]);
						$('#purch_purityD').val(res[16]);
						$('#purch_ppp').val(res[17]);
						$('#purch_pppD').val(res[17]);
						$('#purch_pieces').val(res[18]);
						$('#purch_location').val(res[19]);
						$('#purch_user_id').val(res[20]);
						$('#purch_site').val(res[21]);
						$('#purch_branch_id').val(res[22]);
						$('#purch_gram_both').val(res[23]);
						$.ajax({
							url:'/layout/vouchers/purchases_items_edit.php',
							method:'POST',
							data:{purchase_id:purchase_id},
							success:function(data)
							{
								$('#purchase_items_list').html(data);
							}
						});
						$('#purch_company_id').val(company_id);
						$('#purch_user_id').val(user_id);
						$('#purch_update_btn').show();
						$('#purch_save_btn').hide();
						$('#purchase_create_modal').modal('show');
					}
				});
			});
		}

		function update_purchase_invoice()
		{
			$(document).on('click','#purch_update_btn',function(e){
				e.preventDefault();
				var purch_debit = $('#purch_debit').val();
				var purch_credit = $('#purch_credit').val();
				var purch_product = $('#purch_product').val();
				var purch_gram = $('#purch_gram').val();
				var purch_gram_both = $('#purch_gram_both').val();
				var purch_water = $('#purch_water').val();
				var purch_date = $('#purch_date').val();
				var purch_price = $('#purch_price').val();
				var purch_karat = $('#purch_karat').val();
				var purch_supplied_by = $('#purch_supplied_by').val();
				
				if ((purch_product == 1 && purch_karat < 25) || (purch_product == 2 && purch_karat == '')) 
				{
					if (purch_debit !=="") 
					{
						if (purch_credit !=="") 
						{
							if (purch_product !=="") 
							{
								if (purch_gram_both !=="") 
								{
									if (purch_gram !=="") 
									{
										if (purch_product == 1 && purch_water !="" || purch_product == 2 && purch_water =="") 
										{
											if (purch_date !=="") 
											{
												if (purch_price !=="") 
												{
													if (purch_supplied_by !=="") 
													{
														$.ajax({
															url:'/layout/vouchers/purchases_update.php',
															method:'POST',
															data:$('#purchases_create_form').serialize(),
															success:function(data)
																{
																	$('#purchases_create_form').trigger('reset');
																	$('#purchase_create_modal').modal('hide');
																	window.location.href="/layout/vouchers/purchases_list.php";
																	window.open('/layout/vouchers/purchase_pdf.php', '_blank');
																
																}
														});

													} 
													else 
													{
														alert('Please type the Name of the person who brought the goods!');
													}
												} 
												else 
												{
													alert('Please type the PRICE for item!');
												}
											} 
											else 
											{
												alert('Please select the date of purchase!');
											};
										} 
										else 
										{
											alert('Please type the WATER weight!');
										};
									} 
									else 
									{
										alert('Please type the TOP weight - GRAMS(BIG)!');
									};
								} 
								else 
								{
									alert('Please type the TOP weight - GRAMS (BOTH)!');
								};
							} 
							else 
							{
								alert('Please select the TYPE of Product purchase!');
							};
						} 
						else 
						{
							alert('Please select the ledger from which the purchase was made (Supplier or Cash Account)!');
						};
					} 
					else 
					{
						alert('Please select the ledger into which the purchase was made (Purchases Account)!');
					};
				} 
				else 
				{
					alert('Please the Karat cannot be more than 24!');
				};
			});
		}

		function delete_purchase_invoice()
		{
			$(document).on('click','#btn_delete_purchase',function(){
				var purchase_id = $(this).attr('data-id');
				var currentRow=$(this).closest("tr");
				var purchase_date = currentRow.find("td:eq(0)").text();
				var Supplier = currentRow.find("td:eq(3)").text();
				$('#purchase_invoice_delete_question').text('Are you sure you want to delete purchase invoice of ' + purchase_date + ' for ' + Supplier + '?');
				$('#purchase_invoice_delete_modal').modal('show');
				$(document).on('click','#purchase_delete_yes',function(){
					$.ajax({  
		                 url:'/layout/vouchers/purchases_delete.php',  
		                 type:'POST',  
		                 data:{purchase_id:purchase_id},
		                 success:function(){
		                 	$('#purchase_invoice_delete_modal').modal('hide');
		                 	window.location.href="/layout/vouchers/purchases_list.php";
		                 }  
		            });
			      });
				$(document).on('click','#purchase_delete_no',function(){
					$('#purchase_invoice_delete_modal').modal('hide');
				});
			});
		}

		function search_purchase_by_name()
		{
			$(document).on('keyup','#purchase_search_name',function(e){
				e.preventDefault();
				var company_id = $('#session_company_id').val();
				var purchase_search_name = $('#purchase_search_name').val();

				$.ajax({
		             url:'/layout/vouchers/purchases_search_by_name.php',
		             method:'POST',
		             data:{purchase_search_name:purchase_search_name,company_id:company_id},
		             success:function(data)
			             {
			             	$('#purchase_list_card_body').html(data);
			             }
		        });
			});
		}

		function search_purchase_by_date()
		{
			$(document).on('click','#purchase_search_icon',function(e){
				e.preventDefault();
				var company_id = $('#session_company_id').val();
				var start_date = $('#purchase_search_from').val();
				var end_date = $('#purchase_search_to').val();

				$.ajax({
		             url:'/layout/vouchers/purchases_search_by_date.php',
		             method:'POST',
		             data:{start_date:start_date,end_date:end_date,company_id:company_id},
		             success:function(data)
			             {
			             	$('#purchase_list_card_body').html(data);
			             }
		        });
			});
		}

		function reprint_purchase_invoice()
		{
			$(document).on('click','#btn_reprint_purchase',function(e){
				var purchase_id = $(this).attr('data-id');
				var ledger_credit_id = $(this).attr('data-id1');
				var company_id = $('#session_company_id').val();
				var user_super_id = $('#session_user_super_id').val();
				var user_id = $('#session_user_id').val();

				$.ajax({
		             url:'/layout/vouchers/purchases_reprint.php',
		             method:'POST',
		             data:{
		             	purchase_id:purchase_id,
		             	company_id:company_id,
		             	user_super_id:user_super_id,
		             	user_id:user_id,
		             	ledger_credit_id:ledger_credit_id
		             },
		             success:function(data)
		             {
		             	//window.open('/layout/vouchers/purchases_display.php', '_blank');
		             	window.open('/layout/vouchers/purchase_pdf.php', '_blank');
		             }
		        });
			});
		}
		
	//BULK PURCHASES
		function new_bulk_purchase_modal()
		{
			$(document).on('click','#new_bulk_purchase_icon',function()
			{
				$('#bulk_purchases_create_form').trigger('reset');
				$('#bulk_purch_product').val(1);
				$('#bulk_purch_debitD').val(3);
				$('#bulk_purch_debit').val(3);
				$('#bulk_purch_update_btn').hide();
				$('#bulk_purch_save_btn').show();
				$('#bulk_purchase_create_modal').modal('show');
			});
		}

		function add_bulk_purchase_item_row()
		{
			$(document).on('click','#bulk_purch_enter_btn',function(){ 
				var i = $('#bulk_purchases_items_table tr:last').attr('id');
				var bulk_purch_product = $('#bulk_purch_product').val();
				var bulk_purch_gram_both = $('#bulk_purch_gram_both').val();
				var bulk_purch_gram = $('#bulk_purch_gram').val();
				var bulk_purch_water = $('#bulk_purch_water').val();
				var bulk_purch_price = $('#bulk_purch_price').val();
				var bulk_purch_amount = $('#bulk_purch_amount').val();
				var bulk_purch_pounds = $('#bulk_purch_pounds').val();
				var bulk_purch_density = $('#bulk_purch_density').val();
				var bulk_purch_karat = $('#bulk_purch_karat').val();
				var bulk_purch_purity = $('#bulk_purch_purity').val();
				var bulk_purch_ppp = $('#bulk_purch_ppp').val();
				var bulk_purch_pieces = $('#bulk_purch_pieces').val();
				var bulk_purch_phone_no = $('#bulk_purch_phone_no').val();
				var bulk_purch_date = $('#bulk_purch_date').val();
				var bulk_purch_debit = $('#bulk_purch_debit').val();
				var bulk_purch_credit = $('#bulk_purch_credit').val();
				var bulk_purch_supplied_by = $('#bulk_purch_supplied_by').val();
				i++;
				
				if ((bulk_purch_product == 1 && bulk_purch_karat < 25) || (bulk_purch_product == 2 && bulk_purch_karat == '')) 
				{
					if (bulk_purch_debit !="") 
					{
						if (bulk_purch_credit !="") 
						{
							if (bulk_purch_product !="") 
							{
								if (bulk_purch_gram_both !="") 
								{
									if (bulk_purch_gram !="") 
									{
										if (bulk_purch_product == 1 && bulk_purch_water !="" || bulk_purch_product == 2 && bulk_purch_water =="") 
										{
											if (bulk_purch_date !="") 
											{
												if (bulk_purch_price !="") 
												{
													if (bulk_purch_phone_no !="") 
													{
														if (bulk_purch_supplied_by !="") 
														{
															$.ajax({
																url:'/layout/vouchers/bulk_purchases_invoice_item_list.php',
																method:'POST',
																data:{
																	i:i,
																	bulk_purch_product:bulk_purch_product,
																	bulk_purch_gram_both:bulk_purch_gram_both,
																	bulk_purch_gram:bulk_purch_gram,
																	bulk_purch_water:bulk_purch_water,
																	bulk_purch_price:bulk_purch_price,
																	bulk_purch_amount:bulk_purch_amount,
																	bulk_purch_pounds:bulk_purch_pounds,
																	bulk_purch_density:bulk_purch_density,
																	bulk_purch_karat:bulk_purch_karat,
																	bulk_purch_purity:bulk_purch_purity,
																	bulk_purch_ppp:bulk_purch_ppp,
																	bulk_purch_pieces:bulk_purch_pieces
																},
																success:function(data)
																{
																	$('#bulk_purchases_items_table').append(data);
																	$('#bulk_purch_gram_both').val('');
																	$('#bulk_purch_gram').val('');
																	$('#bulk_purch_water').val('');
																	$('#bulk_purch_price').val('');
																	$('#bulk_purch_amount').val('');
																	$('#bulk_purch_amountD').val('');
																	$('#bulk_purch_pounds').val('');
																	$('#bulk_purch_poundsD').val('');
																	$('#bulk_purch_density').val('');
																	$('#bulk_purch_densityD').val('');
																	$('#bulk_purch_karat').val('');
																	$('#bulk_purch_karatD').val('');
																	$('#bulk_purch_purity').val('');
																	$('#bulk_purch_purityD').val('');
																	$('#bulk_purch_ppp').val('');
																	$('#bulk_purch_pppD').val('');
																	$('#bulk_purch_pieces').val('');
																	var grams = 0;
																	var water = 0;
																	var pounds = 0;
																	var amount = 0;
																	$(".p_grams").each(function(){grams += +$(this).val();});
																	$("#p_grams_total").val(grams);
																	$(".p_water").each(function(){water += +$(this).val();});
																	$("#p_water_total").val(water);
																	$(".p_pounds").each(function(){pounds += +$(this).val();});
																	$("#p_pounds_total").val(pounds);
																	$(".p_amount").each(function(){amount += +$(this).val();});
																	$("#p_amount_total").val(amount);
																}
															});
														} 
														else 
														{
															alert('Please type the Name of the person who brought the goods!');
														};
													} 
													else 
													{
														alert('Please type the Telephone number of the customer!');
													};
												} 
												else 
												{
													alert('Please type the PRICE for item!');
												};
											} 
											else 
											{
												alert('Please select the date of purchase!');
											};
										} 
										else 
										{
											alert('Please type the WATER weight!');
										};
									} 
									else 
									{
										alert('Please type the TOP weight - GRAMS (BIG)!');
									};
								} 
								else 
								{
									alert('Please type the TOP weight - GRAMS (BOTH)!');
								};
							} 
							else 
							{
								alert('Please select the TYPE of Product purchase!');
							};
						} 
						else 
						{
							alert('Please select the ledger from which the purchase was made (Supplier or Cash Account)!');
						};
					} 
					else 
					{
						alert('Please select the ledger into which the purchase was made (Purchases Account)!');
					};
				} 
				else 
				{
					alert('Please the Karat cannot be more than 24!');
				};
			});
		}

		function delete_bulk_purchase_item_row()
		{
			$(document).on('click', '.delete_bulk_purchase_item', function()
			{  
				var tr_id = $(this).closest("tr").attr("id");
				$('#'+tr_id+'').remove();
				var grams = 0;
				var water = 0;
				var pounds = 0;
				var amount = 0;
				$(".p_grams").each(function(){grams += +$(this).val();});
				$("#p_grams_total").val(grams);
				$(".p_water").each(function(){water += +$(this).val();});
				$("#p_water_total").val(water);
				$(".p_pounds").each(function(){pounds += +$(this).val();});
				$("#p_pounds_total").val(pounds);
				$(".p_amount").each(function(){amount += +$(this).val();});
				$("#p_amount_total").val(amount);
			});
		}

		function bulk_purchase_add_ledger()
		{
			$(document).on('click','#new_bulk_purchase_payment_ledger',function()
			{
				var i = $('#bulk_purhcase_payment_list_table tr:last').attr('id');
				$.ajax({
					url:'/layout/vouchers/bulk_purchase_add_ledger.php',
					method:'POST',
					data:{i:i},
					success:function(data)
					{
						$('#bulk_purhcase_payment_list_table').append(data);
					}
				});
			});
		}

		function bulk_purchase_delete_ledger()
		{
			$(document).on('click', '.btn_delete_bulk_purchase_payment_ledger', function()
			{  
				var tr_id = $(this).closest("tr").attr("id");
				$('#'+tr_id+'').remove();
				var sum = 0;
				$(".bulk_purchase_payment_amount").each(function()
				{
					sum += +$(this).val();
				});
				$("#bulk_purchase_payment_amount_total").val(sum);
			});
		}

		function bulk_purchase_ledger_group_id()
		{
			$(document).on('change','.bulk_purchase_payment_ledger_id',function(){
				var tr_id = $(this).closest('tr').attr('id');
				var ledger_id = $(this).val();
				$.ajax({
					url:'/layout/vouchers/bulk_purchase_ledger_group_id.php',
					method:'POST',
					data:{ledger_id:ledger_id},
					success:function(data)
					{
						$('#bulk_purchase_payment_ledger_group_id'+tr_id).val(data);
					}
				});
			});
		}

		function bulk_purchase_sum_payment_amount()
		{
			$(document).on('keyup', '.bulk_purchase_payment_amount', function()
			{  
				var button_id = $(this).closest('tr').attr('id');
				var ledger_id = $('#bulk_purchase_payment_ledger_id'+button_id).val();
				
				if(ledger_id !='' && ledger_id > 0)
				{
					var sum = 0;
					$(".bulk_purchase_payment_amount").each(function()
					{
						sum += +$(this).val();
					});
					$("#bulk_purchase_payment_amount_total").val(sum);
				}
				else
				{
					$(this).val(0);
					alert('Please select the ledger first!');
				};
			});
		}
	
		function bulk_purchase_set_supplied_by()
		{
			$(document).on('change','#bulk_purch_credit',function()
			{
				var ledger_id = $(this).val();
				var telephone = $('#bulk_phone_no').val();
				$.ajax({
					url:'/layout/vouchers/bulk_purchases_set_supplied_by.php',
					method:'POST',
					data:{ledger_id:ledger_id},
					success:function(data)
					{
						var res = $.parseJSON(data);
						$('#bulk_purch_supplied_by').val(res[0]);
						if(res[1] != '')
						{
							$('#bulk_phone_no').val(res[1]);
						};
					}
				});
			});
		}

		function bulk_purchase_set_grams()
		{
			$(document).on('keyup','#bulk_purch_gram_both',function()
			{
				var purch_gram_both = $(this).val();
				$('#bulk_purch_gram').val(purch_gram_both);
			});
		}

		function cancel_bulk_purchase_modal()
		{
			$(document).on('click','#bulk_purch_cancel_btn',function()
			{
				var page = window.location.pathname;
				$('#bulk_purchases_create_form').trigger('reset');
				$('#bulk_purchase_create_modal').modal('hide');
				window.location.href= page;
				//window.location.href="/layout/vouchers/bulk_purchases_list.php";
			});
		}

		/*ADD COMMAS*/
		function addCommas(x) 
		{
			var parts = x.toString().split(".");
			parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
			return parts.join(".");
		}

		//CALCULATIONS
			/*POUNDS*/
				function bulk_purchase_set_pounds()
				{
					$(document).on('keyup','#bulk_purch_gram,#bulk_purch_water',function(){
						var purch_gram_both = $('#bulk_purch_gram_both').val();
						var purch_gram = $('#bulk_purch_gram').val();
						var purch_product = $('#bulk_purch_product').val();
						if (purch_gram > 0) 
						{
							if(purch_product == 1)
							{
								var pounds = Math.trunc((purch_gram_both / 7.75)*100)/100;
								//var pounds = parseFloat(purch_gram_both / 7.75).toFixed(2);
							}
							else if(purch_product == 2)
							{
								var pounds = Math.trunc((purch_gram_both / 0.8)*100)/100;
							};
							//var pounds = Math.trunc(($('#bulk_purch_gram').val() / 7.75)*100)/100;
							$('#bulk_purch_pounds').val(pounds);
							$('#bulk_purch_poundsD').val(pounds);
						};
					});
				}
			
			/*DENSITY*/
				function bulk_purchase_set_density()
				{
					$(document).on('keyup','#bulk_purch_gram, #bulk_purch_water',function(){
						var purch_gram = $('#bulk_purch_gram').val();
						var purch_water = $('#bulk_purch_water').val();
						if (purch_gram > 0 && purch_water > 0) 
						{
							var density = Math.trunc((purch_gram / purch_water)*100)/100;
							$('#bulk_purch_density').val(density);
							$('#bulk_purch_densityD').val(density);
						};
					});
				}
			
			/*CARAT*/
				function bulk_purchase_set_carat()
				{
					$(document).on('keyup','#bulk_purch_gram, #bulk_purch_water',function(){
						var purch_product = $('#bulk_purch_product').val();
						var purch_gram = $('#bulk_purch_gram').val();
						var purch_water = $('#bulk_purch_water').val();
						if (purch_gram > 0 && purch_water > 0) 
						{
							if(purch_product == 1)
							{
								var density = Math.trunc((purch_gram / purch_water)*100)/100;
								//var density = Math.trunc(($('#bulk_purch_gram').val() / $('#bulk_purch_water').val())*100)/100;
								var carat = Math.trunc((((density - 10.51) * 52.838)/density)*100)/100;
								$('#bulk_purch_karat').val(carat);
								$('#bulk_purch_karatD').val(carat);
							};
						};
					});
				}
			
			/*PURITY*/
				function bulk_purchase_set_purity()
				{
					$(document).on('keyup','#bulk_purch_gram, #bulk_purch_water',function(){
						var purch_gram = $('#bulk_purch_gram').val();
						var purch_water = $('#bulk_purch_water').val();
						if (purch_gram > 0 && purch_water > 0) 
						{
							var density = Math.trunc(($('#bulk_purch_gram').val() / $('#bulk_purch_water').val())*100)/100;
							var carat = Math.trunc((((density - 10.51) * 52.838)/density)*100)/100;
							var purity =Math.trunc(((carat/24)*100)*100)/100;
							$('#bulk_purch_purity').val(purity);
							$('#bulk_purch_purityD').val(purity);
						};
					});
				}

			/*PRICE_PER_POUND*/
				function bulk_purchase_price_per_pound()
				{
					$(document).on('keyup','#bulk_purch_price',function(){
						var purch_karat = $('#bulk_purch_karat').val();
						var purch_price = $('#bulk_purch_price').val();
						if (purch_karat > 0 && purch_price > 0) 
						{
							var price_per_pound = (purch_karat * purch_price)/23;
							var amount = parseFloat(price_per_pound).toFixed(2);
							var ppp = addCommas(amount);
							$('#bulk_purch_ppp').val(amount);
							$('#bulk_purch_pppD').val(ppp);
						};
					});
				}
			
			/*AMOUNT*/
				function bulk_purchase_set_amount()
				{
					$(document).on('keyup','#bulk_purch_gram_both, #bulk_purch_gram, #bulk_purch_water, #bulk_purch_price',function(){
						var purch_gram_both = $('#bulk_purch_gram_both').val();
						var purch_gram = $('#bulk_purch_gram').val();
						var purch_water = $('#bulk_purch_water').val();
						var purch_price = $('#bulk_purch_price').val();
						var purch_product = $('#bulk_purch_product').val();
						if (purch_gram > 0 && purch_price > 0) 
						{
							var density = Math.trunc((purch_gram / purch_water)*100)/100;
							var carat = Math.trunc((((density - 10.51) * 52.838)/density)*100)/100;
							if(purch_product == 1)
							{
								//var pounds = parseFloat(purch_gram_both / 7.75).toFixed(2);
								var pounds = Math.trunc((purch_gram_both / 7.75)*100)/100;
								var amount1 = Math.trunc(((carat * $('#bulk_purch_price').val())/23)*pounds);
							}
							else if(purch_product == 2)
							{
								var pounds = Math.trunc((purch_gram_both/0.80)*100)/100;
								var amount1 = Math.trunc($('#bulk_purch_price').val()*pounds);
							};
							var amount = addCommas(amount1);
							$('#bulk_purch_amount').val(amount1);
							$('#bulk_purch_amountD').val(amount);
						};
					});
				}

		function save_bulk_purchase_invoice()
		{
			$(document).on('click','#bulk_purch_save_btn',function(e){
				e.preventDefault();
				var p_grams_total = $('#p_grams_total').val();
				var p_amount_total = $('#p_amount_total').val();
				var bulk_purch_debit = $('#bulk_purch_debit').val();
				var bulk_purch_credit = $('#bulk_purch_credit').val();
				var bulk_purch_date = $('#bulk_purch_date').val();
				var bulk_purchase_payment_amount_total = $('#bulk_purchase_payment_amount_total').val();
				var page = window.location.pathname;
				
				if (p_grams_total != '' && p_grams_total > 0 ) 
				{
					if (bulk_purch_debit !="") 
					{
						if (bulk_purch_credit !="") 
						{
							if (p_amount_total !="" && p_amount_total > 0) 
							{
								if (bulk_purch_date !="") 
								{
									if (bulk_purchase_payment_amount_total != '' && bulk_purchase_payment_amount_total > 0) 
									{
										$.ajax({
											url:'/layout/vouchers/bulk_purchases_save.php',
											method:'POST',
											data:$('#bulk_purchases_create_form').serialize(),
											success:function(data)
											{
												$('#bulk_purchases_create_form').trigger('reset');
												$('#bulk_purchase_create_modal').modal('hide');
												window.location.href= page;
												window.open('/layout/vouchers/bulk_purchase_pdf.php', '_blank');
											}
										});
									} 
									else 
									{
										alert('Please enter the Cash Amount being paid!');
									};
								} 
								else 
								{
									alert('Please enter the date!');
								};
							} 
							else 
							{
								alert('Please enter the price for the goods purchased!');
							};
						} 
						else 
						{
							alert('Please select the Customer Ledger!');
						};
					} 
					else 
					{
						alert('Please select the Purchases ledger!');
					};
				} 
				else 
				{
					alert('Please enter Grams for goods purchased!');
				};
			});
		}

		function edit_bulk_purchase_invoice()
		{
			$(document).on('click','#btn_edit_bulk_purchase',function(){
				var bulk_purchase_id = $(this).attr('data-id');
				$.ajax({
					url:'/layout/vouchers/bulk_purchases_edit.php',
					method:'POST',
					data:{bulk_purchase_id:bulk_purchase_id},
					datatype:'JSON',
					success:function(data)
					{
						var res = $.parseJSON(data);
						$('#bulk_purchase_id').val(res[0][0]);
						$('#bulk_purch_product').val(1);
						$('#bulk_purch_date').val(res[0][1]);
						$('#bulk_purch_debit').val(res[0][2]);
						$('#bulk_purch_debitD').val(res[0][2]);
						$('#bulk_purch_credit').val(res[0][3]);
						$('#bulk_purch_supplied_by').val(res[0][5]);
						$('#bulk_purch_phone_no').val(res[0][6]);
						$('#bulk_purch_narration').val(res[0][7]);
						$('#bulk_purch_location').val(res[0][8]);

						$('#bulk_purchases_items_table').append(res[1]);
						var grams = 0;
						var water = 0;
						var pounds = 0;
						var amount = 0;
						$(".p_grams").each(function(){grams += +$(this).val();});
						$("#p_grams_total").val(grams);
						$(".p_water").each(function(){water += +$(this).val();});
						$("#p_water_total").val(water);
						$(".p_pounds").each(function(){pounds += +$(this).val();});
						$("#p_pounds_total").val(pounds);
						$(".p_amount").each(function(){amount += +$(this).val();});
						$("#p_amount_total").val(amount);

						$('#bulk_purchase_payment_list_div').html(res[2]);
						$("#bulk_purchase_payment_amount_total").val(res[3]);

						$('#bulk_purch_update_btn').show();
						$('#bulk_purch_save_btn').hide();
						$('#bulk_purchase_create_modal').modal('show');
					}
				});
			});
		}

		function update_bulk_purchase_invoice()
		{
			$(document).on('click','#bulk_purch_update_btn',function(e){
				e.preventDefault();
				var p_grams_total = $('#p_grams_total').val();
				var p_amount_total = $('#p_amount_total').val();
				var bulk_purch_debit = $('#bulk_purch_debit').val();
				var bulk_purch_credit = $('#bulk_purch_credit').val();
				var bulk_purch_date = $('#bulk_purch_date').val();
				var bulk_purchase_payment_amount_total = $('#bulk_purchase_payment_amount_total').val();
				var page = window.location.pathname;
				
				if (p_grams_total != '' && p_grams_total > 0 ) 
				{
					if (bulk_purch_debit !="") 
					{
						if (bulk_purch_credit !="") 
						{
							if (p_amount_total !="" && p_amount_total > 0) 
							{
								if (bulk_purch_date !="") 
								{
									if (bulk_purchase_payment_amount_total != '' && bulk_purchase_payment_amount_total > 0) 
									{
										$.ajax({
											url:'/layout/vouchers/bulk_purchases_update.php',
											method:'POST',
											data:$('#bulk_purchases_create_form').serialize(),
											success:function(data)
											{
												$('#bulk_purchases_create_form').trigger('reset');
												$('#bulk_purchase_create_modal').modal('hide');
												window.location.href= page;
												window.open('/layout/vouchers/bulk_purchase_pdf.php', '_blank');
											}
										});
									} 
									else 
									{
										alert('Please enter the Cash Amount being paid!');
									};
								} 
								else 
								{
									alert('Please enter the date!');
								};
							} 
							else 
							{
								alert('Please enter the price for the goods purchased!');
							};
						} 
						else 
						{
							alert('Please select the Customer Ledger!');
						};
					} 
					else 
					{
						alert('Please select the Purchases ledger!');
					};
				} 
				else 
				{
					alert('Please enter Grams for goods purchased!');
				};
			});
		}

		function search_bulk_purchase_by_name()
		{
			$(document).on('keyup','#bulk_purchase_search_name',function(e){
				e.preventDefault();
				var purchase_search_name = $('#bulk_purchase_search_name').val();

				$.ajax({
					url:'/layout/vouchers/bulk_purchases_search_by_name.php',
					method:'POST',
					data:{purchase_search_name:purchase_search_name},
					success:function(data)
						{
							$('#bulk_purchases_list_table').html(data);
						}
				});
			});
		}

		function search_bulk_purchase_by_date()
		{
			$(document).on('change','#bulk_purchase_search_from, #bulk_purchase_search_to',function(e){
				e.preventDefault();
				var start_date = $('#bulk_purchase_search_from').val();
				var end_date = $('#bulk_purchase_search_to').val();

				$.ajax({
					url:'/layout/vouchers/bulk_purchases_search_by_date.php',
					method:'POST',
					data:{start_date:start_date,end_date:end_date},
					success:function(data)
					{
						$('#bulk_purchases_list_table').html(data);
					}
				});
			});
		}

		function reprint_bulk_purchase_invoice()
		{
			$(document).on('click','#btn_reprint_bulk_purchase',function(){
				var bulk_purchase_id = $(this).attr('data-id');
				var ledger_credit_id = $(this).attr('data-id1');

				$.ajax({
					url:'/layout/vouchers/bulk_purchases_reprint.php',
					method:'POST',
					data:{
						bulk_purchase_id:bulk_purchase_id,
						ledger_credit_id:ledger_credit_id
					},
					success:function(data)
					{
						window.open('/layout/vouchers/bulk_purchase_pdf.php', '_blank');
					}
				});
			});
		}
		
		function delete_bulk_purchase_invoice()
		{
			$(document).on('click','#btn_delete_bulk_purchase',function()
			{
				var bulk_purchase_id = $(this).attr('data-id');
				var currentRow = $(this).closest("tr");
				var sales_date = currentRow.find("td:eq(0)").text();
				var Supplier = currentRow.find("td:eq(1)").text();
				$('#item_delete_question').text('Are you sure you want to delete Bulk Purchase Invoice of ' + sales_date + ' for ' + Supplier + '?');
				$('#item_delete_modal').modal('show');
				$(document).on('click','#item_delete_yes',function()
				{
					$.ajax({  
						url:'/layout/vouchers/bulk_purchases_delete.php',  
						type:'POST',  
						data:{bulk_purchase_id:bulk_purchase_id},
						success:function()
						{
							$('#item_delete_modal').modal('hide');
							window.location.href="/layout/vouchers/bulk_purchases_list.php";
						}  
					});
				});
				$(document).on('click','#item_delete_no',function()
				{
					$('#item_delete_modal').modal('hide');
				});
			});
		}
		
	//STOCK_PURCHASES
		function new_stock_purchase_modal()
		{
			$(document).on('click','#new_stock_purchase_icon',function()
			{
				$('#stock_purch_update_btn').hide();
				$('#stock_purch_save_btn').show();
				$('#stock_purchases_create_form').trigger('reset');
				$('#stock_purchase_create_modal').modal('show');
			});
		}

		function cancel_stock_purchase_modal()
		{
			$(document).on('click','#stock_purch_cancel_btn',function()
			{
				var page = window.location.pathname;
				$('#stock_purchases_create_form').trigger('reset');
				$('#stock_purchase_create_modal').modal('hide');
				window.location.href= page;
				//window.location.href="/layout/vouchers/stock_purchases_list.php";
			});
		}

		function add_stock_purchase_item_row()
		{
			$(document).on('change','.stock_purch_desc',function(){ 
				var i = $('#stock_purchase_items_table tr:last').attr('id');
				i++;
				$.ajax({
					url:'/layout/vouchers/stock_purchases_item_list.php',
					method:'POST',
					data:{i:i},
					success:function(data)
					{
						$('#stock_purchase_items_table').append('<tr id="'+i+'">'+data+'<td><input type="text" name="stock_purch_qty[]" class="form-control bg-light stock_purch_qty" id="stock_purch_qty'+i+'" data-id="'+i+'" style="border-width:0px"></td><td><input type="text" name="stock_purch_price[]" class="form-control bg-light stock_purch_price" id="stock_purch_price'+i+'" data-id="'+i+'" style="border-width:0px"></td><td><input type="text" name="stock_purch_amt[]" class="form-control bg-light" id="stock_purch_amt'+i+'" style="border-width:0px"></td><td><input type="text" name="stock_purch_batch[]" class="form-control bg-light" id="stock_purch_batch'+i+'" style="border-width:0px"></td><td><input type="date" name="stock_purch_expiry_date[]" class="form-control bg-light" id="stock_purch_expiry_date'+i+'" style="border-width:0px"></td><td><a href="#" id="delete_stock_purchase_item" data-id="'+i+'"><i class="fa fa-trash fa-sm"></i></a></td></tr>');
					}
				});
			});
		}

		function get_stock_purchase_item_amount()
		{
			$(document).on('change keyup', '.stock_purch_price, .stock_purch_qty', function(){  
       			var total_current = $('#stock_purch_amount').val();
       			var count = $(this).attr("data-id"); 
       			var qty = $('#stock_purch_qty'+count).val();
       			var price = $('#stock_purch_price'+count).val();
       			var amt_earlier = $('#stock_purch_amt'+count).val();
       			var amt = qty * price;
           		$('#stock_purch_amt'+count).val(amt);

           		var amount_item = parseFloat(amt);
           		if(amt_earlier == ''){var amt_previous = 0 }else{var amt_previous = parseFloat(amt_earlier)};
           		if(total_current == ''){var total_previous = 0 }else{var total_previous = parseFloat($('#stock_purch_amount').val())};
				var total = total_previous + amount_item - amt_previous;
           		$('#stock_purch_amount').val(total);
           		$('#stock_purch_amount_2').val(total);
           	});
		}

		function delete_stock_purchase_item_row()
		{
			$(document).on('click', '#delete_stock_purchase_item', function(){  
       			var button_id = $(this).attr("data-id");
       			var total_current = $('#stock_purch_amount').val();
       			var amt = $('#stock_purch_amt'+button_id).val();
       			if(amt == ''){var amount_item = 0 }else{var amount_item = parseFloat($('#stock_purch_amt'+button_id).val())};
       			if(total_current == ''){var total_previous = 0 }else{var total_previous = parseFloat($('#stock_purch_amount').val())};
				var total = total_previous - amount_item;
           		$('#stock_purch_amount').val(total);
           		$('#stock_purch_amount_2').val(total);
           		$('#'+button_id+'').remove();

           	});
		}

		function save_stock_purchase_invoice()
		{
			$(document).on('click','#stock_purch_save_btn',function(e){
				e.preventDefault();
				var last_tr_id = $("#stock_purchase_items_table tr:last").attr("id");
				var last_tr_select = $("#stock_purchase_items_table tr:last option:selected").val();
				if(last_tr_select =="" || last_tr_select ==0)
				{
					$('#'+last_tr_id+'').remove();
				};
				var purch_debit = $('#stock_purch_debit').val();
				var purch_credit = $('#stock_purch_credit').val();
				var purch_amount = $('#stock_purch_amount').val();
				var purch_supplied_by = $('#stock_purch_supplied_by').val();
				var purch_ref_no = $('#stock_purch_ref_no').val();
				var purch_date = $('#stock_purch_date').val();
				var purch_received_by = $('#stock_purch_received_by').val();
				var purch_narration = $('#stock_purch_narration').val();
				var purch_desc = $('#stock_purch_desc').val();
				var page = window.location.pathname;
				if (purch_debit !=="") 
				{
					if (purch_credit !=="") 
					{
						if (purch_amount !=="") 
						{
							if (purch_supplied_by !=="") 
							{
								if (purch_ref_no !=="") 
								{
									if (purch_date !=="") 
									{
										if (purch_received_by !=="") 
										{
											if (purch_desc !=="") 
											{
												$.ajax({
										             url:'/layout/vouchers/stock_purchases_save.php',
										             method:'POST',
										             data:$('#stock_purchases_create_form').serialize(),
										             success:function(data)
											             {
											             	$('#stock_purchases_create_form').trigger('reset');
											             	window.location.href= page;
											             	//window.location.href="/layout/vouchers/stock_purchases_list.php";
											             }
										             });
											} 
											else 
											{
												alert('Please select an item purchased!');
											}
										} 
										else 
										{
											alert('Please type the name of the person receiving the goods!');
										}
									} 
									else 
									{
										alert('Please select the date of purchase!');
									}
								} 
								else 
								{
									alert('Please type the supplier invoice number!');
								}
							} 
							else 
							{
								alert('Please type the name of the person/institution from whom the purchase was made!');
							}
						} 
						else 
						{
							alert('Please type price for each item purhased!');
						}
					} 
					else 
					{
						alert('Please select the ledger from which the purchase was made (Supplier or Cash Account)!');
					}
				} 
				else 
				{
					alert('Please select the ledger into which the purchase was made (Purchases Account)!');
				};
			});
		}

		function edit_stock_purchase_invoice()
		{
			$(document).on('click','#btn_edit_stock_purchase',function(){
				var stock_purchase_id = $(this).attr('data-id');
				$.ajax({
		             url:'/layout/vouchers/stock_purchases_edit.php',
		             method:'POST',
		             data:{stock_purchase_id:stock_purchase_id},
		             datatype:'JSON',
		             success:function(data)
		             {
		             	var res = $.parseJSON(data);
		             	$('#stock_purchase_id').val(res[0]);
		             	$('#stock_purch_date').val(res[1]);
		             	$('#stock_purch_debit').val(res[2]);
		             	$('#stock_purch_credit').val(res[3]);
		             	$('#stock_purch_amount').val(res[4]);
		             	$('#stock_purch_amount_2').val(res[4]);
		             	$('#stock_purch_ref_no').val(res[5]);
		             	$('#stock_purch_supplied_by').val(res[6]);
		             	$('#stock_purch_received_by').val(res[7]);
		             	$('#stock_purch_narration').val(res[8]);
		             	$('#stock_purchase_branch_id').val(res[9]);
		             	$.ajax({
				            url:'/layout/vouchers/stock_purchases_items_edit.php',
				            method:'POST',
				            data:{stock_purchase_id:stock_purchase_id},
				            success:function(data)
				            {
				            	$('#stock_purchase_items_list').html(data);
							}
			             });
		             	$('#stock_purch_update_btn').show();
		             	$('#stock_purch_save_btn').hide();
						$('#stock_purchase_create_modal').modal('show');
		             }
		        });
			});
		}

		function update_stock_purchase_invoice()
		{
			$(document).on('click','#stock_purch_update_btn',function(e){
				e.preventDefault();

				var last_tr_id = $("#stock_purchase_items_table tr:last").attr("id");
				var last_tr_select = $("#stock_purchase_items_table tr:last option:selected").val();
				if(last_tr_select =="" || last_tr_select ==0)
				{
					$('#'+last_tr_id+'').remove();
				};
				var purch_debit = $('#stock_purch_debit').val();
				var purch_credit = $('#stock_purch_credit').val();
				var purch_amount = $('#stock_purch_amount').val();
				var purch_supplied_by = $('#stock_purch_supplied_by').val();
				var purch_ref_no = $('#stock_purch_ref_no').val();
				var purch_date = $('#stock_purch_date').val();
				var purch_received_by = $('#stock_purch_received_by').val();
				var purch_narration = $('#stock_purch_narration').val();
				var purch_desc = $('#stock_purch_desc').val();
				var page = window.location.pathname;
				if (purch_debit !=="") 
				{
					if (purch_credit !=="") 
					{
						if (purch_amount !=="") 
						{
							if (purch_supplied_by !=="") 
							{
								if (purch_ref_no !=="") 
								{
									if (purch_date !=="") 
									{
										if (purch_received_by !=="") 
										{
											if (purch_desc !=="") 
											{
												$.ajax({
										             url:'/layout/vouchers/stock_purchases_update.php',
										             method:'POST',
										             data:$('#stock_purchases_create_form').serialize(),
										             success:function(data)
											             {
											             	$('#stock_purchases_create_form').trigger('reset');
											             	window.location.href= page;
											             }
										             });
											} 
											else 
											{
												alert('Please select an item purchased!');
											}
										} 
										else 
										{
											alert('Please type the name of the person receiving the goods!');
										}
									} 
									else 
									{
										alert('Please select the date of purchase!');
									}
								} 
								else 
								{
									alert('Please type the supplier invoice number!');
								}
							} 
							else 
							{
								alert('Please type the name of the person/institution from whom the purchase was made!');
							}
						} 
						else 
						{
							alert('Please type price for each item purhased!');
						}
					} 
					else 
					{
						alert('Please select the ledger from which the purchase was made (Supplier or Cash Account)!');
					}
				} 
				else 
				{
					alert('Please select the ledger into which the purchase was made (Purchases Account)!');
				};
			});
		}
		
		function search_stock_purchase_by_name()
		{
			$(document).on('keyup','#stock_purchase_name',function(e){
				e.preventDefault();
				var company_id = $('#session_company_id').val();
				var stock_purchase_name = $('#stock_purchase_name').val();

				$.ajax({
					url:'/layout/vouchers/stock_purchases_search_by_name.php',
					method:'POST',
					data:{stock_purchase_name:stock_purchase_name,company_id:company_id},
					success:function(data)
					{
						$('#stock_purchases_list_table').html(data);
					}
		        });
			});
		}

		function search_stock_purchase_by_date()
		{
			$(document).on('click','#stock_purchase_search_icon',function(e){
				e.preventDefault();
				var company_id = $('#session_company_id').val();
				var start_date = $('#stock_purchase_search_from').val();
				var end_date = $('#stock_purchase_search_to').val();

				$.ajax({
		             url:'/layout/vouchers/stock_purchases_search_by_date.php',
		             method:'POST',
		             data:{start_date:start_date,end_date:end_date,company_id:company_id},
		             success:function(data)
			             {
			             	$('#stock_purchases_list_table').html(data);
			             }
		        });
			});
		}

		function delete_stock_purchase_invoice()
		{
			$(document).on('click','#btn_delete_stock_purchase',function(){
				var stock_purchase_id = $(this).attr('data-id');
				var currentRow=$(this).closest("tr");
				var purchase_date = currentRow.find("td:eq(0)").text();
				var Supplier = currentRow.find("td:eq(2)").text();
				$('#stock_purchase_invoice_delete_question').text('Are you sure you want to delete purchase invoice of ' + purchase_date + ' for ' + Supplier + '?');
				$('#stock_purchase_invoice_delete_modal').modal('show');
				$(document).on('click','#stock_purchase_delete_yes',function(){
					$.ajax({  
		                 url:'/layout/vouchers/stock_purchases_delete.php',  
		                 type:'POST',  
		                 data:{stock_purchase_id:stock_purchase_id},
		                 success:function(){
		                 	$('#stock_purchase_invoice_delete_modal').modal('hide');
		                 	window.location.href="/layout/vouchers/stock_purchases_list.php";
		                 }  
		            });
			      });
				$(document).on('click','#stock_purchase_delete_no',function(){
					$('#stock_purchase_invoice_delete_modal').modal('hide');
				});
			});
		}

	//HIRING
		function new_hiring_modal()
		{
			$(document).on('click','#new_hiring_icon',function()
			{
				$('#hiring_update_btn').hide();
				$('#hiring_save_btn').show();
				$('#hiring_create_form').trigger('reset');
				$('#hiring_create_modal').modal('show');
			});
		}

		function cancel_hiring_modal()
		{
			$(document).on('click','#hiring_cancel_btn',function()
			{
				var page = window.location.pathname;
				$('#hiring_create_form').trigger('reset');
				$('#hiring_create_modal').modal('hide');
				window.location.href= page;
				//window.location.href="/layout/vouchers/hiring_list.php";
			});
		}

		function add_hiring_item_row()
		{
			$(document).on('change','.hiring_asset_id',function(){ 
				var i = $('#hiring_items_table tr:last').attr('id');
				i++;
				$.ajax({
					url:'/layout/vouchers/hiring_item_list.php',
					method:'POST',
					data:{i:i},
					success:function(data)
					{
						$('#hiring_items_table').append(data);
					}
				});
			});
		}

		function get_hiring_item_amount()
		{
			$(document).on('change keyup', '.hiring_rate, .hiring_hour', function(){  
       			var total_current = $('#hiring_amount').val();
       			var count = $(this).attr("data-id"); 
       			var qty = $('#hiring_hour'+count).val();
       			var price = $('#hiring_rate'+count).val();
       			var amt_earlier = $('#hiring_amt'+count).val();
       			var amt = qty * price;
           		$('#hiring_amt'+count).val(amt);

           		var amount_item = parseFloat(amt);
           		if(amt_earlier == ''){var amt_previous = 0 }else{var amt_previous = parseFloat(amt_earlier)};
           		if(total_current == ''){var total_previous = 0 }else{var total_previous = parseFloat($('#hiring_amount').val())};
				var total = total_previous + amount_item - amt_previous;
           		$('#hiring_amount').val(total);
           		$('#hiring_amount_2').val(total);
           	});
		}

		function delete_hiring_item_row()
		{
			$(document).on('click', '#delete_hiring_item', function(){  
       			var button_id = $(this).attr("data-id");
       			var total_current = $('#hiring_amount').val();
       			var amt = $('#hiring_amt'+button_id).val();
       			if(amt == ''){var amount_item = 0 }else{var amount_item = parseFloat($('#hiring_amt'+button_id).val())};
       			if(total_current == ''){var total_previous = 0 }else{var total_previous = parseFloat($('#hiring_amount').val())};
				var total = total_previous - amount_item;
           		$('#hiring_amount').val(total);
           		$('#hiring_amount_2').val(total);
           		$('#'+button_id+'').remove();

           	});
		}

		function save_hiring_invoice()
		{
			$(document).on('click','#hiring_save_btn',function(e){
				e.preventDefault();
				var last_tr_id = $("#hiring_items_table tr:last").attr("id");
				var last_tr_select = $("#hiring_items_table tr:last option:selected").val();
				if(last_tr_select =="" || last_tr_select ==0)
				{
					$('#'+last_tr_id+'').remove();
				};
				var hiring_debit = $('#hiring_debit').val();
				var hiring_credit = $('#hiring_credit').val();
				var hiring_amount = $('#hiring_amount').val();
				var hiring_by = $('#hiring_by').val();
				var hiring_address = $('#hiring_address').val();
				var hiring_date = $('#hiring_date').val();
				var hiring_phone = $('#hiring_phone').val();
				var hiring_narration = $('#hiring_narration').val();
				var hiring_asset_id = $('#hiring_asset_id').val();
				var page = window.location.pathname;
				if (hiring_debit !=="") 
				{
					if (hiring_credit !=="") 
					{
						if (hiring_amount !=="") 
						{
							if (hiring_by !=="") 
							{
								if (hiring_address !=="") 
								{
									if (hiring_date !=="") 
									{
										if (hiring_phone !=="") 
										{
											if (hiring_asset_id !=="") 
											{
												$.ajax({
										             url:'/layout/vouchers/hiring_save.php',
										             method:'POST',
										             data:$('#hiring_create_form').serialize(),
										             success:function(data)
											             {
											             	$('#hiring_create_form').trigger('reset');
															window.open('/layout/vouchers/hiring_invoice_pdf.php', '_blank');
											             	window.location.href= page;
											             	//window.location.href="/layout/vouchers/hiring_list.php";
											             }
										        });
											} 
											else 
											{
												alert('Please select an item hired!');
											};
										} 
										else 
										{
											alert('Please type the phone number of the person hiring!');
										};
									} 
									else 
									{
										alert('Please select the date of hiring!');
									};
								} 
								else 
								{
									alert('Please type the address of the person hiring!');
								};
							} 
							else 
							{
								alert('Please type the name of the person/institution hiring!');
							};
						} 
						else 
						{
							alert('Please type price for each item hired!');
						};
					} 
					else 
					{
						alert('Please select the Hiring Charges ledger!');
					};
				} 
				else 
				{
					alert('Please select the Cash/Customer ledger!');
				};
			});
		}

		function edit_hring_invoice()
		{
			$(document).on('click','#btn_edit_hiring',function(){
				var hiring_id = $(this).attr('data-id');
				$.ajax({
		             url:'/layout/vouchers/hiring_edit.php',
		             method:'POST',
		             data:{hiring_id:hiring_id},
		             datatype:'JSON',
		             success:function(data)
		             {
		             	var res = $.parseJSON(data);
		             	$('#hiring_id').val(res[0]);
		             	$('#hiring_date').val(res[1]);
		             	$('#hiring_debit').val(res[2]);
		             	$('#hiring_credit').val(res[3]);
		             	$('#hiring_amount').val(res[4]);
		             	$('#hiring_amount_2').val(res[4]);
		             	$('#hiring_by').val(res[5]);
		             	$('#hiring_address').val(res[6]);
		             	$('#hiring_phone').val(res[7]);
		             	$('#hiring_narration').val(res[8]);
		             	$('#hiring_branch_id').val(res[9]);
		             	$.ajax({
				            url:'/layout/vouchers/hiring_items_edit.php',
				            method:'POST',
				            data:{hiring_id:hiring_id},
				            success:function(data)
				            {
				            	$('#hiring_items_list').html(data);
							}
			             });
		             	$('#hiring_update_btn').show();
		             	$('#hiring_save_btn').hide();
						$('#hiring_create_modal').modal('show');
		             }
		        });
			});
		}

		function update_hiring_invoice()
		{
			$(document).on('click','#hiring_update_btn',function(e)
			{
				e.preventDefault();
				var last_tr_id = $("#hiring_items_table tr:last").attr("id");
				var last_tr_select = $("#hiring_items_table tr:last option:selected").val();
				if(last_tr_select =="" || last_tr_select ==0)
				{
					$('#'+last_tr_id+'').remove();
				};
				var hiring_debit = $('#hiring_debit').val();
				var hiring_credit = $('#hiring_credit').val();
				var hiring_amount = $('#hiring_amount').val();
				var hiring_by = $('#hiring_by').val();
				var hiring_address = $('#hiring_address').val();
				var hiring_date = $('#hiring_date').val();
				var hiring_phone = $('#hiring_phone').val();
				var hiring_narration = $('#hiring_narration').val();
				var hiring_asset_id = $('#hiring_asset_id').val();
				var page = window.location.pathname;
				if (hiring_debit !=="") 
				{
					if (hiring_credit !=="") 
					{
						if (hiring_amount !=="") 
						{
							if (hiring_by !=="") 
							{
								if (hiring_address !=="") 
								{
									if (hiring_date !=="") 
									{
										if (hiring_phone !=="") 
										{
											if (hiring_asset_id !=="") 
											{
												$.ajax({
										             url:'/layout/vouchers/hiring_update.php',
										             method:'POST',
										             data:$('#hiring_create_form').serialize(),
										             success:function(data)
											             {
											             	$('#hiring_create_form').trigger('reset');
															window.open('/layout/vouchers/hiring_invoice_pdf.php', '_blank');
											             	window.location.href= page;
											             	//window.location.href="/layout/vouchers/hiring_list.php";
											             }
										        });
											} 
											else 
											{
												alert('Please select an item hired!');
											};
										} 
										else 
										{
											alert('Please type the phone number of the person hiring!');
										};
									} 
									else 
									{
										alert('Please select the date of hiring!');
									};
								} 
								else 
								{
									alert('Please type the address of the person hiring!');
								};
							} 
							else 
							{
								alert('Please type the name of the person/institution hiring!');
							};
						} 
						else 
						{
							alert('Please type price for each item hired!');
						};
					} 
					else 
					{
						alert('Please select the Hiring Charges ledger!');
					};
				} 
				else 
				{
					alert('Please select the Cash/Customer ledger!');
				};
			});
		}
		
		function search_hiring_invoice_by_name()
		{
			$(document).on('keyup','#hiring_name',function(e){
				e.preventDefault();
				var company_id = $('#session_company_id').val();
				var name = $('#hiring_name').val();

				$.ajax({
					url:'/layout/vouchers/hiring_search_by_name.php',
					method:'POST',
					data:{name:name,company_id:company_id},
					success:function(data)
					{
						$('#hiring_list_table').html(data);
					}
		        });
			});
		}

		function search_hiring_invoice_by_date()
		{
			$(document).on('click','#hiring_search_icon',function(e){
				e.preventDefault();
				var company_id = $('#session_company_id').val();
				var start_date = $('#hiring_search_from').val();
				var end_date = $('#hiring_search_to').val();

				$.ajax({
		             url:'/layout/vouchers/hiring_search_by_date.php',
		             method:'POST',
		             data:{start_date:start_date,end_date:end_date,company_id:company_id},
		             success:function(data)
			             {
			             	$('#hiring_list_table').html(data);
			             }
		        });
			});
		}

		function delete_hiring_invoice()
		{
			$(document).on('click','#btn_delete_hiring',function(){
				var hiring_id = $(this).attr('data-id');
				var currentRow=$(this).closest("tr");
				var hiring_date = currentRow.find("td:eq(0)").text();
				var hired_by = currentRow.find("td:eq(2)").text();
				$('#hiring_invoice_delete_question').text('Are you sure you want to delete hiring invoice of ' + hiring_date + ' for ' + hired_by + '?');
				$('#hiring_invoice_delete_modal').modal('show');
				$(document).on('click','#hiring_delete_yes',function(){
					$.ajax({  
						url:'/layout/vouchers/hiring_delete.php',  
						type:'POST',  
						data:{hiring_id:hiring_id},
						success:function(){
							$('#stock_purchase_invoice_delete_modal').modal('hide');
							window.location.href="/layout/vouchers/hiring_list.php";
						}
		            });
			      });
				$(document).on('click','#hiring_delete_no',function(){
					$('#hiring_invoice_delete_modal').modal('hide');
				});
			});
		}

	//MAINTENANCE SHEET
		function new_mtce_modal()
		{
			$(document).on('click','#new_mtce_icon',function()
			{
				$('#mtce_update_btn').hide();
				$('#mtce_save_btn').show();
				$('#mtce_create_form').trigger('reset');
				$('#mtce_create_modal').modal('show');
			});
		}

		function cancel_mtce_modal()
		{
			$(document).on('click','#mtce_cancel_btn',function()
			{
				var page = window.location.pathname;
				$('#mtce_create_form').trigger('reset');
				$('#mtce_create_modal').modal('hide');
				window.location.href= page;
				//window.location.href="/layout/vouchers/mtce_list.php";
			});
		}

		function add_mtce_item_price()
		{
			$(document).on('change','.mtce_stock_id',function(){
				var i = $(this).closest('tr').attr('id');
				var stock_item_id = $('#mtce_stock_id'+i+'').val();
				$.ajax({
		             url:'/layout/vouchers/mtce_item_price.php',
		             method:'POST',
		             data:{stock_item_id:stock_item_id},
		             datatype:'JSON',
		             success:function(data)
		             {
		             	var res = $.parseJSON(data);
		             	$('#mtce_stock_price'+i+'').val(res[0]);
		             }
		        });
			});
		}

		function add_mtce_service_item_row()
		{
			$(document).on('change','.mtce_service_asset_id',function(){ 
				var i = $('#mtce_service_items_table tr:last').attr('id');
				i++;
				$.ajax({
					url:'/layout/vouchers/mtce_service_list.php',
					method:'POST',
					data:{i:i},
					success:function(data)
					{
						$('#mtce_service_items_table').append(data);
					}
				});
			});
		}

		function add_mtce_stock_item_row()
		{
			$(document).on('change','.mtce_stock_id',function(){ 
				var i = $('#mtce_stock_items_table tr:last').attr('id');
				i++;
				$.ajax({
					url:'/layout/vouchers/mtce_stock_list.php',
					method:'POST',
					data:{i:i},
					success:function(data)
					{
						$('#mtce_stock_items_table').append(data);
					}
				});
			});
		}

		function get_mtce_service_item_amount()
		{
			$(document).on('change keyup', '.mtce_service_amt', function(){ 
				var total_stock = $('#mtce_amount_stock').val();
				if(total_stock == '' ){var mtce_amount_stock = 0;}else{var mtce_amount_stock = parseFloat(total_stock);};
       			var sum = 0;
				$('.mtce_service_amt').each(function(){
					var num = $(this).val().replace(',','');
					if(num !=0)
					{
						sum += parseFloat(num);
					};
				});
				$('#mtce_amount_cash').val(sum);
				$('#mtce_amount_cash_2').val(sum);

				var grand_total = sum + mtce_amount_stock;
				$('#mtce_amount').val(grand_total);
				$('#mtce_amount_2').val(grand_total);
           	});
		}

		function get_mtce_stock_item_amount()
		{
			$(document).on('change keyup', '.mtce_stock_qty, .mtce_stock_price', function(){  
       			var total_service = $('#mtce_amount_cash').val();
				if(total_service == ''){var mtce_amount_service = 0;}else{var mtce_amount_service = parseFloat(total_service);};
       			
       			var total_current = $('#mtce_amount_stock').val();
       			var count = $(this).attr("data-id"); 
       			var qty = $('#mtce_stock_qty'+count).val();
       			var price = $('#mtce_stock_price'+count).val();
       			var amt_earlier = $('#mtce_stock_amt'+count).val();
       			var amt = qty * price;
           		$('#mtce_stock_amt'+count).val(amt);

           		var amount_item = parseFloat(amt);
           		if(amt_earlier == ''){var amt_previous = 0;}else{var amt_previous = parseFloat(amt_earlier);};
           		if(total_current == ''){var total_previous = 0;}else{var total_previous = parseFloat($('#mtce_amount_stock').val());};
				var total = total_previous + amount_item - amt_previous;
           		$('#mtce_amount_stock').val(total);
           		$('#mtce_amount_stock_2').val(total);

           		var grand_total = total + mtce_amount_service;
           		$('#mtce_amount').val(grand_total);
           		$('#mtce_amount_2').val(grand_total);
           	});
		}

		function delete_mtce_service_item_row()
		{
			$(document).on('click', '#delete_mtce_service_item', function(){  
       			var button_id = $(this).attr("data-id");
       			var grand_total = $('#mtce_amount').val();
       			var total_service = $('#mtce_amount_cash').val();

       			var amt = $('#mtce_service_amt'+button_id).val();
       			if(amt == ''){var amount_item = 0 }else{var amount_item = parseFloat($('#mtce_service_amt'+button_id).val())};

       			if(total_service == ''){var total_service_previous = 0;}else{var total_service_previous = parseFloat($('#mtce_amount_cash').val());};
       			if(grand_total == ''){var grand_total_previous = 0;}else{var grand_total_previous = parseFloat($('#mtce_amount').val());};

				var new_total_service = total_service_previous - amount_item;
				var new_grand_total = grand_total_previous - amount_item;
           		$('#mtce_amount_cash').val(new_total_service);
           		$('#mtce_amount_cash_2').val(new_total_service);
           		$('#mtce_amount').val(new_grand_total);
           		$('#mtce_amount_2').val(new_grand_total);
           		$('#'+button_id+'').remove();
           	});
		}

		function delete_mtce_stock_item_row()
		{
			$(document).on('click', '#delete_mtce_stock_item', function(){  
       			var button_id = $(this).attr("data-id");
       			var grand_total = $('#mtce_amount').val();
       			var total_stock = $('#mtce_amount_stock').val();

       			var amt = $('#mtce_stock_amt'+button_id).val();
       			if(amt == ''){var amount_item = 0 }else{var amount_item = parseFloat($('#mtce_stock_amt'+button_id).val())};

       			if(total_stock == ''){var total_stock_previous = 0;}else{var total_stock_previous = parseFloat($('#mtce_amount_stock').val());};
       			if(grand_total == ''){var grand_total_previous = 0;}else{var grand_total_previous = parseFloat($('#mtce_amount').val());};

				var new_total_stock = total_stock_previous - amount_item;
				var new_grand_total = grand_total_previous - amount_item;
           		$('#mtce_amount_stock').val(new_total_stock);
           		$('#mtce_amount_stock_2').val(new_total_stock);
           		$('#mtce_amount').val(new_grand_total);
           		$('#mtce_amount_2').val(new_grand_total);
           		$('#'+button_id+'').remove();
           	});
		}

		function save_mtce_invoice()
		{
			$(document).on('click','#mtce_save_btn',function(e){
				e.preventDefault();
				var last_tr_id_service = $("#mtce_service_items_table tr:last").attr("id");
				var last_tr_select_service = $("#mtce_service_items_table tr:last option:selected").val();
				var last_tr_id_stock = $("#mtce_stock_items_table tr:last").attr("id");
				var last_tr_select_stock = $("#mtce_stock_items_table tr:last option:selected").val();
				var mtce_debit = $('#mtce_debit').val();
				var mtce_amount = $('#mtce_amount').val();
				var mtce_credit_cash = $('#mtce_credit_cash').val();
				var mtce_amount_cash = $('#mtce_amount_cash').val();
				var mtce_credit_stock = $('#mtce_credit_stock').val();
				var mtce_amount_stock = $('#mtce_amount_stock').val();
				var mtce_date = $('#mtce_date').val();
				var serviced_by = $('#serviced_by').val();
				var mtce_address = $('#mtce_address').val();
				var mtce_phone = $('#mtce_phone').val();
				var mtce_narration = $('#mtce_narration').val();
				var page = window.location.pathname;
				if (mtce_debit !=="") 
				{
					if (mtce_amount !=="") 
					{
						if (serviced_by !=="") 
						{
							if (mtce_address !=="") 
							{
								if (mtce_date !=="") 
								{
									if (mtce_phone !=="") 
									{
										if (mtce_credit_cash !=="") 
										{
											if (mtce_credit_stock !=="") 
											{
												if (mtce_credit_stock !== mtce_debit) 
												{
													if(last_tr_select_service =="" || last_tr_select_service ==0)
													{
														$('#'+last_tr_id_service +'').remove();
													};
													if(last_tr_select_stock =="" || last_tr_select_stock ==0)
													{
														$('#'+last_tr_id_stock +'').remove();
													};
													$.ajax({
											             url:'/layout/vouchers/mtce_save.php',
											             method:'POST',
											             data:$('#mtce_create_form').serialize(),
											             success:function(data)
											             {
											             	$('#mtce_create_form').trigger('reset');
											             	window.location.href= page;
											             	//window.location.href="/layout/vouchers/mtce_list.php";
											             }
											        });
										        } 
												else 
												{
													alert('Please Debit and Credit - Stock cannot be the same!');
												};
											} 
											else 
											{
												alert('Please select the Stock Consumption Ledger!');
											};
										} 
										else 
										{
											alert('Please select the cash/bank ledger paying or the name of the person who did the servicing, if its on credit!');
										};
									} 
									else 
									{
										alert('Please type the phone number of the person who serviced the item!');
									};
								} 
								else 
								{
									alert('Please select the date of servicing!');
								};
							} 
							else 
							{
								alert('Please type the address of the person who did the servicing!');
							};
						} 
						else 
						{
							alert('Please type the name of the person/institution who did the servicing!');
						};
					} 
					else 
					{
						alert('Please select the provide the service component and their amount!');
					};
				} 
				else 
				{
					alert('Please select the Expenditure ledger!');
				};
			});
		}

		function edit_mtce_invoice()
		{
			$(document).on('click','#btn_edit_mtce',function(){
				var mtce_sheet_id = $(this).attr('data-id');
				$.ajax({
		             url:'/layout/vouchers/mtce_edit.php',
		             method:'POST',
		             data:{mtce_sheet_id:mtce_sheet_id},
		             datatype:'JSON',
		             success:function(data)
		             {
		             	var res = $.parseJSON(data);
		             	$('#mtce_sheet_id').val(res[0]);
		             	$('#mtce_debit').val(res[1]);
		             	$('#mtce_credit_cash').val(res[2]);
		             	$('#mtce_credit_stock').val(res[3]);
		             	$('#mtce_date').val(res[4]);
		             	$('#mtce_amount_cash').val(res[5]);
		             	$('#mtce_amount_cash_2').val(res[5]);
		             	$('#mtce_amount_stock').val(res[6]);
		             	$('#mtce_amount_stock_2').val(res[6]);
		             	$('#mtce_amount').val(res[7]);
		             	$('#mtce_amount_2').val(res[7]);
		             	$('#serviced_by').val(res[8]);
		             	$('#mtce_address').val(res[9]);
		             	$('#mtce_phone').val(res[10]);
		             	$('#mtce_narration').val(res[11]);
		             	$('#mtce_sheet_branch_id').val(res[12]);
		             	$.ajax({
				            url:'/layout/vouchers/mtce_service_list_edit.php',
				            method:'POST',
				            data:{mtce_sheet_id:mtce_sheet_id},
				            success:function(data)
				            {
				            	$('#mtce_service_items_list').html(data);
							}
			             });
		             	$.ajax({
				            url:'/layout/vouchers/mtce_stock_list_edit.php',
				            method:'POST',
				            data:{mtce_sheet_id:mtce_sheet_id},
				            success:function(data)
				            {
				            	$('#mtce_stock_items_list').html(data);
							}
			             });
		             	$('mtce_update_btn').show();
		             	$('#mtce_save_btn').hide();
						$('#mtce_create_modal').modal('show');
		             }
		        });
			});
		}

		function update_mtce_invoice()
		{
			$(document).on('click','#mtce_update_btn',function(e){
				e.preventDefault();
				var last_tr_id_service = $("#mtce_service_items_table tr:last").attr("id");
				var last_tr_select_service = $("#mtce_service_items_table tr:last option:selected").val();
				var last_tr_id_stock = $("#mtce_stock_items_table tr:last").attr("id");
				var last_tr_select_stock = $("#mtce_stock_items_table tr:last option:selected").val();
				var mtce_debit = $('#mtce_debit').val();
				var mtce_amount = $('#mtce_amount').val();
				var mtce_credit_cash = $('#mtce_credit_cash').val();
				var mtce_amount_cash = $('#mtce_amount_cash').val();
				var mtce_credit_stock = $('#mtce_credit_stock').val();
				var mtce_amount_stock = $('#mtce_amount_stock').val();
				var mtce_date = $('#mtce_date').val();
				var serviced_by = $('#serviced_by').val();
				var mtce_address = $('#mtce_address').val();
				var mtce_phone = $('#mtce_phone').val();
				var mtce_narration = $('#mtce_narration').val();
				var page = window.location.pathname;
				if (mtce_debit !=="") 
				{
					if (mtce_amount !=="") 
					{
						if (serviced_by !=="") 
						{
							if (mtce_address !=="") 
							{
								if (mtce_date !=="") 
								{
									if (mtce_phone !=="") 
									{
										if (mtce_credit_cash !=="") 
										{
											if (mtce_credit_stock !=="") 
											{
												if (mtce_credit_stock !== mtce_debit) 
												{
													if(last_tr_select_service =="" || last_tr_select_service ==0)
													{
														$('#'+last_tr_id_service +'').remove();
													};
													if(last_tr_select_stock =="" || last_tr_select_stock ==0)
													{
														$('#'+last_tr_id_stock +'').remove();
													};
													$.ajax({
											             url:'/layout/vouchers/mtce_update.php',
											             method:'POST',
											             data:$('#mtce_create_form').serialize(),
											             success:function(data)
											             {
											             	$('#mtce_create_form').trigger('reset');
											             	window.location.href= page;
											             	//window.location.href="/layout/vouchers/mtce_list.php";
											             }
											        });
										        } 
												else 
												{
													alert('Please Debit and Credit - Stock cannot be the same!');
												};
											} 
											else 
											{
												alert('Please select the Stock Consumption Ledger!');
											};
										} 
										else 
										{
											alert('Please select the cash/bank ledger paying or the name of the person who did the servicing, if its on credit!');
										};
									} 
									else 
									{
										alert('Please type the phone number of the person who serviced the item!');
									};
								} 
								else 
								{
									alert('Please select the date of servicing!');
								};
							} 
							else 
							{
								alert('Please type the address of the person who did the servicing!');
							};
						} 
						else 
						{
							alert('Please type the name of the person/institution who did the servicing!');
						};
					} 
					else 
					{
						alert('Please select the provide the service component and their amount!');
					};
				} 
				else 
				{
					alert('Please select the Expenditure ledger!');
				};
			});
		}
		
		function search_mtce_invoice_by_name()
		{
			$(document).on('keyup','#mtce_name',function(e){
				e.preventDefault();
				var company_id = $('#session_company_id').val();
				var name = $('#mtce_name').val();

				$.ajax({
					url:'/layout/vouchers/mtce_search_by_name.php',
					method:'POST',
					data:{name:name,company_id:company_id},
					success:function(data)
					{
						$('#mtce_list_table').html(data);
					}
		        });
			});
		}

		function search_mtce_invoice_by_date()
		{
			$(document).on('click','#mtce_search_icon',function(e){
				e.preventDefault();
				var company_id = $('#session_company_id').val();
				var start_date = $('#mtce_search_from').val();
				var end_date = $('#mtce_search_to').val();

				$.ajax({
		             url:'/layout/vouchers/mtce_search_by_date.php',
		             method:'POST',
		             data:{start_date:start_date,end_date:end_date,company_id:company_id},
		             success:function(data)
			             {
			             	$('#mtce_list_table').html(data);
			             }
		        });
			});
		}

		function delete_mtce_invoice()
		{
			$(document).on('click','#btn_delete_mtce_sheet',function(){
				var mtce_sheet_id = $(this).attr('data-id');
				var currentRow = $(this).closest("tr");
				var mtce_date = currentRow.find("td:eq(0)").text();
				var hired_by = currentRow.find("td:eq(2)").text();
				$('#mtce_invoice_delete_question').text('Are you sure you want to delete Maintenance Sheet of ' + mtce_date + ' for ' + hired_by + '?');
				$('#mtce_invoice_delete_modal').modal('show');
				$(document).on('click','#mtce_delete_yes',function(){
					$.ajax({  
						url:'/layout/vouchers/mtce_delete.php',  
						type:'POST',  
						data:{mtce_sheet_id:mtce_sheet_id},
						success:function(){
							$('#mtce_invoice_delete_modal').modal('hide');
							window.location.href="/layout/vouchers/mtce_list.php";
						}
		            });
			      });
				$(document).on('click','#mtce_delete_no',function(){
					$('#mtce_invoice_delete_modal').modal('hide');
				});
			});
		}

	//SALES
		function new_sales_modal()
		{
			$(document).on('click','#new_sales_icon',function()
			{
				var table_id = 1;
				$.ajax({
					url:'/layout/vouchers/sales_pending_list.php',
					method:'POST',
					data:{table_id:table_id},
					success:function(data)
					{
						$('#sales_update_btn').hide();
						$('#sales_save_btn').show();
						$('#sales_create_form').trigger('reset');
						$('#sales_product').val(1);
						$('#sales_credit').val(4);
						$('#sales_creditD').val(4);
						$('#sales_item_list_table').html(data);
						$('#sales_create_modal').modal('show');
					}
				});
			});
		}

		function cancel_sales_modal()
		{
			$(document).on('click','#sales_cancel_btn',function()
			{
				var page = window.location.pathname;
				$('#sales_create_form').trigger('reset');
				$('#sales_create_modal').modal('hide');
				window.location.href= page;
				//window.location.href="/layout/vouchers/sales_list.php";
			});
		}

		function add_sales_item()
		{  
			$(document).on('click','#btn_sales_item_enter',function(){ 
				var purchase_id = $(this).attr('data-id');
				var currentRow = $(this).closest("tr");
				var list_id = currentRow.attr('id');
				var date = currentRow.find("td:eq(0)").text();
				var purchase_id = currentRow.find("td:eq(1)").text();
				var supplier = currentRow.find("td:eq(2)").text();
				var item_grams = currentRow.find("td:eq(3)").text();
				var item_water = currentRow.find("td:eq(4)").text();
				var item_karat = currentRow.find("td:eq(5)").text();
				var item_amount = currentRow.find("td:eq(6)").text();
				grams = parseFloat(item_grams);
				water = parseFloat(item_water);
				amount = parseFloat(item_amount);
				var grams_current = $('#sales_gram').val();
				var water_current = $('#sales_water').val();
				if(grams_current == ''){var grams_previous = 0 }else{var grams_previous = parseFloat($('#sales_gram').val())};
					var grams_total = grams_previous + grams;
				if(water_current == ''){var water_previous = 0 }else{var water_previous = parseFloat($('#sales_water').val())};
					var water_total = water_previous + water;

				var grams_currentD = $('#sales_gramD').val();
				var water_currentD = $('#sales_waterD').val();
				if(grams_currentD == ''){var grams_previousD = 0 }else{var grams_previousD = parseFloat($('#sales_gramD').val())};
					var grams_totalD = grams_previousD + grams;
				if(water_currentD == ''){var water_previousD = 0 }else{var water_previousD = parseFloat($('#sales_waterD').val())};
					var water_totalD = water_previousD + water;

				var purchase_amountD_current = $('#purchase_amountD').val();
				if(purchase_amountD_current == ''){var purchase_amountD_previous = 0 }else{var purchase_amountD_previous = parseFloat($('#purchase_amountD').val())};
					var purchase_amountD_total = purchase_amountD_previous + amount;

				var i = $('#sold_item_list_table tr:last').attr('data-id');
				i++; 
				$('#sold_item_list_table_body').append('<tr id="row_as'+i+'" data-id="'+ i +'"><td><a href="#"id="btn_delete_sales_item" data-id="'+i+'" data-id2="'+list_id+'">'+date+'</a></td><td class="action-td"><a href="#"id="btn_delete_sales_item" data-id="'+i+'" data-id2="'+list_id+'">'+purchase_id+'</a></td><td><a href="#"id="btn_delete_sales_item" data-id="'+i+'" data-id2="'+list_id+'">'+supplier+'</a></td><td class="amt-td"><a href="#"id="btn_delete_sales_item" data-id="'+i+'" data-id2="'+list_id+'">'+grams+'</a></td><td class="amt-td"><a href="#"id="btn_delete_sales_item" data-id="'+i+'" data-id2="'+list_id+'">'+water+'</a></td><td class="amt-td"><a href="#"id="btn_delete_sales_item" data-id="'+i+'" data-id2="'+list_id+'">'+item_karat+'</a></td><td class="amt-td"><a href="#"id="btn_delete_sales_item" data-id="'+i+'" data-id2="'+list_id+'">'+amount+'</a></td><input type="hidden" name="date[]" id="date" value="'+date+'"><input type="hidden" name="supplier[]" id="supplier" value="'+supplier+'"><input type="hidden" name="grams[]" id="grams" value="'+grams+'"><input type="hidden" name="water[]" id="water" value="'+water+'"><input type="hidden" name="karat[]" id="karat" value="'+item_karat+'"><input type="hidden" name="amount[]" id="amount" value="'+amount+'"><input type="hidden" name="purchase_id[]" id="purchase_id" value="'+purchase_id+'"><input type="hidden" name="list_id[]" id="list_id" value="'+list_id+'"></tr>');
				currentRow.hide();
				$('#sales_gram').val(grams_total.toFixed(2));
				$('#sales_water').val(water_total.toFixed(2));
				$('#sales_gramD').val(grams_totalD.toFixed(2));
				$('#sales_waterD').val(water_totalD.toFixed(2));
				$('#purchase_gramD').val(grams_totalD.toFixed(2));
				$('#purchase_waterD').val(water_totalD.toFixed(2));
				$('#purchase_amountD').val(purchase_amountD_total.toFixed(2));
				//CALCULATIONS
					/*POUNDS*/
							var sales_gram = $('#sales_gram').val();
							if (sales_gram > 0) 
							{
						    	var pounds = Math.trunc(($('#sales_gram').val() / 7.75)*100)/100;
						        $('#sales_pounds').val(pounds);
						        $('#sales_poundsD').val(pounds);
					    	};
					/*DENSITY*/
							var sales_gram = $('#sales_gram').val();
							var sales_water = $('#sales_water').val();
							if (sales_gram > 0 && sales_water > 0) 
							{
					        	var density = Math.trunc((sales_gram / sales_water)*100)/100;
					        	$('#sales_density').val(density);
					        	$('#sales_densityD').val(density);
							};	
					/*CARAT*/
							var sales_gram = $('#sales_gram').val();
							var sales_water = $('#sales_water').val();
							if (sales_gram > 0 && sales_water > 0) 
							{
						    	var density = Math.trunc(($('#sales_gram').val() / $('#sales_water').val())*100)/100;
								var carat = Math.trunc((((density - 10.51) * 52.838)/density)*100)/100;
						        $('#sales_karat').val(carat);
						        $('#sales_karatD').val(carat);
					    	};
					/*PURITY*/
							var sales_gram = $('#sales_gram').val();
							var sales_water = $('#sales_water').val();
							if (sales_gram > 0 && sales_water > 0) 
							{
					    		var density = Math.trunc(($('#sales_gram').val() / $('#sales_water').val())*100)/100;
								var carat = Math.trunc((((density - 10.51) * 52.838)/density)*100)/100;
								var purity =Math.trunc(((carat/24)*100)*100)/100;
					        	$('#sales_purity').val(purity);
					        	$('#sales_purityD').val(purity);
				        	};
					/*PRICE_PER_POUND*/
							var sales_karat = $('#sales_karat').val();
							var sales_price = $('#sales_price').val();
							if (sales_karat > 0 && sales_price > 0) 
							{
								var sales_price_per_pound = (sales_karat * sales_price)/23;
								var amount = parseFloat(sales_price_per_pound).toFixed(2);
								var ppp = addCommas(amount);
						        $('#sales_ppp').val(amount);
						        $('#sales_pppD').val(ppp);
					    	};
					/*AMOUNT*/
						var sales_gram = $('#sales_gram').val();
						var sales_water = $('#sales_water').val();
						var sales_price = $('#sales_price').val();
						if (sales_gram > 0 && sales_water > 0 && sales_price > 0) 
						{
				    		var pounds = Math.trunc(($('#sales_gram').val() / 7.75)*100)/100;
							var density = Math.trunc(($('#sales_gram').val() / $('#sales_water').val())*100)/100;
							var carat = Math.trunc((((density - 10.51) * 52.838)/density)*100)/100;
							var amount1 = Math.trunc(((carat * $('#sales_price').val())/23)*pounds);
							var amount = addCommas(amount1);
			    			$('#sales_amount').val(amount1);
			    			$('#sales_amountD').val(amount);
			    		};
			});
		}

		function delete_sales_item()
		{
			$(document).on('click', '#btn_delete_sales_item', function(){  
       			var button_id = $(this).attr("data-id");  
       			var list_id = $(this).attr("data-id2"); 
       			var currentRow=$(this).closest("tr");
				var item_date = currentRow.find("td:eq(0)").text();
				var item_purchase_id = currentRow.find("td:eq(1)").text();
				var item_supplier = currentRow.find("td:eq(2)").text();
				var item_grams = currentRow.find("td:eq(3)").text();
				var item_water = currentRow.find("td:eq(4)").text();
				var item_karat = currentRow.find("td:eq(5)").text();
				var item_amount = currentRow.find("td:eq(6)").text();
       			
				grams = parseFloat(item_grams);
				water = parseFloat(item_water);
				amount = parseFloat(item_amount);
				var grams_current = $('#sales_gram').val();
				var water_current = $('#sales_water').val();
				if(grams_current == ''){var grams_previous = 0 }else{var grams_previous = parseFloat($('#sales_gram').val())};
				var grams_total = grams_previous - grams;

				if(water_current == ''){var water_previous = 0 }else{var water_previous = parseFloat($('#sales_water').val())};
				var water_total = water_previous - water;

				var grams_currentD = $('#sales_gramD').val();
				var water_currentD = $('#sales_waterD').val();
				if(grams_currentD == ''){var grams_previousD = 0 }else{var grams_previousD = parseFloat($('#sales_gramD').val())};
				var grams_totalD = grams_previousD - grams;

				if(water_currentD == ''){var water_previousD = 0 }else{var water_previousD = parseFloat($('#sales_waterD').val())};
				var water_totalD = water_previousD - water;
				
				var purchase_amountD_current = $('#purchase_amountD').val();
				if(purchase_amountD_current == ''){var purchase_amountD_previous = 0 }else{var purchase_amountD_previous = parseFloat($('#purchase_amountD').val())};
				var purchase_amountD_total = purchase_amountD_previous - amount;

				$('#sales_gram').val(grams_total.toFixed(2));
				$('#sales_water').val(water_total.toFixed(2));
				$('#sales_gramD').val(grams_totalD.toFixed(2));
				$('#sales_waterD').val(water_totalD.toFixed(2));
				$('#purchase_gramD').val(grams_totalD.toFixed(2));
				$('#purchase_waterD').val(water_totalD.toFixed(2));
				$('#purchase_amountD').val(purchase_amountD_total.toFixed(2));
           		$('#row_as'+button_id+'').remove();

				var i = $('#pending_item_list_table tr:last').attr('data-id');
				i++;

       			$('#pending_item_list_table_body').append('<tr id="sales_item_list'+ i +'" data-id="'+ i +'"><td><a href="#" id="btn_sales_item_enter" data-id="'+ item_purchase_id +'">'+ item_date +'</a></td><td class="action-td"><a href="#" id="btn_sales_item_enter" data-id="'+ item_purchase_id +'">'+ item_purchase_id +'</a></td><td><a href="#" id="btn_sales_item_enter" data-id="'+ item_purchase_id +'">'+ item_supplier +'</a></td><td class="amt-td"><a href="#" id="btn_sales_item_enter" data-id="'+ item_purchase_id +'">'+ item_grams +'</a></td><td class="amt-td"><a href="#" id="btn_sales_item_enter" data-id="'+ item_purchase_id +'">'+ item_water +'</a></td><td class="amt-td"><a href="#" id="btn_sales_item_enter" data-id="'+ item_purchase_id +'">'+ item_karat +'</a></td><td class="amt-td"><a href="#" id="btn_sales_item_enter" data-id="'+ item_purchase_id +'">'+ amount +'</a></td></tr>');
       				
           		//CALCULATIONS
	           		/*POUNDS*/
							var sales_gram = $('#sales_gram').val();
							if (sales_gram > 0) 
							{
						    	var pounds = Math.trunc(($('#sales_gram').val() / 7.75)*100)/100;
						        $('#sales_pounds').val(pounds);
						        $('#sales_poundsD').val(pounds);
					    	}
					    	else
					    	{
					    		$('#sales_pounds').val('');
						        $('#sales_poundsD').val('');
					    	};
					/*DENSITY*/
							var sales_gram = $('#sales_gram').val();
							var sales_water = $('#sales_water').val();
							if (sales_gram > 0 && sales_water > 0) 
							{
					        	var density = Math.trunc((sales_gram / sales_water)*100)/100;
					        	$('#sales_density').val(density);
					        	$('#sales_densityD').val(density);
							}
					    	else
					    	{
					    		$('#sales_density').val('');
						        $('#sales_densityD').val('');
					    	};	
					/*CARAT*/
							var sales_gram = $('#sales_gram').val();
							var sales_water = $('#sales_water').val();
							if (sales_gram > 0 && sales_water > 0) 
							{
						    	var density = Math.trunc(($('#sales_gram').val() / $('#sales_water').val())*100)/100;
								var carat = Math.trunc((((density - 10.51) * 52.838)/density)*100)/100;
						        $('#sales_karat').val(carat);
						        $('#sales_karatD').val(carat);
					    	}
					    	else
					    	{
					    		$('#sales_karat').val('');
						        $('#sales_karatD').val('');
					    	};
					/*PURITY*/
							var sales_gram = $('#sales_gram').val();
							var sales_water = $('#sales_water').val();
							if (sales_gram > 0 && sales_water > 0) 
							{
					    		var density = Math.trunc(($('#sales_gram').val() / $('#sales_water').val())*100)/100;
								var carat = Math.trunc((((density - 10.51) * 52.838)/density)*100)/100;
								var purity =Math.trunc(((carat/24)*100)*100)/100;
					        	$('#sales_purity').val(purity);
					        	$('#sales_purityD').val(purity);
				        	}
					    	else
					    	{
					    		$('#sales_purity').val('');
						        $('#sales_purityD').val('');
					    	};
					/*PRICE_PER_POUND*/
							var sales_karat = $('#sales_karat').val();
							var sales_price = $('#sales_price').val();
							if (sales_karat > 0 && sales_price > 0) 
							{
								var sales_price_per_pound = (sales_karat * sales_price)/23;
								var amount = parseFloat(sales_price_per_pound).toFixed(2);
								var ppp = addCommas(amount);
						        $('#sales_ppp').val(amount);
						        $('#sales_pppD').val(ppp);
					    	}
					    	else
					    	{
					    		$('#sales_ppp').val('');
						        $('#sales_pppD').val('');
					    	};
					/*AMOUNT*/
							var sales_gram = $('#sales_gram').val();
							var sales_water = $('#sales_water').val();
							var sales_price = $('#sales_price').val();
							if (sales_gram > 0 && sales_water > 0 && sales_price > 0) 
							{
					    		var pounds = Math.trunc(($('#sales_gram').val() / 7.75)*100)/100;
								var density = Math.trunc(($('#sales_gram').val() / $('#sales_water').val())*100)/100;
								var carat = Math.trunc((((density - 10.51) * 52.838)/density)*100)/100;
								var amount1 = Math.trunc(((carat * $('#sales_price').val())/23)*pounds);
								var amount = addCommas(amount1);
				    			$('#sales_amount').val(amount1);
				    			$('#sales_amountD').val(amount);
				    		}
					    	else
					    	{
					    		$('#sales_amount').val('');
						        $('#sales_amountD').val('');
					    	};
           	});
		}
		//CALCULATIONS
			/*POUNDS*/
				function sales_set_pounds()
				{
					$(document).on('keyup','#sales_gram,#sales_water',function(){
						var sales_gram = $('#sales_gram').val();
						var sales_product = $('#sales_product').val();
						if (sales_gram > 0) 
						{
							if(sales_product == 1)
							{
								//var pounds = parseFloat($('#sales_gram').val() / 7.75).toFixed(2);
								var pounds = Math.trunc(($('#sales_gram').val() / 7.75)*100)/100;
							}
							else if(sales_product == 2)
							{
								var pounds = Math.trunc(($('#sales_gram').val() / 0.8)*100)/100;
							};
					        $('#sales_pounds').val(pounds);
					        $('#sales_poundsD').val(pounds);
				    	};
					});
				}
			
			/*DENSITY*/
				function sales_set_density()
				{
					$(document).on('keyup','#sales_gram, #sales_water',function(){
						var sales_gram = $('#sales_gram').val();
						var sales_water = $('#sales_water').val();
						if (sales_gram > 0 && sales_water > 0) 
						{
				        	var density = Math.trunc((sales_gram / sales_water)*100)/100;
				        	$('#sales_density').val(density);
				        	$('#sales_densityD').val(density);
						};
					});
				}
			
			/*CARAT*/
				function sales_set_carat()
				{
					$(document).on('keyup','#sales_gram, #sales_water',function(){
						var sales_gram = $('#sales_gram').val();
						var sales_water = $('#sales_water').val();
						if (sales_gram > 0 && sales_water > 0) 
						{
					    	var density = Math.trunc(($('#sales_gram').val() / $('#sales_water').val())*100)/100;
							var carat = Math.trunc((((density - 10.51) * 52.838)/density)*100)/100;
					        $('#sales_karat').val(carat);
					        $('#sales_karatD').val(carat);
				    	};
					});
				}
			
			/*PURITY*/
				function sales_set_purity()
				{
					$(document).on('keyup','#sales_gram, #sales_water',function(){
						var sales_gram = $('#sales_gram').val();
						var sales_water = $('#sales_water').val();
						if (sales_gram > 0 && sales_water > 0) 
						{
				    		var density = Math.trunc(($('#sales_gram').val() / $('#sales_water').val())*100)/100;
							var carat = Math.trunc((((density - 10.51) * 52.838)/density)*100)/100;
							var purity =Math.trunc(((carat/24)*100)*100)/100;
				        	$('#sales_purity').val(purity);
				        	$('#sales_purityD').val(purity);
			        	};
					});
				}

			/*PRICE_PER_POUND*/
				function sales_price_per_pound()
				{
					$(document).on('keyup','#sales_price',function(){
						var sales_karat = $('#sales_karat').val();
						var sales_price = $('#sales_price').val();
						if (sales_karat > 0 && sales_price > 0) 
						{
							var sales_price_per_pound = (sales_karat * sales_price)/23;
							var amount = parseFloat(sales_price_per_pound).toFixed(2);
							var ppp = addCommas(amount);
					        $('#sales_ppp').val(amount);
					        $('#sales_pppD').val(ppp);
				    	};
					});
				}
			
			/*AMOUNT*/
				function sales_set_amount()
				{
					$(document).on('keyup','#sales_gram, #sales_water, #sales_price',function(){
						var sales_gram = $('#sales_gram').val();
						var sales_water = $('#sales_water').val();
						var sales_price = $('#sales_price').val();
						var sales_product = $('#sales_product').val();
						var purchase_amountD = $('#purchase_amountD').val();
						if (sales_gram > 0 && sales_price > 0) 
						{
							var density = Math.trunc(($('#sales_gram').val() / $('#sales_water').val())*100)/100;
							var carat = Math.trunc((((density - 10.51) * 52.838)/density)*100)/100;
							if(sales_product == 1)
							{
								//var pounds = parseFloat($('#sales_gram').val() / 7.75).toFixed(2);
								var pounds = Math.trunc(($('#sales_gram').val() / 7.75)*100)/100;
								var amount1 = Math.trunc(((carat * $('#sales_price').val())/23)*pounds);
							}
							else if(sales_product == 2)
							{
								var pounds = Math.trunc(($('#sales_gram').val()/ 0.80)*100)/100;
								var amount1 = Math.trunc($('#sales_price').val()*pounds);
							};
							if(sales_price !='' && sales_price > 0)
							{
								var profit1 = amount1 - purchase_amountD;
							}
							else
							{
								var profit1 = 0;
							};
							var amount = addCommas(amount1);
							var profit = addCommas(profit1);
			    			$('#sales_amount').val(amount1);
			    			$('#sales_amountD').val(amount);
			    			$('#profitabilityD').val(profit);
			    		};
					});
				}

		function save_sales()
		{
			$(document).on('click','#sales_save_btn',function(e){
				e.preventDefault();
				var sales_debit = $('#sales_debit').val();
				var sales_credit = $('#sales_credit').val();
				var sales_product = $('#sales_product').val();
				var sales_gram = $('#sales_gram').val();
				var sales_water = $('#sales_water').val();
				var sales_date = $('#sales_date').val();
				var sales_price = $('#sales_price').val();
				var sales_supplied_by = $('#sales_supplied_by').val();
				var page = window.location.pathname;
				if (sales_debit !=="") 
				{
					if (sales_credit !=="") 
					{
						if (sales_product !=="") 
						{
							if (sales_gram !=="") 
							{
								if (sales_water !=="") 
								{
									if (sales_date !=="") 
									{
										if (sales_price !=="") 
										{
											if (sales_supplied_by !=="") 
											{
												$.ajax({
										             url:'/layout/vouchers/sales_save.php',
										             method:'POST',
										             data:$('#sales_create_form').serialize(),
										             success:function(data)
										             {
		             									$('#sales_create_form').trigger('reset');
														$('#sales_create_modal').modal('hide');
														window.open('/layout/vouchers/sales_pdf.php', '_blank');
										             	window.location.href= page;
										             	//window.location.href="/layout/vouchers/sales_list.php";
			             								//window.open('/layout/vouchers/sales_display.php', '_blank');
										             }
										        });

											} 
											else 
											{
												alert('Please type the Name of the person buying the goods!');
											}
										} 
										else 
										{
											alert('Please type the PRICE for item!');
										}
									} 
									else 
									{
										alert('Please select the date of sale!');
									}
								} 
								else 
								{
									alert('Please type the WATER weight!');
								}
							} 
							else 
							{
								alert('Please type the TOP weight (GRAMS)!');
							}
						} 
						else 
						{
							alert('Please select the TYPE of Product sold!');
						}
					} 
					else 
					{
						alert('Please select the ledger from which the sales was made (Sales Account)!');
					}
				} 
				else 
				{
					alert('Please select the ledger into which the sale was made (Creditor/Supplier Account)!');
				};
			});
		}

		function edit_sales_invoice()
		{
			$(document).on('click','#btn_edit_sales',function(){
				var sales_id = $(this).attr('data-id');
				$.ajax({
					url:'/layout/vouchers/sales_edit.php',
					method:'POST',
					data:{sales_id:sales_id},
					datatype:'JSON',
					success:function(data)
					{
						var res = $.parseJSON(data);
						$('#sales_id').val(res[1]);
						$('#sales_company_id').val(res[3]);
						$('#sales_user_super_id').val(res[0]);
						$('#sales_user_id').val(res[4]);
						$('#sales_debit').val(res[6]);
						$('#sales_credit').val(res[5]);
						$('#sales_creditD').val(res[5]);
						$('#sales_date').val(res[8]);
						$('#sales_supplied_by').val(res[7]);
						$('#sales_phone_no').val(res[21]);
						$('#sales_location').val(res[22]);
						$('#sales_product').val(res[10]);
						$('#sales_gram').val(res[11]);
						$('#sales_water').val(res[12]);
						$('#sales_price').val(res[17]);
						$('#sales_amount').val(res[18]);
						$('#sales_amountD').val(res[18]);
						$('#sales_pounds').val(res[14]);
						$('#sales_poundsD').val(res[14]);
						$('#sales_density').val(res[13]);
						$('#sales_densityD').val(res[13]);
						$('#sales_karat').val(res[15]);
						$('#sales_karatD').val(res[15]);
						$('#sales_purity').val(res[16]);
						$('#sales_purityD').val(res[16]);
						$('#sales_ppp').val(res[23]);
						$('#sales_pppD').val(res[23]);
						$('#sales_pieces').val(res[20]);
						$('#sales_narration').val(res[19]);
						$('#sales_gramD').val(res[24]);
						$('#sales_waterD').val(res[25]);
						$('#sales_branch_id').val(res[26]);
						$('#purchase_gramD').val(res[24]);
						$('#purchase_waterD').val(res[25]);
						$('#purchase_amountD').val(res[27]);
						$('#profitabilityD').val(res[28]);
						$('#sales_item_list_table').html(res[29]);
						$.ajax({
							url:'/layout/vouchers/sales_sold_items_edit.php',
							method:'POST',
							data:{sales_id:sales_id},
							success:function(data)
							{
								$('#sold_item_list_div').html(data);
							}
							});
						$('#sales_update_btn').show();
						$('#sales_save_btn').hide();
						$('#sales_create_modal').modal('show');
					}
		        });
			});
		}

		function update_sales_invoice()
		{
			$(document).on('click','#sales_update_btn',function(e){
				e.preventDefault();
				var sales_debit = $('#sales_debit').val();
				var sales_credit = $('#sales_credit').val();
				var sales_product = $('#sales_product').val();
				var sales_gram = $('#sales_gram').val();
				var sales_water = $('#sales_water').val();
				var sales_date = $('#sales_date').val();
				var sales_price = $('#sales_price').val();
				var sales_supplied_by = $('#sales_supplied_by').val();
				var page = window.location.pathname;
				if (sales_debit !=="") 
				{
					if (sales_credit !=="") 
					{
						if (sales_product !=="") 
						{
							if (sales_gram !=="") 
							{
								if (sales_water !=="") 
								{
									if (sales_date !=="") 
									{
										if (sales_price !=="") 
										{
											if (sales_supplied_by !=="") 
											{
												$.ajax({
										             url:'/layout/vouchers/sales_update.php',
										             method:'POST',
										             data:$('#sales_create_form').serialize(),
										             success:function(data)
											             {
			             									$('#sales_create_form').trigger('reset');
															$('#sales_create_modal').modal('hide');
															window.open('/layout/vouchers/sales_pdf.php', '_blank');
											             	window.location.href= page;
											             	//window.location.href="/layout/vouchers/sales_list.php";
				             								//window.open('/layout/vouchers/sales_display.php', '_blank');
											             }
										        });

											} 
											else 
											{
												alert('Please type the Name of the person buying the goods!');
											}
										} 
										else 
										{
											alert('Please type the PRICE for item!');
										}
									} 
									else 
									{
										alert('Please select the date of sale!');
									}
								} 
								else 
								{
									alert('Please type the WATER weight!');
								}
							} 
							else 
							{
								alert('Please type the TOP weight (GRAMS)!');
							}
						} 
						else 
						{
							alert('Please select the TYPE of Product sold!');
						}
					} 
					else 
					{
						alert('Please select the ledger from which the sales was made (Sales Account)!');
					}
				} 
				else 
				{
					alert('Please select the ledger into which the sale was made (Creditor/Supplier Account)!');
				};
			});
		}

		function search_sales_by_name()
		{
			$(document).on('keyup','#sales_search_name',function(e){
				e.preventDefault();
				var company_id = $('#session_company_id').val();
				var sales_search_name = $('#sales_search_name').val();

				$.ajax({
		             url:'/layout/vouchers/sales_search_by_name.php',
		             method:'POST',
		             data:{sales_search_name:sales_search_name,company_id:company_id},
		             success:function(data)
			             {
			             	$('#sales_list_card_body').html(data);
			             }
		        });
			});
		}

		function search_sales_by_date()
		{
			$(document).on('click','#sales_search_icon',function(e){
				e.preventDefault();
				var company_id = $('#session_company_id').val();
				var start_date = $('#sales_search_from').val();
				var end_date = $('#sales_search_to').val();

				$.ajax({
		             url:'/layout/vouchers/sales_search_by_date.php',
		             method:'POST',
		             data:{start_date:start_date,end_date:end_date,company_id:company_id},
		             success:function(data)
		             {
		             	$('#sales_list_card_body').html(data);
		             }
		        });
			});
		}

		function reprint_sales()
		{
			$(document).on('click','#btn_single_sales_reprint',function()
			{
				var sales_id = $(this).attr('data-id');
				$.ajax({
					url:'/layout/vouchers/sales_reprint.php',
					method:'POST',
					data:{
						sales_id:sales_id
					},
					success:function(data)
					{
						window.open('/layout/vouchers/sales_pdf.php', '_blank');
					}
		        });
			});
		}

		function delete_sales()
		{
			$(document).on('click','#btn_delete_sales',function(){
				var sales_id = $(this).attr('data-id');
				var currentRow=$(this).closest("tr");
				var sales_date = currentRow.find("td:eq(1)").text();
				var Supplier = currentRow.find("td:eq(3)").text();
				$('#sales_invoice_delete_question').text('Are you sure you want to delete sales invoice of ' + sales_date + ' for ' + Supplier + '?');
				$('#sales_invoice_delete_modal').modal('show');
				$(document).on('click','#sales_delete_yes',function(){
					$.ajax({  
		                 url:'/layout/vouchers/sales_delete.php',  
		                 type:'POST',  
		                 data:{sales_id:sales_id},
		                 success:function(){
		                 	$('#sales_invoice_delete_modal').modal('hide');
		                 	window.location.href="/layout/vouchers/sales_list.php";
		                 }  
		            });
			      });
				$(document).on('click','#sales_delete_no',function(){
					$('#sales_invoice_delete_modal').modal('hide');
				});
			});
		}

	//BULK_SALES
		function new_bulk_sales_modal()
		{
			$(document).on('click','#new_bulk_sales_icon',function()
			{
				$('#bulk_sales_update_btn').hide();
				$('#bulk_sales_save_btn').show();
				$('#bulk_sales_create_form').trigger('reset');
				$('#bulk_sales_product').val(1);
				$('#bulk_sales_credit').val(4);
				$('#bulk_sales_creditD').val(4);
				$('#bulk_sales_create_modal').modal('show');
			});
		}

		function bulk_sales_add_ledger()
		{
			$(document).on('click','#new_bulk_sales_payment_ledger',function(){
				var i = $('#bulk_sales_payment_list_table tr:last').attr('id');
				$.ajax({
					url:'/layout/vouchers/bulk_sales_add_ledger.php',
					method:'POST',
					data:{i:i},
					success:function(data)
					{
						$('#bulk_sales_payment_list_table').append(data);
					}
				});
			});
		}

		function bulk_sales_delete_ledger()
		{
			$(document).on('click', '.btn_delete_bulk_sales_payment_ledger', function()
			{  
				var tr_id = $(this).closest("tr").attr("id");
				$('#'+tr_id+'').remove();
				var sum = 0;
				$(".bulk_sales_payment_amount").each(function()
				{
					sum += +$(this).val();
				});
				$("#bulk_sales_payment_amount_total").val(sum);
			});
		}

		function bulk_sales_ledger_group_id()
		{
			$(document).on('change','.bulk_sales_payment_ledger_id',function(){
				var tr_id = $(this).closest('tr').attr('id');
				var ledger_id = $(this).val();
				$.ajax({
					url:'/layout/vouchers/bulk_sales_ledger_group_id.php',
					method:'POST',
					data:{ledger_id:ledger_id},
					success:function(data)
					{
						$('#bulk_sales_payment_ledger_group_id'+tr_id).val(data);
					}
				});
			});
		}

		function bulk_sales_sum_payment_amount()
		{
			$(document).on('keyup', '.bulk_sales_payment_amount', function()
			{  
				var button_id = $(this).closest('tr').attr('id');
				var ledger_id = $('#bulk_sales_payment_ledger_id'+button_id).val();
				
				if(ledger_id !='' && ledger_id > 0)
				{
					var sum = 0;
					$(".bulk_sales_payment_amount").each(function(){
						sum += +$(this).val();
					});
					$("#bulk_sales_payment_amount_total").val(sum);
				}
				else
				{
					$(this).val(0);
					alert('Please select the ledger first!');
				};
			});
		}
		
		function bulk_sales_set_item_sales_amount()
		{
			$(document).on('keyup','.bulk_sales_selling_price',function(){
				var currentRow = $(this).closest("tr");
				var tr_id = currentRow.attr("data-id");
				var karat = $.trim(currentRow.find("td:eq(4)").text());
				var pounds = $.trim(currentRow.find("td:eq(5)").text());
				var selling_price = $(this).val();
				var amount = Math.trunc(((karat * selling_price)/23)*pounds);
				
				var amount1 = addCommas(amount);
				$('#bulk_sales_sold_amount'+tr_id).val(amount);
				$('#bulk_sales_sold_amountD'+tr_id).val(amount1);
				
				var weight = 0;
				var water = 0;
				var total_amount = 0;
				$(".bulk_sales_selling_price").each(function()
				{
					var tr_id = $(this).closest('tr').attr('data-id');
					var price = $('#bulk_sales_selling_price'+tr_id).val();
					if(price > 0)
					{
						weight += +$('#bulk_sales_weight'+tr_id).val();
						water += +$('#bulk_sales_water'+tr_id).val();
						total_amount += +$('#bulk_sales_sold_amount'+tr_id).val();
					};
				});
				$("#bulk_sales_total_weight").val(weight);
				$("#bulk_sales_total_water").val(water);
				$("#bulk_sales_total_amount").val(total_amount);
			});
		}

		function cancel_bulk_sales_modal()
		{
			$(document).on('click','#bulk_sales_cancel_btn',function()
			{
				var page = window.location.pathname;
				$('#bulk_sales_create_form').trigger('reset');
				$('#bulk_sales_create_modal').modal('hide');
				window.location.href= page;
				//window.location.href="/layout/vouchers/sales_list.php";
			});
		}

		function save_bulk_sales()
		{
			$(document).on('click','#bulk_sales_save_btn',function(e){
				e.preventDefault();
				var bulk_sales_debit = $('#bulk_sales_debit').val();
				var bulk_sales_credit = $('#bulk_sales_credit').val();
				var bulk_sales_total_weight = $('#bulk_sales_total_weight').val();
				var bulk_sales_date = $('#bulk_sales_date').val();
				var bulk_sales_total_water = $('#bulk_sales_total_water').val();
				var bulk_sales_total_amount = $('#bulk_sales_total_amount').val();
				var page = window.location.pathname;
				if (bulk_sales_debit !="") 
				{
					if (bulk_sales_credit !="") 
					{
						if (bulk_sales_total_weight !="") 
							{
								if (bulk_sales_total_water !="") 
								{
									if (bulk_sales_date !="") 
									{
										if (bulk_sales_total_amount !="") 
										{
											$.ajax({
												url:'/layout/vouchers/bulk_sales_save.php',
												method:'POST',
												data:$('#bulk_sales_create_form').serialize(),
												success:function(data)
												{
												$('#bulk_sales_create_form').trigger('reset');
												$('#bulk_sales_create_modal').modal('hide');
												window.open('/layout/vouchers/bulk_sales_pdf.php', '_blank');
												window.location.href= page;
												}
											});
										} 
										else 
										{
											alert('Please type the PRICE for item!');
										};
									} 
									else 
									{
										alert('Please select the date of sale!');
									};
								} 
								else 
								{
									alert('Please type the WATER weight!');
								};
							} 
							else 
							{
								alert('Please type the TOP weight (GRAMS)!');
							};
					} 
					else 
					{
						alert('Please select the ledger from which the sales was made (Sales Account)!');
					};
				} 
				else 
				{
					alert('Please select the ledger into which the sale was made (Creditor/Supplier Account)!');
				};
			});
		}

		function edit_bulk_sales_invoice()
		{
			$(document).on('click','#btn_edit_bulk_sales',function(){
				var bulk_sales_id = $(this).attr('data-id');
				$.ajax({
					url:'/layout/vouchers/bulk_sales_edit.php',
					method:'POST',
					data:{bulk_sales_id:bulk_sales_id},
					datatype:'JSON',
					success:function(data)
					{
						var res = $.parseJSON(data);
						$('#bulk_sales_payment_list_div').html(res[0]);
						$('#bulk_sales_item_list_table').html(res[1]);
						$('#bulk_sales_total_weight').val(res[3]);
						$('#bulk_sales_total_water').val(res[4]);
						$('#bulk_sales_total_pounds').val(res[5]);
						$('#bulk_sales_total_amount').val(res[6]);
						$('#bulk_sales_id').val(res[2][0]);
						$('#bulk_sales_debit').val(res[2][2]);
						$('#bulk_sales_credit').val(res[2][1]);
						$('#bulk_sales_creditD').val(res[2][1]);
						$('#bulk_sales_date').val(res[2][4]);
						$('#bulk_sales_supplied_by').val(res[2][3]);
						$('#bulk_sales_narration').val(res[2][5]);
						$('#bulk_sales_phone_no').val(res[2][6]);
						$('#bulk_sales_location').val(res[2][7]);
						$('#bulk_sales_update_btn').show();
						$('#bulk_sales_save_btn').hide();
						$('#bulk_sales_create_modal').modal('show');
						
					}
				});
			});
		}

		function update_bulk_sales_invoice()
		{
			$(document).on('click','#bulk_sales_update_btn',function(e){
				e.preventDefault();
				var bulk_sales_debit = $('#bulk_sales_debit').val();
				var bulk_sales_credit = $('#bulk_sales_credit').val();
				var bulk_sales_total_weight = $('#bulk_sales_total_weight').val();
				var bulk_sales_date = $('#bulk_sales_date').val();
				var bulk_sales_total_water = $('#bulk_sales_total_water').val();
				var bulk_sales_total_amount = $('#bulk_sales_total_amount').val();
				var page = window.location.pathname;
				if (bulk_sales_debit !="") 
				{
					if (bulk_sales_credit !="") 
					{
						if (bulk_sales_total_weight !="") 
							{
								if (bulk_sales_total_water !="") 
								{
									if (bulk_sales_date !="") 
									{
										if (bulk_sales_total_amount !="") 
										{
											$.ajax({
												url:'/layout/vouchers/bulk_sales_update.php',
												method:'POST',
												data:$('#bulk_sales_create_form').serialize(),
												success:function()
												{
													$('#bulk_sales_create_form').trigger('reset');
													$('#bulk_sales_create_modal').modal('hide');
													window.open('/layout/vouchers/bulk_sales_pdf.php', '_blank');
													window.location.href= page;
												}
											});
										} 
										else 
										{
											alert('Please type the PRICE for item!');
										};
									} 
									else 
									{
										alert('Please select the date of sale!');
									};
								} 
								else 
								{
									alert('Please type the WATER weight!');
								};
							} 
							else 
							{
								alert('Please type the TOP weight (GRAMS)!');
							};
					} 
					else 
					{
						alert('Please select the ledger from which the sales was made (Sales Account)!');
					};
				} 
				else 
				{
					alert('Please select the ledger into which the sale was made (Creditor/Supplier Account)!');
				};
			});
		}

		function search_bulk_sales_by_name()
		{
			$(document).on('keyup','#bulk_sales_search_name',function(e){
				e.preventDefault();
				var company_id = $('#session_company_id').val();
				var sales_search_name = $('#bulk_sales_search_name').val();

				$.ajax({
					url:'/layout/vouchers/bulk_sales_search_by_name.php',
					method:'POST',
					data:{sales_search_name:sales_search_name,company_id:company_id},
					success:function(data)
						{
							$('#bulk_sales_list_card_body').html(data);
						}
				});
			});
		}

		function search_bulk_sales_by_date()
		{
			$(document).on('change','#bulk_sales_search_from, #bulk_sales_search_to',function(e){
				e.preventDefault();
				var start_date = $('#bulk_sales_search_from').val();
				var end_date = $('#bulk_sales_search_to').val();

				$.ajax({
					url:'/layout/vouchers/bulk_sales_search_by_date.php',
					method:'POST',
					data:{
						start_date:start_date,
						end_date:end_date
					},
					success:function(data)
					{
						$('#bulk_sales_list_table').html(data);
					}
				});
			});
		}

		function reprint_bulk_sales()
		{
			$(document).on('click','#btn_bulk_sales_re_print',function()
			{
				var bulk_sales_id = $(this).attr('data-id');
				
				$.ajax({
					url:'/layout/vouchers/bulk_sales_reprint.php',
					method:'POST',
					data:{
						bulk_sales_id:bulk_sales_id
					},
					success:function(data)
					{
						window.open('/layout/vouchers/bulk_sales_pdf.php', '_blank');
					}
				});
			});
		}

		function delete_bulk_sales()
		{
			$(document).on('click','#btn_delete_bulk_sales',function()
			{
				var bulk_sales_id = $(this).attr('data-id');
				var currentRow = $(this).closest("tr");
				var sales_date = currentRow.find("td:eq(1)").text();
				var Supplier = currentRow.find("td:eq(2)").text();
				$('#item_delete_question').text('Are you sure you want to delete sales invoice of ' + sales_date + ' for ' + Supplier + '?');
				$('#item_delete_modal').modal('show');
				$(document).on('click','#item_delete_yes',function()
				{
					$.ajax({  
						url:'/layout/vouchers/bulk_sales_delete.php',  
						type:'POST',  
						data:{bulk_sales_id:bulk_sales_id},
						success:function()
						{
							$('#item_delete_modal').modal('hide');
							window.location.href="/layout/vouchers/bulk_sales_list.php";
						}  
					});
				});
				$(document).on('click','#item_delete_no',function()
				{
					$('#item_delete_modal').modal('hide');
				});
			});
		}

	//STOCK_SALES
		function new_stock_sales_modal()
		{
			$(document).on('click','#new_stock_sales_icon',function()
			{
				$('#stock_sales_update_btn').hide();
				$('#stock_sales_save_btn').show();
				$('#stock_sales_create_form').trigger('reset');
				$('#stock_sales_create_modal').modal('show');
			});
		}

		function cancel_stock_sales_modal()
		{
			$(document).on('click','#stock_sales_cancel_btn',function()
			{
				var page = window.location.pathname;
				$('#stock_sales_create_form').trigger('reset');
				$('#stock_sales_create_modal').modal('hide');
				window.location.href= page;
				//window.location.href="/layout/vouchers/stock_sales_list.php";
			});
		}

		function add_stock_sales_item_row()
		{
			$(document).on('change','.stock_sales_desc',function(){ 
				var i = $('#stock_sales_items_table tr:last').attr('id');
				i++;
				$.ajax({
					url:'/layout/vouchers/stock_sales_item_list.php',
					method:'POST',
					data:{i:i},
					success:function(data)
					{
						$('#stock_sales_items_table').append('<tr id="'+i+'">'+data+'<td><input type="text" name="stock_sales_qty[]" class="form-control bg-light stock_sales_qty" id="stock_sales_qty'+i+'" data-id="'+i+'" style="border-width:0px"></td><td><input type="text" name="stock_sales_price[]" class="form-control bg-light stock_sales_price" id="stock_sales_price'+i+'" data-id="'+i+'" style="border-width:0px"></td><td><input type="text" name="stock_sales_amt[]" class="form-control bg-light" id="stock_sales_amt'+i+'" style="border-width:0px"></td><td><input type="text" name="stock_sales_batch[]" class="form-control bg-light" id="stock_sales_batch'+i+'" style="border-width:0px"></td><td><input type="date" name="stock_sales_expiry_date[]" class="form-control bg-light" id="stock_sales_expiry_date'+i+'" style="border-width:0px"></td><td><a href="#" id="delete_stock_sales_item" data-id="'+i+'"><i class="fa fa-trash fa-sm"></i></a></td></tr>');
					}
				});
			});
		}

		function add_stock_sales_item_price()
		{
			$(document).on('click','.stock_sales_desc',function(){
				var i = $('#stock_sales_items_table tr:last').attr('id');
				var stock_item_id = $('#stock_sales_desc'+i+'').val();
				$.ajax({
		             url:'/layout/vouchers/stock_sales_item_price.php',
		             method:'POST',
		             data:{stock_item_id:stock_item_id},
		             datatype:'JSON',
		             success:function(data)
		             {
		             	var res = $.parseJSON(data);
		             	$('#stock_sales_price'+i+'').val(res[0]);
		             }
		        });
			});
		}

		function get_stock_sales_item_amount()
		{
			$(document).on('change keyup', '.stock_sales_price, .stock_sales_qty', function(){  
       			var total_current = $('#stock_sales_amount').val();
       			var count = $(this).attr("data-id"); 
       			var qty = $('#stock_sales_qty'+count).val();
       			var price = $('#stock_sales_price'+count).val();
       			var amt_earlier = $('#stock_sales_amt'+count).val();
       			var amt = qty * price;
           		$('#stock_sales_amt'+count).val(amt);

           		var amount_item = parseFloat(amt);
           		if(amt_earlier == ''){var amt_previous = 0 }else{var amt_previous = parseFloat(amt_earlier)};
           		if(total_current == ''){var total_previous = 0 }else{var total_previous = parseFloat($('#stock_sales_amount').val())};
				var total = total_previous + amount_item - amt_previous;
           		$('#stock_sales_amount').val(total);
           		$('#stock_sales_amount_2').val(total);
           	});
		}

		function delete_stock_sales_item_row()
		{
			$(document).on('click', '#delete_stock_sales_item', function()
			{  
       			var button_id = $(this).attr("data-id");
       			var total_current = $('#stock_sales_amount').val();
       			var amt = $('#stock_sales_amt'+button_id).val();
       			if(amt == ''){var amount_item = 0 }else{var amount_item = parseFloat($('#stock_sales_amt'+button_id).val())};
       			if(total_current == ''){var total_previous = 0 }else{var total_previous = parseFloat($('#stock_sales_amount').val())};
				var total = total_previous - amount_item;
           		$('#stock_sales_amount').val(total);
           		$('#stock_sales_amount_2').val(total);
           		$('#'+button_id+'').remove();
           	});
		}

		function save_stock_sales()
		{
			$(document).on('click','#stock_sales_save_btn',function(e){
				e.preventDefault();
				var last_tr_id = $("#stock_sales_items_table tr:last").attr("id");
				var last_tr_select = $("#stock_sales_items_table tr:last option:selected").val();
				if(last_tr_select =="" || last_tr_select ==0)
				{
					$('#'+last_tr_id+'').remove();
				};
				var stock_sales_debit = $('#stock_sales_debit').val();
				var stock_sales_credit = $('#stock_sales_credit').val();
				var stock_sales_amount = $('#stock_sales_amount').val();
				var stock_sales_supplied_by = $('#stock_sales_supplied_by').val();
				var stock_sales_ref_no = $('#stock_sales_ref_no').val();
				var stock_sales_date = $('#stock_sales_date').val();
				var stock_sales_received_by = $('#stock_sales_received_by').val();
				var stock_sales_narration = $('#stock_sales_narration').val();
				var stock_sales_desc = $('#stock_sales_desc').val();
				var page = window.location.pathname;
				if (stock_sales_debit !=="") 
				{
					if (stock_sales_credit !=="") 
					{
						if (stock_sales_amount !=="") 
						{
							if (stock_sales_supplied_by !=="") 
							{
								if (stock_sales_ref_no !=="") 
								{
									if (stock_sales_date !=="") 
									{
										if (stock_sales_received_by !=="") 
										{
											if (stock_sales_desc !=="") 
											{
												$.ajax({
										             url:'/layout/vouchers/stock_sales_save.php',
										             method:'POST',
										             data:$('#stock_sales_create_form').serialize(),
										             success:function(data)
											             {
											             	$('#stock_sales_create_form').trigger('reset');
															 window.open('/layout/vouchers/stock_sales_pdf.php', '_blank');
											             	window.location.href= page;
											             	//window.location.href="/layout/vouchers/stock_sales_list.php";
											             }
										             });
											} 
											else 
											{
												alert('Please select an item sold!');
											}
										} 
										else 
										{
											alert('Please type the name of the person receiving the goods!');
										}
									} 
									else 
									{
										alert('Please select the date of sales!');
									}
								} 
								else 
								{
									alert('Please type the supplier invoice number!');
								}
							} 
							else 
							{
								alert('Please type the name of the person/institution from whom the sales was made!');
							}
						} 
						else 
						{
							alert('Please type price for each item sold!');
						}
					} 
					else 
					{
						alert('Please select the ledger from which the sales was made (Supplier or Cash Account)!');
					}
				} 
				else 
				{
					alert('Please select the ledger into which the sales was made (Purchases Account)!');
				};
			});
		}

		function edit_stock_sales()
		{
			/*$(document).on('click','#btn_edit_stock_sales',function(){
				var stock_sales_id = $(this).attr('data-id');
				$.ajax({
		             url:'/layout/vouchers/stock_sales_edit.php',
		             method:'POST',
		             data:{stock_sales_id:stock_sales_id},
		             datatype:'JSON',
		             success:function(data)
		             {
		             	var res = $.parseJSON(data);
		             	$('#stock_sales_id').val(res[0]);
		             	$('#stock_sales_date').val(res[1]);
		             	$('#stock_sales_debit').val(res[2]);
		             	$('#stock_sales_credit').val(res[3]);
		             	$('#stock_sales_amount').val(res[4]);
		             	$('#stock_sales_amount_2').val(res[4]);
		             	$('#stock_sales_ref_no').val(res[5]);
		             	$('#stock_sales_supplied_by').val(res[6]);
		             	$('#stock_sales_received_by').val(res[7]);
		             	$('#stock_sales_narration').val(res[8]);
		             	$('#stock_sales_branch_id').val(res[9]);
		             	$.ajax({
				            url:'/layout/vouchers/stock_sales_items_edit.php',
				            method:'POST',
				            data:{stock_sales_id:stock_sales_id},
				            success:function(data)
				            {
				            	$('#stock_sales_items_list').html(data);
							}
			             });
		             	$('#stock_sales_update_btn').show();
		             	$('#stock_sales_save_btn').hide();
						$('#stock_sales_create_modal').modal('show');
		             }
		        });
			});*/
		}

		function update_stock_sales()
		{
			$(document).on('click','#stock_sales_update_btn',function(e){
				e.preventDefault();

				var last_tr_id = $("#stock_sales_items_table tr:last").attr("id");
				var last_tr_select = $("#stock_sales_items_table tr:last option:selected").val();
				if(last_tr_select =="" || last_tr_select ==0)
				{
					$('#'+last_tr_id+'').remove();
				};
				var stock_sales_debit = $('#stock_sales_debit').val();
				var stock_sales_credit = $('#stock_sales_credit').val();
				var stock_sales_amount = $('#stock_sales_amount').val();
				var stock_sales_supplied_by = $('#stock_sales_supplied_by').val();
				var stock_sales_ref_no = $('#stock_sales_ref_no').val();
				var stock_sales_date = $('#stock_sales_date').val();
				var stock_sales_received_by = $('#stock_sales_received_by').val();
				var stock_sales_narration = $('#stock_sales_narration').val();
				var stock_sales_desc = $('#stock_sales_desc').val();
				var page = window.location.pathname;
				if (stock_sales_debit !=="") 
				{
					if (stock_sales_credit !=="") 
					{
						if (stock_sales_amount !=="") 
						{
							if (stock_sales_supplied_by !=="") 
							{
								if (stock_sales_ref_no !=="") 
								{
									if (stock_sales_date !=="") 
									{
										if (stock_sales_received_by !=="") 
										{
											if (stock_sales_desc !=="") 
											{
												$.ajax({
													url:'/layout/vouchers/stock_sales_update.php',
													method:'POST',
													data:$('#stock_sales_create_form').serialize(),
													success:function(data)
													{
														$('#stock_sales_create_form').trigger('reset');
														window.open('/layout/vouchers/stock_sales_pdf.php', '_blank');
														window.location.href= page;
														//window.location.href="/layout/vouchers/stock_sales_list.php";
													}
										        });
											} 
											else 
											{
												alert('Please select an item sold!');
											}
										} 
										else 
										{
											alert('Please type the name of the person receiving the goods!');
										}
									} 
									else 
									{
										alert('Please select the date of sales!');
									}
								} 
								else 
								{
									alert('Please type the supplier invoice number!');
								}
							} 
							else 
							{
								alert('Please type the name of the person/institution from whom the sales was made!');
							}
						} 
						else 
						{
							alert('Please type price for each item sold!');
						}
					} 
					else 
					{
						alert('Please select the ledger from which the sales was made (Supplier or Cash Account)!');
					}
				} 
				else 
				{
					alert('Please select the ledger into which the sales was made (Purchases Account)!');
				};
			});
		}

		function reprint_stock_sales()
		{
			$(document).on('click','#btn_stock_sales_reprint',function(){
				var stock_sales_id = $(this).attr('data-id');
				$.ajax({
		             url:'/layout/vouchers/stock_sales_reprint.php',
		             method:'POST',
		             data:{
						stock_sales_id:stock_sales_id
		             },
		             success:function(data)
		             {
		             	window.open('/layout/vouchers/stock_sales_pdf.php', '_blank');
		             }
		        });
			});
		}

		function delete_stock_sales()
		{
			$(document).on('click','#btn_delete_stock_sales',function(){
				var stock_sales_id = $(this).attr('data-id');
				var currentRow=$(this).closest("tr");
				var sales_date = currentRow.find("td:eq(1)").text();
				//var Supplier = currentRow.find("td:eq(3)").text();
				$('#stock_sales_invoice_delete_question').text('Are you sure you want to delete stock sales invoice of ' + sales_date + '?');
				$('#stock_sales_invoice_delete_modal').modal('show');
				$(document).on('click','#stock_sales_delete_yes',function(){
					$.ajax({  
		                 url:'/layout/vouchers/stock_sales_delete.php',  
		                 type:'POST',  
		                 data:{stock_sales_id:stock_sales_id},
		                 success:function(){
		                 	$('#stock_sales_invoice_delete_modal').modal('hide');
		                 	window.location.href="/layout/vouchers/stock_sales_list.php";
		                 }  
		            });
			      });
				$(document).on('click','#stock_sales_delete_no',function(){
					$('#stock_sales_invoice_delete_modal').modal('hide');
				});
			});
		}
		
		function search_stock_sales_invoice_by_name()
		{
			$(document).on('keyup','#stock_sales_name',function(e){
				e.preventDefault();
				var company_id = $('#session_company_id').val();
				var name = $('#stock_sales_name').val();

				$.ajax({
					url:'/layout/vouchers/stock_sales_search_by_name.php',
					method:'POST',
					data:{name:name,company_id:company_id},
					success:function(data)
					{
						$('#stock_sales_list_table').html(data);
					}
		        });
			});
		}

		function search_stock_sales_invoice_by_date()
		{
			$(document).on('click','#stock_sales_search_icon',function(e){
				e.preventDefault();
				var company_id = $('#session_company_id').val();
				var start_date = $('#stock_sales_search_from').val();
				var end_date = $('#stock_sales_search_to').val();

				$.ajax({
		             url:'/layout/vouchers/stock_sales_search_by_date.php',
		             method:'POST',
		             data:{start_date:start_date,end_date:end_date,company_id:company_id},
		             success:function(data)
			             {
			             	$('#stock_sales_list_table').html(data);
			             }
		        });
			});
		}

	//STOCK_SALES_INVOICE
		function stock_sales_invoice_add_ledger()
		{
			$(document).on('click','#stock_sales_invoice_add_ledger',function(){
				var i = $('#stock_sales_invoice_payment_optionTable tr:last').attr('id');
				$.ajax({
					url:'/layout/vouchers/stock_sales_invoice_add_ledger.php',
					method:'POST',
					data:{i:i},
					success:function(data)
					{
						$('#stock_sales_invoice_payment_optionTable').append(data);
					}
				});
			});
		}

		function stock_sales_invoice_sum_payment_amount()
		{
			$(document).on('keyup', '.payment_option_amount', function()
			{  
				var button_id = $(this).closest('tr').attr('id');
				var ledger_id = $('#payment_option_ledger_id'+button_id).val();
				
				if(ledger_id !='' && ledger_id > 0)
				{
					var sum = 0;
					$(".payment_option_amount").each(function(){
						sum += +$(this).val();
					});
					$("#payment_option_total").val(sum);
					$("#payment_option_cash_tendered").val(sum);
				}
				else
				{
					$(this).val(0);
					alert('Please select the ledger first!');
				};
			});
		}

		function stock_sales_invoice_delete_ledger()
		{
			$(document).on('click', '#delete_payment_option_ledger', function()
			{  
				var button_id = $(this).attr("data-id");
				$('#'+button_id+'').remove();
				var sum = 0;
				$(".payment_option_amount").each(function()
				{
					sum += +$(this).val();
				});
				$("#payment_option_total").val(sum);
				$("#payment_option_cash_tendered").val(sum);
			});
		}

		function stock_sales_invoice_change_amount()
		{
			$(document).on('change', '#payment_option_cash_tendered', function()
			{  
				var total = $('#payment_option_total').val();
				var cash_tendered = $('#payment_option_cash_tendered').val();
				
				if(cash_tendered >=total)
				{
					var change = cash_tendered - total;
					$("#payment_option_change").val(change);
				}
				else
				{
					$(this).val(0);
					alert('Please cash tendered cannot be less than the Total invoice value!');
				};
			});
		}

		function stock_sales_invoice_item_search_modal()
		{
			$(document).on('click','#stock_sales_invoice_search_item',function()
			{
				$('#item_search').prop('id','customer_search');
				$('#customer_list_table').html('');
				$('#item_search_modal_header').text('Item Search');
				$('#item_search_modal_form').trigger('reset');
				$('#item_search_modal').modal('show');
			});
		}
	
		function stock_sales_invoice_item_search()
		{
			$(document).on('keyup','#customer_search',function(e){
				e.preventDefault();
				
				var search = $('#customer_search').val();
				$.ajax({
					url:'/layout/vouchers/stock_sales_invoice_item_search.php',
					method:'POST',
					data:{
						search:search
					},
					success:function(data)
					{
						$('#customer_list_table').html(data);
					}
				});
			});
		}

		function add_stock_sales_invoice_item_row()
		{
			$(document).on('click','#btn_add_stock_sales_invoice_item',function()
			{
				var count = $('#stock_sales_invoiceTable tr:last').attr('id');
				var stock_item_id = $(this).attr('data-id');
				var stock_item = $(this).attr('data-id1');
				var price = $(this).attr('data-id2');
				var i = $(this).closest('tr').attr('id');
				var qty = $('#item_search_qty'+i).val();
				if($('#stock_sales_invoice_discount').val() != '')
				{
					var discount = parseFloat($('#stock_sales_invoice_discount').val());
				}
				else
				{
					var discount = 0;
				}
				if($('#stock_sales_invoice_tax').val() != '')
				{
					var tax = parseFloat($('#stock_sales_invoice_tax').val());
				}
				else
				{
					var tax = 0;
				}
				var amount = qty * price;
				if(qty !='' && qty > 0)
				{
					$.ajax({
						url:'/layout/vouchers/stock_sales_invoice_item_search_save.php',
						method:'POST',
						data:{
							stock_item_id:stock_item_id,
							stock_item:stock_item,
							qty:qty,
							price:price,
							amount:amount,
							count:count
						},
						datatype:'JSON',
						success:function(data)
						{
							$('#item_search_modal_form').trigger('reset');
							$('#customer_search').focus();
							$('#stock_sales_invoiceTable').append(data);
							var sum = 0;
							$(".stock_sales_invoice_item_amount").each(function()
							{
								sum += +$(this).val();
							});
							sub_total = parseFloat(sum);
							var net = sub_total - discount + tax;
							$("#stock_sales_invoice_sub_total").val(sub_total);
							$("#stock_sales_invoice_sub_totalD").val(sub_total);
							$("#stock_sales_invoice_net_total").val(net);
							$("#stock_sales_invoice_net_totalD").val(net);
						}
					});
				}
				else
				{
					alert('Please the quantity cannot be EMPTY!');
				};
			});
		}

		function stock_sales_invoice_delete_item()
		{
			$(document).on('click', '#delete_stock_sales_invoice_item', function()
			{  
				var button_id = $(this).attr("data-id");
				$('#item_list'+button_id+'').remove();
				
				var sum = 0;
				$(".stock_sales_invoice_item_amount").each(function(){
					sum += +$(this).val();
				});
				$("#stock_sales_invoice_sub_total").val(sum);
				$("#stock_sales_invoice_sub_totalD").val(sum);
				$("#stock_sales_invoice_net_total").val(sum);
				$("#stock_sales_invoice_net_totalD").val(sum);
			});
		}

		function stock_sales_invoice_calculate_net_amount()
		{
			$(document).on('keyup', '#stock_sales_invoice_discount, #stock_sales_invoice_tax', function()
			{  
				if($('#stock_sales_invoice_discount').val() != '')
				{
					var discount = parseFloat($('#stock_sales_invoice_discount').val());
				}
				else
				{
					var discount = 0;
				};

				if($('#stock_sales_invoice_tax').val() != '')
				{
					var tax = parseFloat($('#stock_sales_invoice_tax').val());
				}
				else
				{
					var tax = 0;
				};
				var sub_total = parseFloat($('#stock_sales_invoice_sub_total').val());
				var net = sub_total + tax - discount;
				$("#stock_sales_invoice_discountD").val(discount);
				$("#stock_sales_invoice_taxD").val(tax);
				$("#stock_sales_invoice_net_total").val(net);
				$("#stock_sales_invoice_net_totalD").val(net);
			});
		}

		function save_stock_sales_invoice()
		{
			$(document).on('click','#stock_sales_invoice_save_btn',function(e){
				e.preventDefault();
				var customer_id = $('#stock_sales_invoice_customer_id').val();
				var cash_tendered = $('#payment_option_cash_tendered').val();
				var net_total = $('#stock_sales_invoice_net_total').val();
				var default_warehouse = $('#stock_sales_invoice_default_warehouse').val();
				var default_date = $('#default_date').val();
				var payment_option_total = $('#payment_option_total').val();
				
				var page = window.location.pathname;

				if (customer_id !="" && customer_id > 0) 
				{
					if (net_total !="" && net_total > 0) 
					{
						if (payment_option_total !="" && payment_option_total > 0) 
						{
							if (net_total == payment_option_total) 
							{
								if (cash_tendered >= payment_option_total) 
								{
									$.ajax({
										url:'/layout/vouchers/stock_sales_invoice_save.php',
										method:'POST',
										data:$('#stock_sales_invoice_form').serialize(),
										success:function(data)
										{
											//$('#stock_sales_invoice_form').trigger('reset');
											//window.location.href="/layout/vouchers/stock_sales_invoice_template.php";
											window.open('/layout/vouchers/stock_sales_invoice_pdf.php', '_blank');
											window.location.href= page;
										}
									});
								} 
								else 
								{
									alert('Please the Cash Tendered cannot be Empty!');
								};
							} 
							else 
							{
								alert('Please the Total Cash Tendered and the Total Invoice value should be the same!');
							};
						} 
						else 
						{
							alert('Please the TENDERED Amount cannot be empty!');
						};
					} 
					else 
					{
						alert('Please select the ITEMS to selll!');
					};
				} 
				else 
				{
					alert('Please the CUSTOMER cannot be empty!');
				};
			});
		}

		function display_stock_sales_invoice()
		{
			$(document).on('click','#btn_display_stock_sales',function()
			{
				var stock_sales_id = $(this).attr('data-id');
				$.ajax({
					url:'/layout/vouchers/stock_sales_invoice_display.php',
					method:'POST',
					data:{stock_sales_id:stock_sales_id},
					datatype:'JSON',
					success:function(data)
					{
						window.location.href="/layout/vouchers/stock_sales_invoice_template.php";
					}
		        });
			});
		}

		function edit_stock_sales_invoice()
		{
			$(document).on('click','#btn_edit_stock_sales',function()
			{
				var stock_sales_id = $(this).attr('data-id');
				$.ajax({
					url:'/layout/vouchers/stock_sales_invoice_edit.php',
					method:'POST',
					data:{stock_sales_id:stock_sales_id},
					datatype:'JSON',
					success:function(data)
					{
						var res = $.parseJSON(data);
						$('#stock_sales_invoice_customer_details').html(res[0]);
						$('#stock_sales_invoice_payment_option').html(res[1]);
						$('#stock_sales_invoice_list_table').html(res[2]);
						$('#stock_sales_invoice_total_table').html(res[3]);
						$('#stock_sales_invoice_warehouse_cash_ledger').html(res[4]);
						$('#stock_sales_invoice_id').val(res[5]);
						$('#stock_sales_update_btn').show();
						$('#stock_sales_save_btn').hide();
						$('#stock_sales_invoice_modal').modal('show');
					}
		        });
			});
		}

		function update_stock_sales_invoice()
		{
			$(document).on('click','#stock_sales_invoice_update_btn',function(e)
			{
				e.preventDefault();
				var customer_id = $('#stock_sales_invoice_customer_id').val();
				var cash_tendered = $('#payment_option_cash_tendered').val();
				var net_total = $('#stock_sales_invoice_net_total').val();
				var default_warehouse = $('#stock_sales_invoice_default_warehouse').val();
				var default_date = $('#default_date').val();
				var payment_option_total = $('#payment_option_total').val();
				
				var page = window.location.pathname;

				if (customer_id !="" && customer_id > 0) 
				{
					if (net_total !="" && net_total > 0) 
					{
						if (payment_option_total !="" && payment_option_total > 0) 
						{
							if (net_total == payment_option_total) 
							{
								if (cash_tendered >= payment_option_total) 
								{
									$.ajax({
										url:'/layout/vouchers/stock_sales_invoice_update.php',
										method:'POST',
										data:$('#stock_sales_invoice_form').serialize(),
										success:function(data)
										{
											window.open('/layout/vouchers/stock_sales_invoice_pdf.php', '_blank');
											window.location.href= page;
										}
									});
								} 
								else 
								{
									alert('Please the Cash Tendered cannot be Empty!');
								};
							} 
							else 
							{
								alert('Please the Total Cash Tendered and the Total Invoice value should be the same!');
							};
						} 
						else 
						{
							alert('Please the TENDERED Amount cannot be empty!');
						};
					} 
					else 
					{
						alert('Please select the ITEMS to selll!');
					};
				} 
				else 
				{
					alert('Please the CUSTOMER cannot be empty!');
				};
			});
		}

		function reprint_stock_sales_invoice()
		{
			$(document).on('click','#btn_stock_sales_invoice_reprint',function(){
				var stock_sales_id = $(this).attr('data-id');
				var customer_name = $(this).attr('data-id1');
				$.ajax({
		             url:'/layout/vouchers/stock_sales_invoice_reprint.php',
		             method:'POST',
		             data:{
						stock_sales_id:stock_sales_id,
						customer_name:customer_name
		             },
		             success:function(data)
		             {
						window.open('/layout/vouchers/stock_sales_invoice_pdf.php', '_blank');
		             }
		        });
			});
		}
	
	//SMS
		function sms_purchase_modal()
		{
			$(document).on('click','#new_sms_purchase_icon',function()
			{
				var company_id = $('#session_company').val();
				$('#sms_company').val(company_id);
				$('#sms_company_2').val(company_id);
				$('#sms_update_btn').hide();
				$('#sms_save_btn').show();
				$('#sms_cancel_btn').show();
				$('#sms_purchase_create_form').trigger('reset');
				$('#sms_purchase_create_modal').modal('show');
			});
		}

		function save_sms_purchase()
		{
			$(document).on('click','#sms_save_btn',function(){
				var sms_date = $('#sms_date').val();
				var sms_qty = $('#sms_qty').val();
				if (sms_date !=="") 
				{
					if (sms_qty !=="" && sms_qty > 0 ) 
					{
						$.ajax({
							url:'/layout/vouchers/sms_save.php',
							method:'POST',
							data:$('#sms_purchase_create_form').serialize(),
							success:function(data){
								$('#sms_purchase_create_modal').modal('hide');
								$('#sms_purchase_create_form').trigger('reset');
								$('#sms_list_table').html(data);
							}
						});
					} 
					else 
					{
						alert('Please the Qty cannot be EMPTY!');
					};
				} 
				else 
				{
					alert('Please the Date cannot be EMPTY!');
				};
			});
		}

		function edit_sms_purchase()
		{
			$(document).on('click','#btn_edit_sms_purchase',function()
			{
				var sms_utility_id = $(this).attr('data-id');
				$.ajax({
					url:'/layout/vouchers/sms_edit.php',
					method:'POST',
					data:{sms_utility_id:sms_utility_id},
					datatype: 'JSON',
					success:function(data){
						var res = $.parseJSON(data);
						$('#sms_utility_id').val(res[0]);
						$('#sms_date').val(res[1]);
						$('#sms_qty').val(res[2]);
						$('#sms_update_btn').show();
						$('#sms_save_btn').hide();
						$('#sms_purchase_create_modal_header').html('SMS Purchase Edit');
						$('#sms_purchase_create_modal').modal('show');
					}
				});
			});
		}

		function update_sms_purchase()
		{
			$(document).on('click','#sms_update_btn',function(){
				var sms_date = $('#sms_date').val();
				var sms_qty = $('#sms_qty').val();
				if (sms_date !=="") 
				{
					if (sms_qty !=="" && sms_qty > 0 ) 
					{
						$.ajax({
							url:'/layout/vouchers/sms_update.php',
							method:'POST',
							data:$('#sms_purchase_create_form').serialize(),
							success:function(data){
								$('#sms_purchase_create_modal').modal('hide');
								$('#sms_purchase_create_form').trigger('reset');
								$('#sms_list_table').html(data);
							}
						});
					} 
					else 
					{
						alert('Please the Qty cannot be EMPTY!');
					};
				} 
				else 
				{
					alert('Please the Date cannot be EMPTY!');
				};
			});
		}
//REPORTS
	//PURCHASE REPORT
		function purchase_report_modal()
		{
			$(document).on('click','#purchase_report_link',function()
			{
				var company_id = $('#session_company_id').val();
				var user_super_id = $('#session_user_super_id').val();
				var start_date = $('#purch_report_start_date').val();
				var end_date = $('#purch_report_end_date').val();
				$('#purchase_report_modal_form').trigger('reset');
				$('#purch_report_company_id').val(company_id);
				$('#purch_report_user_super_id').val(user_super_id);
				$('#purchase_report_modal').modal('show');
			}) 
		}

		function purchase_report_display()
		{
			$(document).on('click','#purch_report_ok_btn',function()
			{
				var company_id = $('#session_company_id').val();
				var user_super_id = $('#session_user_super_id').val();
				var start_date = $('#purch_report_start_date').val();
				var end_date = $('#purch_report_end_date').val();
				if (start_date !== "") 
				{
					if (end_date !== "") 
					{
						if (end_date >= start_date) 
						{
							$.ajax({
					             url:'/layout/reports/purchase_report_processing.php',
					             method:'POST',
					             data:$('#purchase_report_modal_form').serialize(),
					             success:function(data)
						             {
						             	//$('#purchase_report_modal_form').trigger('reset');
				             			$('#purchase_report_modal').modal('hide');
				             			window.open('/layout/reports/purchase_report_display.php', '_blank');
						             }
					        });	
						} 
						else 
						{
							$('#purchase_report_modal_warning').html('<h6 style=color:red;>Please the End Date cannot be less than the Start Date!</h6>');
							$('#purchase_report_modal_warning').hide().slideDown().delay(2000).fadeOut();
						};
					} 
					else 
					{
						$('#purchase_report_modal_warning').html('<h6 style=color:red;>Please the End Date cannot be EMPTY!</h6>');
						$('#purchase_report_modal_warning').hide().slideDown().delay(2000).fadeOut();
					};
				} 
				else 
				{
					$('#purchase_report_modal_warning').html('<h6 style=color:red;>Please the Start Date cannot be EMPTY!</h6>');
					$('#purchase_report_modal_warning').hide().slideDown().delay(2000).fadeOut();
				};
			}); 
		}

		function purchase_report_by_branch_modal()
		{
			$(document).on('click','#purchase_report_by_branch_link',function()
			{
				var company_id = $('#session_company_id').val();
				var user_super_id = $('#session_user_super_id').val();
				var start_date = $('#prbb_start_date').val();
				var end_date = $('#prbb_end_date').val();
				$('#purchase_report_by_branch_modal_form').trigger('reset');
				$('#prbb_company_id').val(company_id);
				$('#prbb_user_super_id').val(user_super_id);
				$('#purchase_report_by_branch_modal').modal('show');
			}) 
		}

		function purchase_report_by_branch_display()
		{
			$(document).on('click','#prbb_ok_btn',function()
			{
				var company_id = $('#session_company_id').val();
				var user_super_id = $('#session_user_super_id').val();
				var start_date = $('#prbb_start_date').val();
				var end_date = $('#prbb_end_date').val();
				if (start_date !== "") 
				{
					if (end_date !== "") 
					{
						if (end_date >= start_date) 
						{
							$.ajax({
					             url:'/layout/reports/purchase_report_br_branch_processing.php',
					             method:'POST',
					             data:$('#purchase_report_by_branch_modal_form').serialize(),
					             success:function()
								{
									//$('#purchase_report_modal_form').trigger('reset');
									$('#purchase_report_by_branch_modal').modal('hide');
									window.open('/layout/reports/purchase_report_by_branch_display.php', '_blank');
								}
					        });	
						} 
						else 
						{
							$('#purchase_report_by_branch_modal_warning').html('<h6 style=color:red;>Please the End Date cannot be less than the Start Date!</h6>');
							$('#purchase_report_by_branch_modal_warning').hide().slideDown().delay(2000).fadeOut();
						};
					} 
					else 
					{
						$('#purchase_report_by_branch_modal_warning').html('<h6 style=color:red;>Please the End Date cannot be EMPTY!</h6>');
						$('#purchase_report_by_branch_modal_warning').hide().slideDown().delay(2000).fadeOut();
					};
				} 
				else 
				{
					$('#purchase_report_by_branch_modal_warning').html('<h6 style=color:red;>Please the Start Date cannot be EMPTY!</h6>');
					$('#purchase_report_by_branch_modal_warning').hide().slideDown().delay(2000).fadeOut();
				};
			}); 
		}

		function profitability_report_modal()
		{
			$(document).on('click','#profitability_report_link',function()
			{
				var company_id = $('#session_company_id').val();
				var user_super_id = $('#session_user_super_id').val();
				var start_date = $('#profitability_report_start_date').val();
				var end_date = $('#profitability_report_end_date').val();
				$('#profitability_report_modal_form').trigger('reset');
				$('#profitability_report_company_id').val(company_id);
				$('#profitability_report_user_super_id').val(user_super_id);
				$('#profitability_report_modal').modal('show');
			}) 
		}

		function profitability_report_display()
		{
			$(document).on('click','#profitability_report_ok_btn',function()
			{
				var company_id = $('#session_company_id').val();
				var user_super_id = $('#session_user_super_id').val();
				var start_date = $('#profitability_report_start_date').val();
				var end_date = $('#profitability_report_end_date').val();
				if (start_date !== "") 
				{
					if (end_date !== "") 
					{
						if (end_date >= start_date) 
						{
							$.ajax({
					             url:'/layout/reports/profitability_report_processing.php',
					             method:'POST',
					             data:$('#profitability_report_modal_form').serialize(),
					             success:function(data)
						             {
						             	//$('#purchase_report_modal_form').trigger('reset');
				             			$('#profitability_report_modal').modal('hide');
				             			window.open('/layout/reports/profitability_report_display.php', '_blank');
						             }
					        });	
						} 
						else 
						{
							$('#profitability_report_modal_warning').html('<h6 style=color:red;>Please the End Date cannot be less than the Start Date!</h6>');
							$('#profitability_report_modal_warning').hide().slideDown().delay(2000).fadeOut();
						};
					} 
					else 
					{
						$('#profitability_report_modal_warning').html('<h6 style=color:red;>Please the End Date cannot be EMPTY!</h6>');
						$('#profitability_report_modal_warning').hide().slideDown().delay(2000).fadeOut();
					};
				} 
				else 
				{
					$('#profitability_report_modal_warning').html('<h6 style=color:red;>Please the Start Date cannot be EMPTY!</h6>');
					$('#profitability_report_modal_warning').hide().slideDown().delay(2000).fadeOut();
				};
			}); 
		}

	//SALES REPORT
		function sales_report_modal()
		{
			$(document).on('click','#sales_report_link',function()
			{
				var company_id_sales = $('#session_company_id').val();
				var user_super_id_sales = $('#session_user_super_id').val();
				var start_date_sales = $('#start_date_sales').val();
				var end_date_sales = $('#end_date_sales').val();
				$('#sales_report_modal_form').trigger('reset');
				$('#company_id_sales').val(company_id_sales);
				$('#user_super_id_sales').val(user_super_id_sales);
				$('#sales_report_modal').modal('show');
			}) 
		}

		function sales_report_display()
		{
			$(document).on('click','#sales_report_ok_btn',function()
			{
				var company_id_sales = $('#session_company_id').val();
				var user_super_id_sales = $('#session_user_super_id').val();
				var start_date_sales = $('#start_date_sales').val();
				var end_date_sales = $('#end_date_sales').val();
				if (start_date_sales !== "") 
				{
					if (end_date_sales !== "") 
					{
						if (end_date_sales >= start_date_sales) 
						{
							$.ajax({
					             url:'/layout/reports/sales_report_processing.php',
					             method:'POST',
					             data:$('#sales_report_modal_form').serialize(),
					             success:function(data)
						             {
				             			$('#sales_report_modal').modal('hide');
				             			window.open('/layout/reports/sales_report_display.php', '_blank');
						             }
					        });	
						} 
						else 
						{
							$('#sales_report_modal_warning').html('<h6 style=color:red;>Please the End Date cannot be less than the Start Date!</h6>');
							$('#sales_report_modal_warning').hide().slideDown().delay(2000).fadeOut();
						};
					} 
					else 
					{
						$('#sales_report_modal_warning').html('<h6 style=color:red;>Please the End Date cannot be EMPTY!</h6>');
						$('#sales_report_modal_warning').hide().slideDown().delay(2000).fadeOut();
					};
				} 
				else 
				{
					$('#sales_report_modal_warning').html('<h6 style=color:red;>Please the Start Date cannot be EMPTY!</h6>');
					$('#sales_report_modal_warning').hide().slideDown().delay(2000).fadeOut();
				};
			}); 
		}

	//LEDGER REPORT
		function ledger_report_modal()
		{
			$(document).on('click','#ledger_report_link',function()
			{
				var company_id = $('#session_company_id').val();
				var user_super_id = $('#session_user_super_id').val();
				$('#sales_report_modal_form').trigger('reset');
				$('#ledger_report_company_id').val(company_id);
				$('#ledger_report_user_super_id').val(user_super_id);
				$('#ledger_report_modal').modal('show');
			}) 
		}

		function ledger_report_display()
		{
			$(document).on('click','#ledger_report_ok_btn',function()
			{
				var company_id = $('#ledger_report_company_id').val();
				var user_super_id = $('#ledger_report_user_super_id').val();
				var ledger_id = $('#ledger_report_ledger_id').val();
				var start_date = $('#ledger_report_start_date').val();
				var end_date = $('#ledger_report_end_date').val();
				if (ledger_id > 0) 
				{
					if (start_date !== "") 
					{
						if (end_date !== "") 
						{
							if (end_date >= start_date) 
							{
								$.ajax({
						             url:'/layout/reports/ledger_report_processing.php',
						             method:'POST',
						             data:$('#ledger_report_modal_form').serialize(),
						             success:function(data)
							             {
					             			$('#ledger_report_modal').modal('hide');
					             			window.open('/layout/reports/ledger_report_display.php', '_blank');
							             }
						        });	
							} 
							else 
							{
								$('#ledger_report_modal_warning').html('<h6 style=color:red;>Please the End Date cannot be less than the Start Date!</h6>');
								$('#ledger_report_modal_warning').hide().slideDown().delay(2000).fadeOut();
							};
						} 
						else 
						{
							$('#ledger_report_modal_warning').html('<h6 style=color:red;>Please the End Date cannot be EMPTY!</h6>');
							$('#ledger_report_modal_warning').hide().slideDown().delay(2000).fadeOut();
						};
					} 
					else 
					{
						$('#ledger_report_modal_warning').html('<h6 style=color:red;>Please the Start Date cannot be EMPTY!</h6>');
						$('#ledger_report_modal_warning').hide().slideDown().delay(2000).fadeOut();
					};
				} 
				else 
				{
					$('#ledger_report_modal_warning').html('<h6 style=color:red;>Please the Ledger cannot be EMPTY!</h6>');
					$('#ledger_report_modal_warning').hide().slideDown().delay(2000).fadeOut();
				};
			}); 
		}

		function ledger_report_display_with_item_detail()
		{
			$(document).on('click','#btn_ledger_report_display_with_item_detail',function(e)
			{
				e.preventDefault();
				var ledger_report_company_id = $(this).attr('data-id');
				var ledger_report_user_id = $(this).attr('data-id1');
				var ledger_report_user_super_id = $(this).attr('data-id2');
				var ledger_report_ledger_id = $(this).attr('data-id3');
				var ledger_report_start_date = $(this).attr('data-id4');
				var ledger_report_end_date = $(this).attr('data-id5');
				$.ajax({
					url:'/layout/reports/ledger_report_processing.php',
					method:'POST',
					data:{
						ledger_report_company_id:ledger_report_company_id,
						ledger_report_user_id:ledger_report_user_id,
						ledger_report_user_super_id:ledger_report_user_super_id,
						ledger_report_ledger_id:ledger_report_ledger_id,
						ledger_report_start_date:ledger_report_start_date,
						ledger_report_end_date:ledger_report_end_date
					},
					success:function(data)
					{
						window.open('/layout/reports/ledger_report_display_with_item_detail.php', '_blank');
					}
				});
			}); 
		}

	//LEDGER DETAIL REPORT
		function ledger_detail_report_modal()
		{
			$(document).on('click','#ledger_detail_report_link',function()
			{
				var company_id = $('#session_company_id').val();
				var user_super_id = $('#session_user_super_id').val();
				$('#ledger_detail_report_modal_form').trigger('reset');
				$('#ledger_detail_report_company_id').val(company_id);
				$('#ledger_detail_report_user_super_id').val(user_super_id);
				$('#ledger_detail_report_modal').modal('show');
			}) 
		}

		function ledger_detail_report_display()
		{
			$(document).on('click','#ledger_detail_report_ok_btn',function()
			{
				var company_id = $('#ledger_detail_report_company_id').val();
				var user_super_id = $('#ledger_detail_report_user_super_id').val();
				var start_date = $('#ledger_detail_report_start_date').val();
				var end_date = $('#ledger_detail_report_end_date').val();
				
				if (start_date !== "") 
				{
					if (end_date !== "") 
					{
						if (end_date >= start_date) 
						{
							$.ajax({
					             url:'/layout/reports/ledger_detail_report_processing.php',
					             method:'POST',
					             data:$('#ledger_detail_report_modal_form').serialize(),
					             success:function(data)
						             {
				             			$('#ledger_detail_report_modal').modal('hide');
				             			window.open('/layout/reports/ledger_detail_report_display.php', '_blank');
						             }
					        });	
						} 
						else 
						{
							$('#ledger_detail_report_modal_warning').html('<h6 style=color:red;>Please the End Date cannot be less than the Start Date!</h6>');
							$('#ledger_detail_report_modal_warning').hide().slideDown().delay(2000).fadeOut();
						};
					} 
					else 
					{
						$('#ledger_detail_report_modal_warning').html('<h6 style=color:red;>Please the End Date cannot be EMPTY!</h6>');
						$('#ledger_detail_report_modal_warning').hide().slideDown().delay(2000).fadeOut();
					};
				} 
				else 
				{
					$('#ledger_detail_report_modal_warning').html('<h6 style=color:red;>Please the Start Date cannot be EMPTY!</h6>');
					$('#ledger_detail_report_modal_warning').hide().slideDown().delay(2000).fadeOut();
				};
			}); 
		}

	//LEDGER SUMMARY REPORT
		function ledger_summary_report_modal()
		{
			$(document).on('click','#ledger_summary_report_link',function()
			{
				var company_id = $('#session_company_id').val();
				var user_super_id = $('#session_user_super_id').val();
				$('#ledger_summary_report_modal_form').trigger('reset');
				$('#ledger_summary_report_company_id').val(company_id);
				$('#ledger_summary_report_user_super_id').val(user_super_id);
				$('#ledger_summary_report_modal').modal('show');
			}) 
		}

		function ledger_summary_report_display()
		{
			$(document).on('click','#ledger_summary_report_ok_btn',function()
			{
				var company_id = $('#ledger_summary_report_company_id').val();
				var user_super_id = $('#ledger_summary_report_user_super_id').val();
				var start_date = $('#ledger_summary_report_start_date').val();
				var end_date = $('#ledger_summary_report_end_date').val();
				
				if (start_date !== "") 
				{
					if (end_date !== "") 
					{
						if (end_date >= start_date) 
						{
							$.ajax({
					             url:'/layout/reports/ledger_summary_report_processing.php',
					             method:'POST',
					             data:$('#ledger_summary_report_modal_form').serialize(),
					             success:function(data)
						             {
				             			$('#ledger_summary_report_modal').modal('hide');
				             			window.open('/layout/reports/ledger_summary_report_display.php', '_blank');
						             }
					        });	
						} 
						else 
						{
							$('#ledger_summary_report_modal_warning').html('<h6 style=color:red;>Please the End Date cannot be less than the Start Date!</h6>');
							$('#ledger_summary_report_modal_warning').hide().slideDown().delay(2000).fadeOut();
						};
					} 
					else 
					{
						$('#ledger_summary_report_modal_warning').html('<h6 style=color:red;>Please the End Date cannot be EMPTY!</h6>');
						$('#ledger_summary_report_modal_warning').hide().slideDown().delay(2000).fadeOut();
					};
				} 
				else 
				{
					$('#ledger_summary_report_modal_warning').html('<h6 style=color:red;>Please the Start Date cannot be EMPTY!</h6>');
					$('#ledger_summary_report_modal_warning').hide().slideDown().delay(2000).fadeOut();
				};
			}); 
		}
	//CASH REPORT
		function cash_report_modal()
		{
			$(document).on('click','#cash_report_link',function()
			{
				var company_id = $('#session_company_id').val();
				var user_super_id = $('#session_user_super_id').val();
				$('#cash_report_modal_form').trigger('reset');
				$('#cash_report_company_id').val(company_id);
				$('#cash_report_user_super_id').val(user_super_id);
				$('#cash_report_modal').modal('show');
			}) 
		}

		function cash_report_display()
		{
			$(document).on('click','#cash_report_ok_btn',function()
			{
				//var company_id = $('#cash_report_company_id').val();
				//var user_super_id = $('#cash_report_user_super_id').val();
				var ledger_id = $('#cash_report_ledger_id').val();
				var start_date = $('#cash_report_start_date').val();
				var end_date = $('#cash_report_end_date').val();
				if (ledger_id > 0 || ledger_id == 'ALL') 
				{
					if (start_date !== "") 
					{
						if (end_date !== "") 
						{
							if (end_date >= start_date) 
							{
								$.ajax({
									url:'/layout/reports/cash_report_processing.php',
									method:'POST',
									data:$('#cash_report_modal_form').serialize(),
									success:function()
									{
										$('#cash_report_modal').modal('hide');
										window.open('/layout/reports/cash_report_display.php', '_blank');
									}
								});	
							} 
							else 
							{
								$('#ledger_report_modal_warning').html('<h6 style=color:red;>Please the End Date cannot be less than the Start Date!</h6>');
								$('#ledger_report_modal_warning').hide().slideDown().delay(2000).fadeOut();
							};
						} 
						else 
						{
							$('#ledger_report_modal_warning').html('<h6 style=color:red;>Please the End Date cannot be EMPTY!</h6>');
							$('#ledger_report_modal_warning').hide().slideDown().delay(2000).fadeOut();
						};
					} 
					else 
					{
						$('#ledger_report_modal_warning').html('<h6 style=color:red;>Please the Start Date cannot be EMPTY!</h6>');
						$('#ledger_report_modal_warning').hide().slideDown().delay(2000).fadeOut();
					};
				} 
				else 
				{
					$('#ledger_report_modal_warning').html('<h6 style=color:red;>Please the Ledger cannot be EMPTY!</h6>');
					$('#ledger_report_modal_warning').hide().slideDown().delay(2000).fadeOut();
				};
			}); 
		}

	//PROFIT AND LOSS ACCOUNT
		function profit_and_loss_modal()
		{
			$(document).on('click','#profit_and_loss_link',function()
			{
				var company_id = $('#session_company_id').val();
				var user_super_id = $('#session_user_super_id').val();
				var start_date = $('#plr_start_date').val();
				var end_date = $('#plr_end_date').val();
				$('#profit_and_loss_report_modal_form').trigger('reset');
				$('#plr_company_id').val(company_id);
				$('#plr_user_super_id').val(user_super_id);
				$('#profit_and_loss_report_modal').modal('show');
			}) 
		}

		function profit_and_loss_display()
		{
			$(document).on('click','#plr_ok_btn',function()
			{
				var company_id = $('#session_company_id').val();
				var user_super_id = $('#session_user_super_id').val();
				var start_date = $('#plr_start_date').val();
				var end_date = $('#plr_end_date').val();
				if (start_date !== "") 
				{
					if (end_date !== "") 
					{
						if (end_date >= start_date) 
						{
							$.ajax({
								url:'/layout/reports/profit_and_loss_processing.php',
								method:'POST',
								data:$('#profit_and_loss_report_modal_form').serialize(),
								success:function(data)
								{
									$('#profit_and_loss_report_modal').modal('hide');
									window.open('/layout/reports/profit_and_loss_report_display.php', '_blank');
								}
							});	
						} 
						else 
						{
							$('#profit_and_loss_report_modal_warning').html('<h6 style=color:red;>Please the End Date cannot be less than the Start Date!</h6>');
							$('#profit_and_loss_report_modal_warning').hide().slideDown().delay(2000).fadeOut();
						};
					} 
					else 
					{
						$('#profit_and_loss_report_modal_warning').html('<h6 style=color:red;>Please the End Date cannot be EMPTY!</h6>');
						$('#profit_and_loss_report_modal_warning').hide().slideDown().delay(2000).fadeOut();
					};
				} 
				else 
				{
					$('#profit_and_loss_report_modal_warning').html('<h6 style=color:red;>Please the Start Date cannot be EMPTY!</h6>');
					$('#profit_and_loss_report_modal_warning').hide().slideDown().delay(2000).fadeOut();
				};
			}); 
		}

	//BALANCE SHEET
		function balance_sheet_modal()
		{
			$(document).on('click','#balance_sheet_link',function()
			{
				var company_id = $('#session_company_id').val();
				var user_super_id = $('#session_user_super_id').val();
				var start_date = $('#balance_sheet_start_date').val();
				var end_date = $('#balance_sheet_end_date').val();
				$('#balance_sheet_modal_form').trigger('reset');
				$('#balance_sheet_company_id').val(company_id);
				$('#balance_sheet_user_super_id').val(user_super_id);
				$('#balance_sheet_modal').modal('show');
			}) 
		}

		function balance_sheet_display()
		{
			$(document).on('click','#balance_sheet_ok_btn',function()
			{
				var company_id = $('#session_company_id').val();
				var user_super_id = $('#session_user_super_id').val();
				var start_date = $('#balance_sheet_start_date').val();
				var end_date = $('#balance_sheet_end_date').val();
				if (start_date !== "") 
				{
					if (end_date !== "") 
					{
						if (end_date >= start_date) 
						{
							$.ajax({
								url:'/layout/reports/balance_sheet_processing.php',
								method:'POST',
								data:$('#balance_sheet_modal_form').serialize(),
								success:function(data)
								{
									$('#balance_sheet_modal').modal('hide');
									window.open('/layout/reports/balance_sheet_display.php', '_blank');
								}
							});	
						} 
						else 
						{
							$('#balance_sheet_modal_warning').html('<h6 style=color:red;>Please the End Date cannot be less than the Start Date!</h6>');
							$('#balance_sheet_modal_warning').hide().slideDown().delay(2000).fadeOut();
						};
					} 
					else 
					{
						$('#balance_sheet_modal_warning').html('<h6 style=color:red;>Please the End Date cannot be EMPTY!</h6>');
						$('#balance_sheet_modal_warning').hide().slideDown().delay(2000).fadeOut();
					};
				} 
				else 
				{
					$('#balance_sheet_modal_warning').html('<h6 style=color:red;>Please the Start Date cannot be EMPTY!</h6>');
					$('#balance_sheet_modal_warning').hide().slideDown().delay(2000).fadeOut();
				};
			}); 
		}
//INVENTORY VOUCHERS
	//STOCK REQUISITION
		function new_stock_requisition_modal()
		{
			$(document).on('click','#new_stock_requisition_icon',function()
			{
				$('#stock_req_update_btn').hide();
				$('#stock_req_save_btn').show();
				$('#stock_requisition_create_form').trigger('reset');
				$('#stock_requisition_create_modal').modal('show');
			});
		}

		function cancel_stock_requisition_modal()
		{
			$(document).on('click','#stock_req_cancel_btn',function()
			{
				$('#stock_requisition_create_form').trigger('reset');
				$('#stock_requisition_create_modal').modal('hide');
				window.location.href="/layout/vouchers/stock_requisition_list.php";
			});
		}

		function add_stock_requisition_item_row()
		{
			$(document).on('change','.stk_req_item_id',function(){ 
				var i = $('#stock_requisition_items_table tr:last').attr('id');
				i++;
				$.ajax({
					url:'/layout/vouchers/stock_requisition_item_list.php',
					method:'POST',
					data:{i:i},
					success:function(data)
					{
						$('#stock_requisition_items_table').append('<tr id="'+i+'">'+data+'</tr>');
					}
				});
			});
		}

		function get_stock_requisition_item_category()
		{
			$(document).on('change','.stk_req_item_id',function(){ 
				var category_id = $('option:selected', this).attr('data-value');
				var count = $(this).attr("data-id");
				$('#item_cat_id'+count).val(category_id);
			});
		}

		function delete_stock_requisition_item_row()
		{
			$(document).on('click', '#delete_stk_req_item', function(){  
       			var button_id = $(this).attr("data-id");
           		$('#'+button_id+'').remove();

           	});
		}

		function save_stock_requisition_voucher()
		{
			$(document).on('click','#stock_req_save_btn',function(e){
				e.preventDefault();
				var last_tr_id = $("#stock_requisition_items_table tr:last").attr("id");
				var last_tr_select = $("#stock_requisition_items_table tr:last option:selected").val();
				if(last_tr_select =="" || last_tr_select ==0)
				{
					$('#'+last_tr_id+'').remove();
				};
				var stock_req_from = $('#stock_req_from').val();
				var stock_req_to = $('#stock_req_to').val();
				var stk_req_date = $('#stk_req_date').val();
				if (stock_req_to !=="") 
				{
					if (stock_req_from !=="") 
					{
						if (stock_req_from !==stock_req_to) 
						{
							$.ajax({
					             url:'/layout/vouchers/stock_requisition_save.php',
					             method:'POST',
					             data:$('#stock_requisition_create_form').serialize(),
					             success:function(data)
						             {
						             	$('#stock_requisition_create_form').trigger('reset');
						             	window.location.href="/layout/vouchers/stock_requisition_list.php";
						             }
					        });		
						} 
						else 
						{
							alert('Please the location this requisition is being made from and location made to cannot be the same!');
						}
					} 
					else 
					{
						alert('Please select the location from which this requisition is being made!');
					}
				} 
				else 
				{
					alert('Please select the location the requisition is being made!');
				};
			});
		}

		function edit_stock_requisition_voucher()
		{
			$(document).on('click','#btn_edit_stock_req',function(){
				var stock_req_id = $(this).attr('data-id');
				$.ajax({
			             url:'/layout/vouchers/stock_requisition_check_transfer.php',
			             method:'POST',
			             data:{stock_req_id:stock_req_id},
			             success:function(data)
				            {
				            	if (data == "transferred") 
				            	{
				            		alert("The requisition has been served, editing is therefore not allowed!");
				            	}
				            	else if (data == "none")
				            	{
				            		$.ajax({
							             url:'/layout/vouchers/stock_requisition_edit.php',
							             method:'POST',
							             data:{stock_req_id:stock_req_id},
							             datatype:'JSON',
							             success:function(data)
								             {
								             	var res = $.parseJSON(data);
								             	$('#stock_req_id').val(res[0]);
								             	$('#stock_req_from').val(res[1]);
								             	$('#stock_req_to').val(res[2]);
								             	$('#stk_req_date').val(res[3]);
								             	$('#stk_req_requested_by').val(res[4]);
								             	//$('#').val(res[5]);
								             	$('#stk_req_narration').val(res[6]);
								             	$.ajax({
										             url:'/layout/vouchers/stock_requisition_items_edit.php',
										             method:'POST',
										             data:{stock_req_id:stock_req_id},
										             success:function(data)
											            {
											            	$('#stock_requisition_items_list').html(data);
														}
									             });
								             	$('#stock_req_update_btn').show();
								             	$('#stock_req_save_btn').hide();
												$('#stock_requisition_create_modal').modal('show');
								             }
							             });
        						};
							}
		             });
				
			});
		}

		function update_stock_requisition_voucher()
		{
			$(document).on('click','#stock_req_update_btn',function(e){
				e.preventDefault();
				var last_tr_id = $("#stock_requisition_items_table tr:last").attr("id");
				var last_tr_select = $("#stock_requisition_items_table tr:last option:selected").val();
				if(last_tr_select =="" || last_tr_select ==0)
				{
					$('#'+last_tr_id+'').remove();
				};
				var stock_req_from = $('#stock_req_from').val();
				var stock_req_to = $('#stock_req_to').val();
				var stk_req_date = $('#stk_req_date').val();
				if (stock_req_to !=="") 
				{
					if (stock_req_from !=="") 
					{
						if (stock_req_from !==stock_req_to) 
						{
							$.ajax({
					             url:'/layout/vouchers/stock_requisition_update.php',
					             method:'POST',
					             data:$('#stock_requisition_create_form').serialize(),
					             success:function(data)
						             {
						             	$('#stock_requisition_create_form').trigger('reset');
						             	window.location.href="/layout/vouchers/stock_requisition_list.php";
						             }
					        });		
						} 
						else 
						{
							alert('Please the location this requisition is being made from and location made to cannot be the same!');
						}
					} 
					else 
					{
						alert('Please select the location from which this requisition is being made!');
					}
				} 
				else 
				{
					alert('Please select the location the requisition is being made!');
				};
			});
		}

	//STOCK TRANSFER
		function stock_transfer_modal_requisition()
		{
			$(document).on('click','#btn_transfer_stock_req',function()
			{
				var stock_req_id = $(this).attr('data-id');
				$.ajax({
			             url:'/layout/vouchers/stock_requisition_check_transfer.php',
			             method:'POST',
			             data:{stock_req_id:stock_req_id},
			             success:function(data)
				            {
				            	if (data == "transferred") 
				            	{
				            		alert("The requisition has already been transferred!");
				            	}
				            	else if (data == "none")
				            	{
				            		$.ajax({
										url:'/layout/vouchers/stock_requisition_edit.php',
										method:'POST',
										data:{stock_req_id:stock_req_id},
										datatype:'JSON',
										success:function(data)
										{
											var res = $.parseJSON(data);
											$('#stock_req_id_trans').val(res[0]);
											$('#stock_trans_to').val(res[1]);
											$('#stock_trans_from').val(res[2]);
											$('#stock_req_date').val(res[3]);
											$('#stk_trans_requested_by').val(res[4]);
											$.ajax({
												url:'/layout/vouchers/stock_transfer_items_requested.php',
												method:'POST',
												data:{stock_req_id:stock_req_id},
												success:function(data)
												{
													$('#stock_transfer_items_list').html(data);
												}
											});
											$('#stock_trans_update_btn').hide();
											$('#stock_trans_save_btn').show();
											$('#stock_transfer_create_modal').modal('show');
										}
							        });
				            	};
							}
		             });
			});
		}

		function save_stock_transfer_voucher()
		{
			$(document).on('click','#stock_trans_save_btn',function(e){
				e.preventDefault();
				var last_tr_id = $("#stock_transfer_items_table tr:last").attr("id");
				var last_tr_select = $("#stock_transfer_items_table tr:last option:selected").val();
				if(last_tr_select =="" || last_tr_select ==0)
				{
					$('#'+last_tr_id+'').remove();
				};
				var stk_trans_date = $('#stk_trans_date').val();
				var stock_trans_from = $('#stock_trans_from').val();
				var stock_trans_to = $('#stock_trans_to').val();
				var stk_trans_date = $('#stk_trans_date').val();
				var stk_trans_transferred_by = $('#stk_trans_transferred_by').val();
				var stk_trans_requested_by = $('#stk_trans_requested_by').val();
				var stk_trans_collected_by = $('#stk_trans_collected_by').val();
				if (stock_trans_to !=="") 
				{
					if (stock_trans_from !=="") 
					{
						if (stock_trans_from !==stock_trans_to) 
						{
							if (stk_trans_transferred_by !=="") 
							{
								if (stk_trans_requested_by !=="") 
								{
									if (stk_trans_date !=="") 
									{
										$.ajax({
								             url:'/layout/vouchers/stock_transfer_save.php',
								             method:'POST',
								             data:$('#stock_transfer_create_form').serialize(),
								             success:function(data)
									             {
									             	$('#stock_transfer_create_form').trigger('reset');
									             	window.location.href="/layout/vouchers/stock_transfer_list.php";
									             }
								        });
							        } 
									else 
									{
										alert('Please type the date of the transaction!');
									}
								} 
								else 
								{
									alert('Please type the name of the person making the request!');
								}
							} 
							else 
							{
								alert('Please type name of the person making transfer!');
							}	
						} 
						else 
						{
							alert('Please the location this transfer is being made from and location made to cannot be the same!');
						}
					} 
					else 
					{
						alert('Please select the location from which this transfer is being made!');
					}
				} 
				else 
				{
					alert('Please select the location the transfer is being made!');
				};
			});
		}

		function edit_stock_transfer_voucher()
		{
			$(document).on('click','#btn_edit_stk_trans',function(){
				var stock_trans_id = $(this).attr('data-id');
				$.ajax({
			             url:'/layout/vouchers/stock_transfer_edit.php',
			             method:'POST',
			             data:{stock_trans_id:stock_trans_id},
			             datatype:'JSON',
			             success:function(data)
				             {
				             	var res = $.parseJSON(data);
				             	$('#stock_trans_id').val(res[0]);
				             	$('#stock_req_id_trans').val(res[1]);
				             	$('#stock_trans_from').val(res[2]);
				             	$('#stock_trans_to').val(res[3]);
				             	$('#stk_trans_date').val(res[4]);
				             	$('#stock_req_date').val(res[5]);
				             	$('#stk_trans_requested_by').val(res[6]);
				             	$('#stk_trans_approved_by').val(res[7]);
				             	$('#stk_trans_transferred_by').val(res[8]);
				             	$('#stk_trans_collected_by').val(res[9]);
				             	$('#stk_trans_narration').val(res[10]);
				             	$.ajax({
						             url:'/layout/vouchers/stock_transfer_items_edit.php',
						             method:'POST',
						             data:{stock_trans_id:stock_trans_id},
						             success:function(data)
							            {
							            	$('#stock_transfer_items_list').html(data);
										}
					             });
				             	$('#stock_trans_update_btn').show();
				             	$('#stock_trans_save_btn').hide();
								$('#stock_transfer_create_modal').modal('show');
				             }
			             });
			});
		}

		function update_stock_transfer_voucher()
		{
			$(document).on('click','#stock_trans_update_btn',function(e){
				e.preventDefault();
				var last_tr_id = $("#stock_transfer_items_table tr:last").attr("id");
				var last_tr_select = $("#stock_transfer_items_table tr:last option:selected").val();
				if(last_tr_select =="" || last_tr_select ==0)
				{
					$('#'+last_tr_id+'').remove();
				};
				var stock_trans_from = $('#stock_trans_from').val();
				var stock_trans_to = $('#stock_trans_to').val();
				var stk_trans_date = $('#stk_trans_date').val();
				var stk_trans_transferred_by = $('#stk_trans_transferred_by').val();
				var stk_trans_requested_by = $('#stk_trans_requested_by').val();
				var stk_trans_collected_by = $('#stk_trans_collected_by').val();
				if (stock_trans_to !=="") 
				{
					if (stock_trans_from !=="") 
					{
						if (stock_trans_from !==stock_trans_to) 
						{
							if (stk_trans_transferred_by !=="") 
							{
								if (stk_trans_requested_by !=="") 
								{
									$.ajax({
							             url:'/layout/vouchers/stock_transfer_update.php',
							             method:'POST',
							             data:$('#stock_transfer_create_form').serialize(),
							             success:function(data)
								             {
								             	$('#stock_transfer_create_form').trigger('reset');
												$('#stock_transfer_create_modal').modal('hide');
								             	window.location.href="/layout/vouchers/stock_transfer_list.php";
								             }
							        });	
								} 
								else 
								{
									alert('Please type the name of the person making the request!');
								}
							} 
							else 
							{
								alert('Please type name of the person making transfer!');
							}	
						} 
						else 
						{
							alert('Please the location this transfer is being made from and location made to cannot be the same!');
						}
					} 
					else 
					{
						alert('Please select the location from which this transfer is being made!');
					}
				} 
				else 
				{
					alert('Please select the location the transfer is being made!');
				};
			});
		}

		function new_stock_transfer_modal()
		{
			$(document).on('click','#new_stock_transfer_icon',function()
			{
				$('#stock_trans_update_btn').hide();
				$('#stock_trans_save_btn').show();
				$.ajax({
					url:'/layout/vouchers/stock_transfer_item_initial.php',
					method:'POST',
					data:{i:1},
					success:function(data)
					{
						$('#stock_transfer_items_list').html(data);
					}
				});
				$('#stock_transfer_create_form').trigger('reset');
				$('#stock_transfer_create_modal').modal('show');
			});
		}

		/*function cancel_stock_transfer_modal()
		{
			$(document).on('click','#stock_trans_cancel_btn',function()
			{
				$('#stock_transfer_create_form').trigger('reset');
				$('#stock_transfer_create_modal').modal('hide');
				window.location.href="/layout/vouchers/stock_transfer_list.php";
			});
		}*/

		function add_stock_transfer_item_row()
		{
			$(document).on('change','.stk_trans_item_id',function(){ 
				var i = $('#stock_transfer_items_table tr:last').attr('id');
				i++;
				$.ajax({
					url:'/layout/vouchers/stock_transfer_item_list.php',
					method:'POST',
					data:{i:i},
					success:function(data)
					{
						$('#stock_transfer_items_table').append(data);
					}
				});
			});
		}

		function get_stock_transfer_item_category()
		{
			$(document).on('change','.stk_trans_item_id',function(){ 

				var category_id = $('option:selected', this).attr('data-value');
				var count = $(this).attr("data-id");
				$('#item_cat_id'+count).val(category_id);
			});
		}

		function delete_stock_transfer_item_row()
		{
			$(document).on('click', '#delete_stk_trans_item', function(){  
       			var button_id = $(this).attr("data-id");
           		$('#'+button_id+'').remove();

           	});
		}

		/*function stock_transfer_modal_direct()
		{
			$(document).on('click','#new_stock_transfer_icon',function()
			{
				$('#stock_trans_update_btn').hide();
				$('#stock_trans_save_btn').show();
				$('#stock_transfer_create_form').trigger('reset');
				$('#stock_transfer_create_modal').modal('show');
			});
		}*/

		/*function stock_transfer_batch_list()
		{
			$(document).on('change','.stk_trans_item_id',function()
			{
				var count = $(this).val('data-id');
				var item_id = $('#stk_trans_item_id'+count).val();
				var category_id = $('#item_cat_id'+count).val();
				$.ajax(
				{
					url: '/layout/vouchers/stock_transfer_batch_list.php',
					method: 'POST',
					data: {item_id:item_id, category_id:category_id},
					datatype: 'JSON',
					success: function(data)
					{
						var res = $.parseJSON(data);
						$('#stock_trans_batch_no'+count).html('<option value="0">Please select</option>');
						for (var i=0, l=res.length; i<l;i+=2)
						{
							var oddPositionVal = res[i];
							var evenPositionVal = res[i+1];
							var rowhtml = '<option value=' + oddPositionVal + '>' + evenPositionVal + '</option>';
							$('#stock_trans_batch_no'+count).append(rowhtml);
						}
					}
				});
			});
		}*/
	
	//STOCK ADJUSTMENT
		function new_stock_adjustment_modal()
		{
			$(document).on('click','#new_stock_adjustment_icon', function()
			{
				$('#stock_adj_update_btn').hide();
				$('#stock_adj_save_btn').show();
				$('#stock_adjustment_create_form').trigger('reset');
				$('#stock_adjustment_create_modal').modal('show');
			});
		}

		function add_stock_adjustment_item_row()
		{
			$(document).on('change','.stk_adj_item_id',function(){ 
				var i = $('#stock_adjustment_items_table tr:last').attr('id');
				i++;
				$.ajax({
					url:'/layout/vouchers/stock_adjustment_item_list.php',
					method:'POST',
					data:{i:i},
					success:function(data)
					{
						$('#stock_adjustment_items_table').append('<tr id="'+i+'">'+data+'</tr>');
					}
				});
			});
		}

		function get_stock_adjustment_item_category()
		{
			$(document).on('change','.stk_adj_item_id',function(){ 
				var category_id = $('option:selected', this).attr('data-value');
				var count = $(this).attr("data-id");
				$('#item_cat_id'+count).val(category_id);
			});
		}

		function clear_adjustment_qty_in_or_out()
		{
			$(document).on('change click','.stk_adj_qty_in',function(){ 
				var i = $(this).closest('tr').attr('id');
				var qty_in = $('#stk_adj_qty_in'+i).val();
				if(qty_in !== "" && qty_in > 0)
				{
					$('#stk_adj_qty_out'+i).val(''); 
					$('#stk_adj_qty_out'+i).attr('hidden',true); 
				}
				else
				{
					$('#stk_adj_qty_out'+i).attr('hidden',false); 
				}
			});

			$(document).on('change click','.stk_adj_qty_out',function(){ 
				var i = $(this).closest('tr').attr('id');
				var qty_out = $('#stk_adj_qty_out'+i).val();
				if(qty_out !== "" && qty_out > 0)
				{
					$('#stk_adj_qty_in'+i).val(''); 
					$('#stk_adj_qty_in'+i).attr('hidden',true); 
				}
				else
				{
					$('#stk_adj_qty_in'+i).attr('hidden',false); 
				}
			});
		}

		function cancel_stock_adjustment_modal()
		{
			$(document).on('click','#stock_adj_cancel_btn',function()
			{
				$('#stock_adjustment_create_form').trigger('reset');
				$('#stock_adjustment_create_modal').modal('hide');
				window.location.href="/layout/vouchers/stock_adjustment_list.php";
			});
		}

		function delete_stock_adjustment_item_row()
		{
			$(document).on('click', '#delete_stk_adj_item', function(){  
       			var button_id = $(this).attr("data-id");
           		$('#'+button_id+'').remove();

           	});
		}

		function save_stock_adjustment_voucher()
		{
			$(document).on('click','#stock_adj_save_btn',function(e){
				e.preventDefault();
				var last_tr_id = $("#stock_adjustment_items_table tr:last").attr("id");
				var last_tr_select = $("#stock_adjustment_items_table tr:last option:selected").val();
				
				var stk_adj_adjusted_by = $('#stk_adj_adjusted_by').val();
				var stk_adj_narration = $('#stk_adj_narration').val();
				var stk_adj_date = $('#stk_adj_date').val();
				if (stk_adj_date !=="") 
				{
					if (stk_adj_adjusted_by !=="") 
					{
						if (stk_adj_narration !== "") 
						{
							if(last_tr_select == "" || last_tr_select == 0)
							{
								$('#'+last_tr_id+'').remove();
							};

							$.ajax({
					             url:'/layout/vouchers/stock_adjustment_save.php',
					             method:'POST',
					             data:$('#stock_adjustment_create_form').serialize(),
					             success:function(data)
						             {
						             	$('#stock_adjustment_create_form').trigger('reset');
						             	window.location.href="/layout/vouchers/stock_adjustment_list.php";
						             }
					        });		
						} 
						else 
						{
							alert('Please the narration this Stock Adjustment Voucher cannot be the empty!');
						}
					} 
					else 
					{
						alert('Please Adjusted by of this Stock Adjustment Voucher cannot be the empty!');
					}
				} 
				else 
				{
					alert('Please select the Date for the Stock Adjustment Voucher is being made!');
				};
			});
		}

		function edit_stock_adjustment_voucher()
		{
			$(document).on('click','#btn_edit_stk_adj',function(){
				var stock_adj_id = $(this).attr('data-id');
        		$.ajax({
		             url:'/layout/vouchers/stock_adjustment_edit.php',
		             method:'POST',
		             data:{stock_adj_id:stock_adj_id},
		             datatype:'JSON',
		             success:function(data)
			             {
			             	var res = $.parseJSON(data);
			             	$('#stock_adj_id').val(res[0]);
			             	$('#stk_adj_ref_no').val(res[1]);
			             	$('#stk_adj_date').val(res[2]);
			             	$('#stk_adj_narration').val(res[3]);
			             	$('#stk_adj_adjusted_by').val(res[4]);
			             	$.ajax({
					             url:'/layout/vouchers/stock_adjustment_items_edit.php',
					             method:'POST',
					             data:{stock_adj_id:stock_adj_id},
					             success:function(data)
						            {
						            	$('#stock_adjustment_items_list').html(data);
									}
				             });
			             	$('#stock_adj_update_btn').show();
			             	$('#stock_adj_save_btn').hide();
							$('#stock_adjustment_create_modal').modal('show');
			             }
		        });
			});
		}

		function update_stock_adjustment_voucher()
		{
			$(document).on('click','#stock_adj_update_btn',function(e){
				e.preventDefault();
				var last_tr_id = $("#stock_adjustment_items_table tr:last").attr("id");
				var last_tr_select = $("#stock_adjustment_items_table tr:last option:selected").val();
				
				var stk_adj_adjusted_by = $('#stk_adj_adjusted_by').val();
				var stk_adj_narration = $('#stk_adj_narration').val();
				var stk_adj_date = $('#stk_adj_date').val();
				if (stk_adj_date !=="") 
				{
					if (stk_adj_adjusted_by !=="") 
					{
						if (stk_adj_narration !== "") 
						{
							if(last_tr_select == "" || last_tr_select == 0)
							{
								$('#'+last_tr_id+'').remove();
							};
							$.ajax({
					             url:'/layout/vouchers/stock_adjustment_update.php',
					             method:'POST',
					             data:$('#stock_adjustment_create_form').serialize(),
					             success:function(data)
						             {
						             	$('#stock_adjustment_create_form').trigger('reset');
						             	window.location.href="/layout/vouchers/stock_adjustment_list.php";
						             }
					        });		
						} 
						else 
						{
							alert('Please the narration this Stock Adjustment Voucher cannot be the empty!');
						}
					} 
					else 
					{
						alert('Please Adjusted by of this Stock Adjustment Voucher cannot be the empty!');
					}
				} 
				else 
				{
					alert('Please select the Date for the Stock Adjustment Voucher is being made!');
				};
			});
		}

		function delete_stock_adjustment()
		{
			$(document).on('click','#btn_delete_stk_adj',function(){
				var stock_adj_id = $(this).attr('data-id');
				var currentRow=$(this).closest("tr");
				var lab = currentRow.find("td:eq(1)").text();
				$('#stock_adjustment_delete_question').text('Are you sure you want to delete Stock Adjustment No:' + stock_adj_id + '?');
				$('#stock_adjustment_delete_modal').modal('show');
				$(document).on('click','#stk_adj_del_yes',function(){
					$.ajax({  
		                 url:'/layout/vouchers/stock_adjustment_delete.php',  
		                 type:'POST',  
		                 data:{stock_adj_id:stock_adj_id},
		                 success:function(){
		                 	$('#stock_adjustment_delete_modal').modal('hide');
		                 	window.location.href="/layout/vouchers/stock_adjustment_list.php";
		                 }  
		            });
			      });
				$(document).on('click','#stk_adj_del_no',function(){
					$('#stock_adjustment_delete_modal').modal('hide');
				});
			});
		}

	//STOCK REPORT
		function stock_report_modal()
		{
			$(document).on('click','#stock_report_link',function()
			{
				var stock_report_company_id = $('#session_company_id').val();
				var stock_report_user_id = $('#session_user_super_id').val();
				$('#stock_report_modal_form').trigger('reset');
				$('#stock_report_company_id').val(stock_report_company_id);
				$('#stock_report_user_id').val(stock_report_user_id);
				$('#stock_report_modal').modal('show');
			}) 
		}

		function stock_report_display()
		{
			$(document).on('click','#stock_report_ok_btn',function()
			{
				var stock_report_company_id = $('#session_company_id').val();
				var stock_report_user_id = $('#session_user_super_id').val();
				var stock_report_warehouse = $('#stock_report_warehouse').val();
				var stock_report_start_date = $('#stock_report_start_date').val();
				var stock_report_end_date = $('#stock_report_end_date').val();
				if (stock_report_start_date !== "") 
				{
					if (stock_report_end_date !== "") 
					{
						if (stock_report_end_date >= stock_report_start_date) 
						{
							if (stock_report_warehouse !=="") 
							{
								$.ajax({
						             url:'/layout/reports/stock_report_processing.php',
						             method:'POST',
						             data:$('#stock_report_modal_form').serialize(),
						             success:function(data)
							             {
					             			$('#stock_report_modal').modal('hide');
					             			window.open('/layout/reports/stock_report_display.php', '_blank');
							             }
						        });	
							} 
							else 
							{
								$('#stock_report_modal_warning').html('<h6 style=color:red;>Please the Warehouse cannot be EMPTY!</h6>');
								$('#stock_report_modal_warning').hide().slideDown().delay(2000).fadeOut();
							};
						} 
						else 
						{
							$('#stock_report_modal_warning').html('<h6 style=color:red;>Please the End Date cannot be less than the Start Date!</h6>');
							$('#stock_report_modal_warning').hide().slideDown().delay(2000).fadeOut();
						};
					} 
					else 
					{
						$('#stock_report_modal_warning').html('<h6 style=color:red;>Please the End Date cannot be EMPTY!</h6>');
						$('#stock_report_modal_warning').hide().slideDown().delay(2000).fadeOut();
					};
				} 
				else 
				{
					$('#stock_report_modal_warning').html('<h6 style=color:red;>Please the Start Date cannot be EMPTY!</h6>');
					$('#stock_report_modal_warning').hide().slideDown().delay(2000).fadeOut();
				};
			}); 
		}

		function stock_report_item_tally_card()
		{
			$(document).on('click','#stock_report_item_tally_card',function()
			{
				var item_id = $(this).attr('data-id');
				var category_id = $(this).attr('data-id1');
				var warehouse_id = $(this).attr('data-id2');
				var start_date = $(this).attr('data-id3');
				var end_date = $(this).attr('data-id4');
				var company_id = $(this).attr('data-id5');
				$.ajax({
		             url:'/layout/reports/stock_report_item_tally_card.php',
		             method:'POST',
		             data:{
		             	item_id:item_id,
		             	category_id:category_id,
		             	warehouse_id:warehouse_id,
		             	start_date:start_date,
		             	end_date:end_date,
		             	company_id:company_id
		             },
		             success:function(data)
			             {
	             			//$('#stock_report_modal').modal('hide');
	             			window.open('/layout/reports/stock_report_item_tally_card_display.php', '_blank');
			             }
		        });	
			}); 
		}

	//TALLY CARD
		function stock_item_tally_card_modal()
		{
			$(document).on('click','#stock_item_tally_card_link',function()
			{
				var stock_item_tally_card_company_id = $('#session_company_id').val();
				var stock_item_tally_card_user_id = $('#session_user_super_id').val();
				$('#stock_item_tally_card_modal_form').trigger('reset');
				$('#stock_item_tally_card_company_id').val(stock_item_tally_card_company_id);
				$('#stock_item_tally_card_user_id').val(stock_report_user_id);
				$('#stock_item_tally_card_modal').modal('show');
			});
		}

		function stock_item_tally_card_get_category()
		{
			$(document).on('change','#stock_item_tally_card_item',function(){ 

				var category_id = $('option:selected', this).attr('data-value');
				$('#stock_item_tally_card_category_id').val(category_id);
			});
		}

		function stock_item_tally_card_display()
		{
			$(document).on('click','#stock_item_tally_card_ok_btn',function()
			{
				var company_id = $('#session_company_id').val();
				var user_id = $('#session_user_super_id').val();
				var item_id = $('#stock_item_tally_card_item').val();
				var category_id = $('#stock_item_tally_card_category_id').val();
				var warehouse_id = $('#stock_item_tally_card_warehouse').val();
				var start_date = $('#stock_item_tally_card_start_date').val();
				var end_date = $('#stock_item_tally_card_end_date').val();
				if (start_date !== "") 
				{
					if (end_date !== "") 
					{
						if (end_date >= start_date) 
						{
							if (warehouse_id !=="") 
							{
								if (item_id !=="" && item_id > 0) 
								{
									$.ajax({
							             url:'/layout/reports/stock_report_item_tally_card.php',
							             method:'POST',
							             data:{
							             	company_id:company_id,
							             	item_id:item_id,
							             	category_id:category_id,
							             	warehouse_id:warehouse_id,
							             	start_date:start_date,
							             	end_date:end_date
							             },
							             success:function(data)
								             {
						             			$('#stock_item_tally_card_modal').modal('hide');
						             			window.open('/layout/reports/stock_report_item_tally_card_display.php', '_blank');
								             }
							        });
								} 
								else 
								{
									$('#stock_item_tally_card_modal_warning').html('<h6 style=color:red;>Please the Item cannot be EMPTY!</h6>');
									$('#stock_item_tally_card_modal_warning').hide().slideDown().delay(2000).fadeOut();
								};	
							} 
							else 
							{
								$('#stock_item_tally_card_modal_warning').html('<h6 style=color:red;>Please the Warehouse cannot be EMPTY!</h6>');
								$('#stock_item_tally_card_modal_warning').hide().slideDown().delay(2000).fadeOut();
							};
						} 
						else 
						{
							$('#stock_item_tally_card_modal_warning').html('<h6 style=color:red;>Please the End Date cannot be less than the Start Date!</h6>');
							$('#stock_item_tally_card_modal_warning').hide().slideDown().delay(2000).fadeOut();
						};
					} 
					else 
					{
						$('#stock_item_tally_card_modal_warning').html('<h6 style=color:red;>Please the End Date cannot be EMPTY!</h6>');
						$('#stock_item_tally_card_modal_warning').hide().slideDown().delay(2000).fadeOut();
					};
				} 
				else 
				{
					$('#stock_item_tally_card_modal_warning').html('<h6 style=color:red;>Please the Start Date cannot be EMPTY!</h6>');
					$('#stock_item_tally_card_modal_warning').hide().slideDown().delay(2000).fadeOut();
				};
			}); 
		}

	//SITE REPORT
		function site_report_modal()
		{
			$(document).on('click','#site_report_link',function()
			{
				var site_report_company_id = $('#session_company_id').val();
				var site_report_user_id = $('#session_user_super_id').val();
				$('#site_report_modal_form').trigger('reset');
				$('#site_report_company_id').val(site_report_company_id);
				$('#site_report_user_id').val(site_report_user_id);
				$('#site_report_modal').modal('show');
			}) 
		}

		function site_report_display()
		{
			$(document).on('click','#site_report_ok_btn',function()
			{
				var site_report_company_id = $('#session_company_id').val();
				var site_report_user_id = $('#session_user_super_id').val();
				var site_report_site = $('#site_report_site').val();
				var site_report_start_date = $('#site_report_start_date').val();
				var site_report_end_date = $('#site_report_end_date').val();
				if (site_report_start_date !== "") 
				{
					if (site_report_end_date !== "") 
					{
						if (site_report_end_date >= site_report_start_date) 
						{
							if (site_report_site !=="") 
							{
								$.ajax({
						             url:'/layout/reports/site_report_processing.php',
						             method:'POST',
						             data:$('#site_report_modal_form').serialize(),
						             success:function(data)
							             {
					             			$('#site_report_modal').modal('hide');
					             			window.open('/layout/reports/site_report_display.php', '_blank');
							             }
						        });	
							} 
							else 
							{
								$('#site_report_modal_warning').html('<h6 style=color:red;>Please the Site cannot be EMPTY!</h6>');
								$('#site_report_modal_warning').hide().slideDown().delay(2000).fadeOut();
							};
						} 
						else 
						{
							$('#site_report_modal_warning').html('<h6 style=color:red;>Please the End Date cannot be less than the Start Date!</h6>');
							$('#site_report_modal_warning').hide().slideDown().delay(2000).fadeOut();
						};
					} 
					else 
					{
						$('#site_report_modal_warning').html('<h6 style=color:red;>Please the End Date cannot be EMPTY!</h6>');
						$('#site_report_modal_warning').hide().slideDown().delay(2000).fadeOut();
					};
				} 
				else 
				{
					$('#site_report_modal_warning').html('<h6 style=color:red;>Please the Start Date cannot be EMPTY!</h6>');
					$('#site_report_modal_warning').hide().slideDown().delay(2000).fadeOut();
				};
			}); 
		}

		function site_report_item_tally_card()
		{
			$(document).on('click','#site_report_item_tally_card',function()
			{
				var site_id = $(this).attr('data-id');
				var start_date = $(this).attr('data-id3');
				var end_date = $(this).attr('data-id4');
				var company_id = $(this).attr('data-id5');
				$.ajax({
		             url:'/layout/reports/site_report_item_tally_card.php',
		             method:'POST',
		             data:{
		             	site_id:site_id,
		             	start_date:start_date,
		             	end_date:end_date,
		             	company_id:company_id
		             },
		             success:function(data)
			             {
	             			//$('#stock_report_modal').modal('hide');
	             			window.open('/layout/reports/site_report_item_tally_card_display.php', '_blank');
			             }
		        });	
			}); 
		}

	//ASSET REPORT
		function asset_report_modal()
		{
			$(document).on('click','#asset_report_link',function()
			{
				var asset_report_company_id = $('#session_company_id').val();
				var asset_report_user_id = $('#session_user_super_id').val();
				$('#asset_report_modal_form').trigger('reset');
				$('#asset_report_company_id').val(asset_report_company_id);
				$('#asset_report_user_id').val(asset_report_user_id);
				$('#asset_report_modal').modal('show');
			}) 
		}

		function asset_report_display()
		{
			$(document).on('click','#asset_report_ok_btn',function()
			{
				var asset_report_company_id = $('#session_company_id').val();
				var asset_report_user_id = $('#session_user_super_id').val();
				var asset_report_asset = $('#asset_report_asset').val();
				var asset_report_start_date = $('#asset_report_start_date').val();
				var asset_report_end_date = $('#asset_report_end_date').val();
				if (asset_report_start_date !== "") 
				{
					if (asset_report_end_date !== "") 
					{
						if (asset_report_end_date >= asset_report_start_date) 
						{
							if (asset_report_asset !=="") 
							{
								$.ajax({
						             url:'/layout/reports/asset_report_processing.php',
						             method:'POST',
						             data:$('#asset_report_modal_form').serialize(),
						             success:function(data)
							             {
					             			$('#asset_report_modal').modal('hide');
					             			window.open('/layout/reports/asset_report_display.php', '_blank');
							             }
						        });	
							} 
							else 
							{
								$('#asset_report_modal_warning').html('<h6 style=color:red;>Please the Site cannot be EMPTY!</h6>');
								$('#asset_report_modal_warning').hide().slideDown().delay(2000).fadeOut();
							};
						} 
						else 
						{
							$('#asset_report_modal_warning').html('<h6 style=color:red;>Please the End Date cannot be less than the Start Date!</h6>');
							$('#asset_report_modal_warning').hide().slideDown().delay(2000).fadeOut();
						};
					} 
					else 
					{
						$('#asset_report_modal_warning').html('<h6 style=color:red;>Please the End Date cannot be EMPTY!</h6>');
						$('#asset_report_modal_warning').hide().slideDown().delay(2000).fadeOut();
					};
				} 
				else 
				{
					$('#asset_report_modal_warning').html('<h6 style=color:red;>Please the Start Date cannot be EMPTY!</h6>');
					$('#asset_report_modal_warning').hide().slideDown().delay(2000).fadeOut();
				};
			}); 
		}

		function asset_report_item_tally_card()
		{
			$(document).on('click','#asset_report_item_tally_card',function()
			{
				var asset_id = $(this).attr('data-id');
				var start_date = $(this).attr('data-id3');
				var end_date = $(this).attr('data-id4');
				var company_id = $(this).attr('data-id5');
				$.ajax({
		             url:'/layout/reports/asset_report_item_tally_card.php',
		             method:'POST',
		             data:{
		             	asset_id:asset_id,
		             	start_date:start_date,
		             	end_date:end_date,
		             	company_id:company_id
		             },
		             success:function(data)
			             {
	             			//$('#stock_report_modal').modal('hide');
	             			window.open('/layout/reports/asset_report_item_tally_card_display.php', '_blank');
			             }
		        });	
			}); 
		}